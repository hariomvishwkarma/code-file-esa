"use strict";

(function () {
  if (!customElements.get("product-bundle")) {
    class ProductBundle extends HTMLElement {
      constructor() {
        super();
        this.min = parseInt(this.dataset.min, 10) || 0;
        this.max = Math.max(this.min, parseInt(this.dataset.max, 10) || 0);
        this.bundleCount = 0;
        this.productIds = [];
      }

      connectedCallback() {
        this.elements = {
          submitButton: this.querySelector('[data-component="product-bundle-submit"]'),
          addToBundleBtns: Array.from(this.querySelectorAll('[data-component="product-bundle-button"]')),
        };
        this.addEventListener("change", (event) => this.handleCheckboxChange(event));
        this.addEventListener("click", (event) => this.handleButtonClick(event));
        this.updateSubmitButtonState();
      }

      checkTargetElement(element, selector) {
        return element.closest(selector) || (element.matches(selector) ? element : null);
      }

      handleCheckboxChange(event) {
        const checkbox = this.checkTargetElement(event.target, '[data-component="product-bundle-button"]');
        if (checkbox) this.toggleProductInBundle(checkbox);
      }

      handleButtonClick(event) {
        const submitButton = this.checkTargetElement(event.target, '[data-component="product-bundle-submit"]');
        if (submitButton) this.addBundleToCart(submitButton);
      }

      toggleProductInBundle(checkbox) {
        if (!checkbox) return;
        const { productId } = checkbox.dataset;
        const isChecked = checkbox.checked;
        if (isChecked && this.bundleCount < this.max) {
          this.bundleCount++;
          this.productIds.push({ id: productId, currentId: productId });
          checkbox.inBundle = true;
        } else if (!isChecked) {
          this.bundleCount--;
          this.productIds = this.productIds.filter(item => item.id !== productId);
          checkbox.inBundle = false;
        }
        this.updateSubmitButtonState();
      }

      updateSubmitButtonState() {
        const isComplete = this.bundleCount >= this.min;
        if (this.elements.submitButton) {
          this.elements.submitButton.disabled = !isComplete;
        }
      }

      async addBundleToCart(button) {
        if (!button || this.bundleCount < this.min) return;
      
        button.setAttribute("disabled", "true");
      
        const loader = button.querySelector(".loading__spinner");
        if (loader) loader.classList.remove("hidden");
      
        const bundleData = {
          items: this.productIds.map((id) => ({
            id: parseInt(id.currentId),
            quantity: 1
          }))
        };
      
        try {
          const response = await fetch("/cart/add.js", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json"
            },
            body: JSON.stringify(bundleData)
          });
      
          if (!response.ok) throw new Error("Failed to add bundle to cart");
      
          const cartPopup = document.querySelector("cart-popup");
          if (cartPopup) {
            const responseText = await (await fetch("/")).text();
            const html = new DOMParser().parseFromString(responseText, "text/html");
            const selectors = [
              "cart-popup-items",
              ".popup__footer",
              "#cart-icon-bubble",
              ".popup__header .cart-count-bubble",
              ".popup__inner-empty"
            ];
      
            for (const selector of selectors) {
              const targetElement = document.querySelector(selector);
              const sourceElement = html.querySelector(selector);
              if (targetElement && sourceElement) {
                targetElement.innerHTML = sourceElement.innerHTML;
                targetElement.className = sourceElement.className;
              }
              if (selector === ".popup__inner-empty" && targetElement) {
                targetElement.style.display = "none";
              }
            }
      
            cartPopup.classList.remove("is-empty");
            cartPopup.open();
          }
      
          this.cleanBundleAfterSubmit();
        } catch (error) {
          console.error(error.message);
        } finally {
          if (loader) loader.classList.add("hidden");
          button.removeAttribute("disabled");
        }
      }


      cleanBundleAfterSubmit() {
        this.bundleCount = 0;
        this.productIds = [];
        this.elements.addToBundleBtns.forEach((btn) => {
          if (btn.dataset.outOfStock !== "true") {
            btn.checked = false;
            btn.inBundle = false;
          }
        });
        this.updateSubmitButtonState();
        if (this.elements.submitButton) {
          setTimeout(() => {
            this.elements.submitButton.disabled = true;
          }, 500);
        }

      }

      disconnectedCallback() {}
    }

    customElements.define("product-bundle", ProductBundle);
  }
})();

