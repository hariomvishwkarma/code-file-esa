if (!customElements.get('quick-purchase')) {
class QuickPurchase extends HTMLElement {
  constructor() {
    super();
    this.initialized = false;
  }  

  connectedCallback() {
    if (this.initialized) return;
    this.initialized = true;
    this.setupListener();
  }

   disconnectedCallback() {
    this.initialized = false;
  }

  setupListener() {
    const quickPurchaseStyle1 = this.querySelectorAll('.quick-purchase-product-list-style_1');
    const quickPurchaseStyle2 = this.querySelectorAll('.quick-purchase-product-list-style_2');
    const productDetailItems = this.querySelectorAll('.quick-purchase-product-detail li');
    const marqueeProductsContainer = this.querySelector('.quick-purchase-product-marquee');
    const productDetailContainer = this.querySelector('.quick-purchase-product-detail');
    const quickPurchaseProductAddIcon = this.querySelector('.quick-purchase-product-add-icon');
    const quickPurchaseProductClose = this.querySelector('.quick-purchase-product-close');

    /* ---------- STYLE 1 ACTIVE TOGGLE ---------- */
    this.addEventListener('click', (e) => {
      const item = e.target.closest('.quick-purchase-product-list-style_1');
      if (!item || !this.contains(item)) return;

      const addIcon = e.target.closest('.quick-purchase-product-add-icon');
      const isActive = item.classList.contains('is-active');

      const allItems = this.querySelectorAll('.quick-purchase-product-list-style_1');

      /* ----- CLOSE: only when active close-button icon clicked ----- */
      if (isActive && addIcon?.classList.contains('close-button')) {
        item.classList.remove('is-active');
        addIcon.classList.remove('close-button');
        e.stopPropagation();
        return;
      }

      /* ----- IF already active & card clicked → do nothing ----- */
      if (isActive) return;

      /* ----- OPEN ----- */
      allItems.forEach(el => {
        el.classList.remove('is-active');
        el.querySelector('.quick-purchase-product-add-icon')
          ?.classList.remove('close-button');
      });

      item.classList.add('is-active');
      item.querySelector('.quick-purchase-product-add-icon')
        ?.classList.add('close-button');
    });


    /* ---------- STYLE 2 EXISTING LOGIC ---------- */
    quickPurchaseStyle2.forEach(item => {
      item.addEventListener('click', () => {
        const clickedProductId = item.getAttribute('product-id');

        marqueeProductsContainer?.classList.add('quick-purchase-product-marquee-width');
        productDetailContainer?.classList.add('quick-purchase-product-detail-width');

        productDetailItems.forEach(detailItem => {
          detailItem.classList.add('hidden-active');
        });

        const matchingDetailItem = Array.from(productDetailItems).find(detailItem => {
          return detailItem.getAttribute('product-id') === clickedProductId;
        });

        if (matchingDetailItem) {
          matchingDetailItem.classList.remove('hidden-active');
        }
      });
    });
    /* ---------- STYLE 2 CLOSE BUTTON ---------- */
    quickPurchaseProductClose?.addEventListener('click', () => {
      marqueeProductsContainer?.classList.remove('quick-purchase-product-marquee-width');
      productDetailContainer?.classList.remove('quick-purchase-product-detail-width');

      productDetailItems.forEach(detailItem => {
        detailItem.classList.add('hidden-active');
      });

      quickPurchaseProductClose.classList.add('hidden-active');
    });
  }
}

customElements.define('quick-purchase', QuickPurchase);
}