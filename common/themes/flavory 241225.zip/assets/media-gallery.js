if (!customElements.get('media-gallery')) {
  customElements.define(
    'media-gallery',
    class MediaGallery extends HTMLElement {
      constructor() {
        super();
        this.elements = {
          liveRegion: this.querySelector('[id^="GalleryStatus"]'),
          viewer: this.querySelector('[id^="GalleryViewer"]'),
          thumbnails: this.querySelector('[id^="GalleryThumbnails"]'),
        };

        this.handleResize = this.handleResize.bind(this);

        this.mql = window.matchMedia('(min-width: 750px)');
        if (!this.elements.thumbnails) return;

        this.elements.viewer.addEventListener('slideChanged', debounce(this.onSlideChanged.bind(this), 500));

        this.elements.thumbnails.querySelectorAll('[data-target]').forEach((mediaToSwitch) => {
          mediaToSwitch
            .querySelector('button')
            .addEventListener('click', this.setActiveMedia.bind(this, mediaToSwitch.dataset.target, false));
        });

        if (this.dataset.desktopLayout.includes('thumbnail') && this.mql.matches)
          this.removeListSemantic();

        window.addEventListener('resize', this.handleResize);
      }

      handleResize() {
        if (this.classList.contains('thumbnail-vertical-scrollbar')) {
          const thisElement = this;
          setTimeout(function () {
            // Empty, but placeholder remains
          }, 5);
        }
      }

      onSlideChanged(event) {
        const thumbnail = this.elements.thumbnails.querySelector(
          `[data-target="${event.detail.currentElement.dataset.mediaId}"]`
        );
        this.setActiveThumbnail(thumbnail);
      }

      setActiveMedia(mediaId, prepend) {
        let activeMedia =
          this.elements.viewer.querySelector(`[data-media-id="${mediaId}"]`);

        if (!activeMedia) {
          console.warn("Media not found:", mediaId);
          return;
        }
        activeMedia.classList.add('is-active');
        if (prepend) {}

        this.preventStickyHeader();

        window.setTimeout(() => {
          if (this.elements.thumbnails) {
            activeMedia.parentElement.scrollTo({ left: activeMedia.offsetLeft });
          }
          if (!this.elements.thumbnails || this.dataset.desktopLayout === 'stacked') {
            activeMedia.scrollIntoView({ behavior: 'smooth' });
          }
        });

        this.playActiveMedia(activeMedia);

        if (!this.elements.thumbnails) return;
        const activeThumbnail = this.elements.thumbnails.querySelector(`[data-target="${mediaId}"]`);
        this.setActiveThumbnail(activeThumbnail);
        this.announceLiveRegion(activeMedia, activeThumbnail.dataset.mediaPosition);
      }

      // ✅ FIXED METHOD
      setActiveThumbnail(thumbnail) {
        if (!this.elements.thumbnails || !thumbnail) return;

        this.elements.thumbnails
          .querySelectorAll('button')
          .forEach((element) => element.removeAttribute('aria-current'));

        thumbnail.querySelector('button').setAttribute('aria-current', true);

        const containerRect = this.elements.thumbnails.getBoundingClientRect();
        const thumbRect = thumbnail.getBoundingClientRect();

        const isVisible =
          thumbRect.left >= containerRect.left &&
          thumbRect.right <= containerRect.right &&
          thumbRect.top >= containerRect.top &&
          thumbRect.bottom <= containerRect.bottom;

        if (isVisible) return;

        this.elements.thumbnails.scrollTo({ left: thumbnail.offsetLeft });
      }

      announceLiveRegion(activeItem, position) {
        const image = activeItem.querySelector('.product__modal-opener--image img');
        if (!image) return;
        image.onload = () => {
          this.elements.liveRegion.setAttribute('aria-hidden', false);
          this.elements.liveRegion.innerHTML = window.accessibilityStrings.imageAvailable.replace('[index]', position);
          setTimeout(() => {
            this.elements.liveRegion.setAttribute('aria-hidden', true);
          }, 2000);
        };
        image.src = image.src;
      }

      playActiveMedia(activeItem) {
        window.pauseAllMedia();
        const deferredMedia = activeItem.querySelector('.deferred-media');
        if (deferredMedia) deferredMedia.loadContent(false);
      }

      preventStickyHeader() {
        this.stickyHeader = this.stickyHeader || document.querySelector('sticky-header');
        if (!this.stickyHeader) return;
        this.stickyHeader.dispatchEvent(new Event('preventHeaderReveal'));
      }

      removeListSemantic() {
        if (!this.elements.viewer.slider) return;
        this.elements.viewer.slider.setAttribute('role', 'presentation');
        this.elements.viewer.sliderItems.forEach((slide) => slide.setAttribute('role', 'presentation'));
      }
    }
  );
}

class GallerySlider extends HTMLElement {
  constructor() {
    super();
    this.swiperInstance = null;
    this.thumbnailSwiper = null;
    this.handleResize = this.handleResize.bind(this);
    this.currentDirection = null;
    this._isInitialized = false;
  }

  connectedCallback() {
    window.requestAnimationFrame(() => {
      try {
        this.initSwiper();
      } catch (err) {
        console.error('GallerySlider init error:', err);
      }
    });
    window.addEventListener('resize', this.handleResize);
  }

  disconnectedCallback() {
    this.destroySwipers();
    window.removeEventListener('resize', this.handleResize);
  }

  destroySwipers() {
    if (this.swiperInstance) {
      try { this.swiperInstance.destroy(true, true); } catch(e){ console.warn(e); }
      this.swiperInstance = null;
    }
    if (this.thumbnailSwiper) {
      try { this.thumbnailSwiper.destroy(true, true); } catch(e){ console.warn(e); }
      this.thumbnailSwiper = null;
    }
    this._isInitialized = false;
  }

  getDirection() {
    const explicit = this.dataset.direction;
    if (explicit) return (window.innerWidth >= 989) ? explicit : 'horizontal';
    const isDesktop = window.innerWidth >= 989;
    return isDesktop ? 'horizontal' : 'horizontal';
  }

  parseSlides(el, fallback) {
    if (!el) return { desktop: fallback, tablet: Math.max(2, fallback), mobile: Math.max(1, Math.floor(fallback/2)) };
    const d = el.dataset || {};
    return {
      desktop: parseInt(d.desktopSlide) || fallback,
      tablet: parseInt(d.tabletSlide) || Math.max(2, fallback),
      mobile: parseInt(d.mobileSlide) || Math.max(1, Math.floor(fallback/2)),
    };
  }

  initSwiper() {
    const swiperContainer = this.querySelector('.swiper.gallery-slider') || this.querySelector('.swiper');
    if (!swiperContainer) {
      console.error('GallerySlider: .swiper.gallery-slider not found inside this instance');
      return;
    }

    const stackedLayout = this.classList.contains('layout--stacked');
    const stackedDesktopBreakpoint = 990;
    const shouldInit = !(stackedLayout && window.innerWidth >= stackedDesktopBreakpoint);

    if (!shouldInit) {
      if (this._isInitialized) {
        this.destroySwipers();
      }
      return;
    }

    const mainSlides = this.parseSlides(swiperContainer, 1);

    let thumbsWrapper = this.querySelector('.swiper.gallery-thumbs') || this.querySelector('.gallery-thumbs');
    if (!thumbsWrapper) {
      const siblingThumb = this.parentElement?.querySelector('.gallerythumbnail-slider .swiper.gallery-thumbs');
      if (siblingThumb) thumbsWrapper = siblingThumb;
    }

    const thumbSlides = this.parseSlides(thumbsWrapper, 4);
    const direction = this.getDirection();
    const slidesCount = swiperContainer.querySelectorAll('.swiper-slide').length;

    this.destroySwipers();
    this.currentDirection = direction;

    const thumbsAreVertical = !!(thumbsWrapper && (thumbsWrapper.dataset.direction === 'vertical' || thumbsWrapper.getAttribute('data-direction') === 'vertical'));

    if (thumbsWrapper) {
      // vertical thumbs
      if (thumbsAreVertical) {
        this.thumbnailSwiper = new Swiper(thumbsWrapper, {
          direction: 'vertical',
          slidesPerView: 'auto',
          freeMode: true,
          spaceBetween: 12,
          watchSlidesVisibility: true,
          watchSlidesProgress: true,
          mousewheel: {
            releaseOnEdges: true
          },
          breakpoints: {
            320: { slidesPerView: Math.max(3, thumbSlides.mobile), spaceBetween: 8 },
            750: { slidesPerView: Math.max(4, thumbSlides.tablet), spaceBetween: 10 },
            989: { slidesPerView: 'auto', spaceBetween: 12 },
          }
        });
      } else {
        // horizontal thumbnails
        this.thumbnailSwiper = new Swiper(thumbsWrapper, {
          direction: thumbsWrapper.dataset.direction || 'horizontal',
          slidesPerView: thumbSlides.desktop,
          freeMode: true,
          spaceBetween: 15,
          watchSlidesVisibility: true,
          watchSlidesProgress: true,
           scrollbar: {
            el: '.swipe-scrollbar',
            draggable: true,
            snapOnRelease: true
          },
          breakpoints: {
            320: { slidesPerView: thumbSlides.mobile, spaceBetween: 10 },
            750: { slidesPerView: thumbSlides.tablet, spaceBetween: 12 },
            989: { slidesPerView: thumbSlides.desktop, spaceBetween: 15 },
          },
        });
      }
    }

    const prevEl = this.querySelector('.gallery-button-prev') || this.querySelector('.swiper-button-prev') || (thumbsWrapper && thumbsWrapper.querySelector('.gallery-button-prev'));
    const nextEl = this.querySelector('.gallery-button-next') || this.querySelector('.swiper-button-next') || (thumbsWrapper && thumbsWrapper.querySelector('.gallery-button-next'));
    const navWrapper = this.querySelector('.swiper_arrows') || this.querySelector('.columns-arrow-left, .columns-arrow-right, .show_slider');

    this.swiperInstance = new Swiper(swiperContainer, {
      direction,
      slidesPerView: mainSlides.desktop,
      speed: 300,
      spaceBetween: 15,
      navigation: {
        nextEl: nextEl,
        prevEl: prevEl,
      },
      thumbs: this.thumbnailSwiper ? { swiper: this.thumbnailSwiper } : undefined,
      breakpoints: {
        320: { slidesPerView: mainSlides.mobile, spaceBetween: 10 },
        750: { slidesPerView: mainSlides.tablet, spaceBetween: 12 },
        989: { slidesPerView: mainSlides.desktop, spaceBetween: 15 },
      },
      on: {
        afterInit: (swiper) => {
          this.toggleArrows(navWrapper, slidesCount, swiper.params.slidesPerView);
          this.syncActiveThumbnail(swiper.realIndex);
        },
        slideChange: (swiper) => {
          this.syncActiveThumbnail(swiper.realIndex);
        },
        resize: (swiper) => {
          this.toggleArrows(navWrapper, slidesCount, swiper.params.slidesPerView);
        }
      }
    });

    if (this.thumbnailSwiper) {
      this.thumbnailSwiper.on('click', (thumbSwiper) => {
        const clickedIndex = thumbSwiper.clickedIndex;
        if (typeof clickedIndex === 'number' && this.swiperInstance) {
          this.swiperInstance.slideTo(clickedIndex);
        }
      });

      if (thumbsAreVertical) {
        this.swiperInstance.on('slideChange', () => {
          const idx = this.swiperInstance.realIndex;
          if (typeof idx === 'number') {
            try {
              this.thumbnailSwiper.slideTo(idx);
            } catch (e) { /* ignore */ }
          }
        });
      }
    }

    this._isInitialized = true;
  }

  syncActiveThumbnail(index) {
    const thumbButtons = this.querySelectorAll('.slider-thumbnails .thumbnail, .thumbnail-list .thumbnail, .thumbnail-list__item .thumbnail');
    if (!thumbButtons || thumbButtons.length === 0) {
      const siblingThumbs = this.parentElement?.querySelectorAll('.gallerythumbnail-slider .slider-thumbnails .thumbnail');
      if (siblingThumbs && siblingThumbs.length) {
        siblingThumbs.forEach(b => b.removeAttribute('aria-current'));
        const active = siblingThumbs[index];
        if (active) {
          active.setAttribute('aria-current', 'true');
          siblingThumbs.forEach(b => b.classList.remove('thumbnail-active'));
          active.classList.add('thumbnail-active');
        }
      }
      return;
    }
    thumbButtons.forEach((btn) => btn.removeAttribute('aria-current'));
    const activeThumb = thumbButtons[index];
    if (activeThumb) {
      activeThumb.setAttribute('aria-current', 'true');
      thumbButtons.forEach(b => b.classList.remove('thumbnail-active'));
      activeThumb.classList.add('thumbnail-active');
    }
  }

  toggleArrows(navWrapper, slidesCount, visibleSlides) {
    if (!navWrapper) return;
    const visible = (typeof visibleSlides === 'number') ? visibleSlides : 1;
    if (slidesCount <= visible) {
      navWrapper.classList.add('no-arrows');
    } else {
      navWrapper.classList.remove('no-arrows');
    }
  }

  handleResize() {
    const newDirection = this.getDirection();
    if (newDirection !== this.currentDirection) {
      this.initSwiper();
    } else {
      this.initSwiper();
    }
  }
}

if (!customElements.get('gallery-slider')) {
  customElements.define('gallery-slider', GallerySlider);
}
