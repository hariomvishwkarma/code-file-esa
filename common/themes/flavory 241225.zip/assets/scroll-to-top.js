document.addEventListener("DOMContentLoaded", () => {

  const scrollBtn = document.querySelector(".scroll-top-btn");
  const btn = document.querySelector(".btn-scroll-top");
  const topArrow = document.querySelector(".top-arrow");

  // Show/hide button on scroll
  window.addEventListener("scroll", function () {
    if (window.scrollY > 350) {
      scrollBtn.classList.remove("hidden");
    } else {
      scrollBtn.classList.add("hidden");
    }
  });

  // Scroll to top + animation
  btn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });

    btn.classList.add("shrink");

    topArrow.style.top = "-100%";

    setTimeout(() => {
      btn.classList.remove("shrink");
      topArrow.style.top = "0";
    }, 500);
  });

});
