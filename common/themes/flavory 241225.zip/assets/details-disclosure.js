class DetailsDisclosure extends HTMLElement {
    constructor() {
        super();
        this.mainDetailsToggle = this.querySelector('details');
        this.content = this.mainDetailsToggle?.querySelector('summary').nextElementSibling;

        this.mainDetailsToggle?.addEventListener('focusout', this.onFocusOut.bind(this));
        this.mainDetailsToggle?.addEventListener('toggle', this.onToggle.bind(this));
    }

    onFocusOut() {
        setTimeout(() => {
            if (!this.contains(document.activeElement)) this.close();
        });
    }

    onToggle() {
        if (!this.animations) this.animations = this.content.getAnimations();

        if (this.mainDetailsToggle.hasAttribute('open')) {
            this.animations.forEach((animation) => animation.play());
        } else {
            this.animations.forEach((animation) => animation.cancel());
        }
    }

    close() {
        this.mainDetailsToggle.removeAttribute('open');
        this.mainDetailsToggle.querySelector('summary').setAttribute('aria-expanded', false);
    }
}

customElements.define('details-disclosure', DetailsDisclosure);

class HeaderMenu extends HTMLElement {
  constructor() {
    super();

    this.header = document.querySelector('.header-wrapper');
    this.menuItem = this.querySelector('.header__menu-item');
    this.megaMenu = this.querySelector('.mega-menu__content');

    this.handleMouseEnter = this.handleMouseEnter.bind(this);
    this.handleMouseLeave = this.handleMouseLeave.bind(this);
  }

  connectedCallback() {
    if (!this.menuItem || !this.megaMenu) return;

    this.menuItem.setAttribute('aria-expanded', 'false');

    this.addEventListener('mouseenter', this.handleMouseEnter);
    this.addEventListener('mouseleave', this.handleMouseLeave);
  }

  handleMouseEnter() {
    this.openMenu();
  }

  handleMouseLeave() {
    this.closeMenu();
  }

  openMenu() {
    this.classList.add('is-open');
    this.megaMenu.setAttribute('data-open', 'true');
    this.menuItem.setAttribute('aria-expanded', 'true');

    if (!this.header) return;

    this.header.preventHide = true;

    if (
      document.documentElement.style.getPropertyValue(
        '--header-bottom-position-desktop'
      ) === ''
    ) {
      document.documentElement.style.setProperty(
        '--header-bottom-position-desktop',
        `${Math.floor(this.header.getBoundingClientRect().bottom)}px`
      );
    }
  }

  closeMenu() {
    this.classList.remove('is-open');
    this.megaMenu.removeAttribute('data-open');
    this.menuItem.setAttribute('aria-expanded', 'false');

    if (this.header) {
      this.header.preventHide = false;
    }
  }
}

customElements.define('header-menu', HeaderMenu);

