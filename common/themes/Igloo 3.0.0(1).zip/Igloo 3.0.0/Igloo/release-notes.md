A update with updated presets names and theme files restructure!

### Changed preset names
- We have updated the Preset name for the theme as following:
- Preset 1 - Igloo (Old Preset name-Cool)
- Preset2- Drift (Old Preset name-Clean)
- Preset3- Bella (Old Preset name-Glow)

### Theme files restructured
- We have changed the theme structure as per the new Theme store redesign requirements.