$(window).ready(linkIndex),
  document.addEventListener("shopify:section:load", linkIndex);
function linkIndex() {
  var nav_link_child = $("#link-navbar-append-holder > .ic-nav-link"),
    block_link_child = $("#block-navbar-append-holder > .ic-block-link");
  nav_link_child.each(function () {
    $(this).attr("data-index", $(this).index());
  }),
    block_link_child.each(function () {
      $(this).attr("data-index", $(this).index());
    });
}
$(window).ready(link_append),
  $(window).resize(link_append),
  document.addEventListener("shopify:section:load", link_append);
function link_append() {
  var link_navbar = $("#link-navbar-append-holder").hasClass("ic-append-md"),
    top_navbar = $("#top-navbar-append-holder").hasClass("ic-append-md"),
    block_navbar = $("#block-navbar-append-holder").hasClass("ic-append-md"),
    nav_link = $(
      "#link-navbar-append-holder > .ic-nav-link:not(.ic-ex-link-md)"
    ),
    top_link = $(
      "#top-navbar-append-holder > .ic-top-link:not(.ic-ex-link-md)"
    ),
    block_link = $(
      "#block-navbar-append-holder > .ic-block-link:not(.ic-ex-link-md)"
    );
  if (window.matchMedia("(max-width: 1023px)").matches && link_navbar == !0)
    nav_link.appendTo("#link-sidebar-append-holder");
  else {
    $("#link-sidebar-append-holder > .ic-nav-link").appendTo(
      "#link-navbar-append-holder"
    );
    var $link_wrapper = $("#link-navbar-append-holder");
    $link_wrapper
      .children(".ic-nav-link")
      .sort(function (a, b) {
        return +a.dataset.index - +b.dataset.index;
      })
      .appendTo($link_wrapper);
  }
  if (window.matchMedia("(max-width: 1023px)").matches && top_navbar == !0) {
    top_link.appendTo("#top-sidebar-append-holder");
    var $top_side_wrapper = $("#top-sidebar-append-holder");
    $top_side_wrapper
      .children(".ic-top-link")
      .sort(function (a, b) {
        return +b.dataset.index - +a.dataset.index;
      })
      .appendTo($top_side_wrapper);
  } else {
    $("#top-sidebar-append-holder > .ic-top-link").appendTo(
      "#top-navbar-append-holder"
    );
    var $top_wrapper = $("#top-navbar-append-holder");
    $top_wrapper
      .children(".ic-top-link")
      .sort(function (a, b) {
        return +a.dataset.index - +b.dataset.index;
      })
      .appendTo($top_wrapper);
  }
  if (window.matchMedia("(max-width: 1023px)").matches && block_navbar == !0)
    block_link.appendTo("#block-sidebar-append-holder");
  else {
    $("#block-sidebar-append-holder > .ic-block-link").appendTo(
      "#block-navbar-append-holder"
    );
    var $block_wrapper = $("#block-navbar-append-holder");
    $block_wrapper
      .children(".ic-block-link")
      .sort(function (a, b) {
        return +a.dataset.index - +b.dataset.index;
      })
      .appendTo($block_wrapper);
  }
  window.matchMedia("(max-width: 1023px)").matches &&
    ($(".ic-block-link").removeAttr("x-link"),
    $(".account-link").removeAttr("x-account"),
    $(".login-link").removeAttr("x-login"));
}
$(function () {
  $(".ic-dropdown-toggle").click(function () {
    $(this).next(".ic-dropdown-menu").slideToggle();
  }),
    $(document).click(function (e) {
      var target = e.target;
      !$(target).is(".ic-dropdown-toggle") &&
        !$(target).parents().is(".ic-dropdown-toggle") &&
        $(".ic-dropdown-menu").slideUp();
    });
}),
  window.addEventListener("DOMContentLoaded", menuToggle),
  document.addEventListener("shopify:section:load", menuToggle);
function menuToggle() {
  $("body").removeClass("menu-overlay"),
    $(".ic-breadcrumb").click(function (event) {
      event.stopPropagation(),
        $(".ic-mobile-sidebar").toggle(),
        $(".ic-breadcrumb").attr("aria-expanded", "true"),
        $(".ic-mobile-sidebar-header .ic-close-icon").attr(
          "aria-expanded",
          "true"
        ),
        $(".menu-close-overlay").attr("aria-expanded", "true"),
        $("body").addClass("menu-overlay");
    }),
    $(".ic-mobile-sidebar-header .ic-close-icon").click(function (event) {
      event.stopPropagation(),
        $(".ic-mobile-sidebar").toggle(),
        $(".ic-breadcrumb").attr("aria-expanded", "false"),
        $(".ic-mobile-sidebar-header .ic-close-icon").attr(
          "aria-expanded",
          "false"
        ),
        $(".menu-close-overlay").attr("aria-expanded", "false"),
        $("body").removeClass("menu-overlay");
    }),
    $(".menu-close-overlay").click(function (event) {
      event.stopPropagation(),
        $(".ic-mobile-sidebar").toggle(),
        $(".ic-breadcrumb").attr("aria-expanded", "false"),
        $(".ic-mobile-sidebar-header .ic-close-icon").attr(
          "aria-expanded",
          "false"
        ),
        $(".menu-close-overlay").attr("aria-expanded", "false"),
        $("body").removeClass("menu-overlay");
    });
  const scrollY = $("body").css("top");
}
$(window).on("DOMContentLoaded resize", handleStickyHeader),
  $(window).on("DOMContentLoaded resize", main_height);
function main_height() {
  var header_group_height = $(".header-group").length
      ? $(".header-group").height()
      : 0,
    footer_group_height = $(".footer-group").length
      ? $(".footer-group").height()
      : 0,
    breadcrumb_height_val = $("#breadcrumbs").length
      ? $("#breadcrumbs").height()
      : 0,
    inner_header_height = $(".ic-header").length
      ? $(".ic-header").outerHeight()
      : 0,
    header_height = $(".transparent-header").length
      ? $(".transparent-header").outerHeight()
      : 0,
    header_top_bar_height = $(".transparent-header .header-top-bar").length
      ? $(".transparent-header .header-top-bar").outerHeight()
      : 0,
    viewport_height = $(window).height();
  if (breadcrumb_height_val) var breadcrumb_height = breadcrumb_height_val;
  else var breadcrumb_height = 0;
  var topAnnouncementHeight = 0;
  $(".header-group > *:not(.skip-link)").each(function () {
    if ($(this).is("header")) return !1;
    var announcementHeight = $(this).outerHeight();
    topAnnouncementHeight += announcementHeight;
  });
  var bottomAnnouncementHeight = 0,
    isBtAnnouncement = !1;
  $(".header-group > *:not(div):not(.skip-link)").each(function () {
    if (isBtAnnouncement) {
      var btannouncementHeight = $(this).outerHeight();
      bottomAnnouncementHeight += btannouncementHeight;
    }
    $(this).is("header") && (isBtAnnouncement = !0);
  }),
    $("body").css("--header-group", header_group_height + "px"),
    $("body").css("--header-top", topAnnouncementHeight + "px"),
    $("body").css("--header-top-bar-height", header_top_bar_height + "px"),
    $("body").css("--inner-header-height", inner_header_height + "px"),
    $("body").css("--header-height", header_height + "px"),
    $("body").css("--header-bottom", bottomAnnouncementHeight + "px");
  var min_height =
    viewport_height -
    header_group_height -
    footer_group_height -
    breadcrumb_height +
    "px";
  $("#MainContent").css("min-height", min_height),
    $(".fill-screen-height").css("--main-height", min_height),
    $(".footer-group").removeAttr("x-footer");
  let lastScrollTop = 0,
    lastScrollDown = 0,
    lastScrollUp = 0,
    lastScrollUpAmount = 0,
    lastScrollUDownAmount = 0,
    headerScrollTop = 0;
  $(window).scrollTop() >
  topAnnouncementHeight + $(".header-top-bar").outerHeight()
    ? (headerScrollTop = 0)
    : (headerScrollTop = topAnnouncementHeight),
    $(window).scroll(function () {
      const currentScrollTop = $(window).scrollTop(),
        headerTopHeight = $(".header-top-bar").length
          ? $(".header-top-bar").outerHeight()
          : 0,
        scrollTopLimit = topAnnouncementHeight + headerTopHeight,
        initialScrollTop = topAnnouncementHeight;
      if (currentScrollTop > lastScrollTop) {
        if (
          ((lastScrollUDownAmount = currentScrollTop - lastScrollUp),
          currentScrollTop <= scrollTopLimit)
        )
          (headerScrollTop = initialScrollTop - currentScrollTop),
            headerScrollTop <= headerTopHeight * -1 &&
              (headerScrollTop = headerTopHeight * -1);
        else {
          const currHeaderScroll =
            (headerTopHeight - lastScrollUpAmount) * -1 - lastScrollUDownAmount;
          headerScrollTop > currHeaderScroll
            ? (headerScrollTop = currHeaderScroll)
            : (headerScrollTop = 0 - lastScrollUDownAmount),
            headerScrollTop <= headerTopHeight * -1 &&
              (headerScrollTop = headerTopHeight * -1);
        }
        lastScrollDown = $(window).scrollTop();
      } else {
        if (
          ((lastScrollUpAmount = lastScrollDown - currentScrollTop),
          currentScrollTop <= scrollTopLimit)
        ) {
          const currHeaderScroll =
            (lastScrollDown - initialScrollTop) * -1 + lastScrollUpAmount;
          headerScrollTop < currHeaderScroll
            ? (headerScrollTop = currHeaderScroll)
            : ((headerScrollTop =
                headerTopHeight * -1 +
                (lastScrollDown - (lastScrollDown - lastScrollUpAmount))),
              headerScrollTop >= 0 && (headerScrollTop = 0)),
            headerScrollTop >= initialScrollTop &&
              (headerScrollTop = initialScrollTop);
        } else {
          const currHeaderScroll =
            0 - lastScrollUDownAmount + lastScrollUpAmount;
          currHeaderScroll >= headerTopHeight * -1
            ? (headerScrollTop = currHeaderScroll)
            : (headerScrollTop = headerTopHeight * -1 + lastScrollUpAmount),
            headerScrollTop >= 0 && (headerScrollTop = 0);
        }
        lastScrollUp = $(window).scrollTop();
      }
      (lastScrollTop = currentScrollTop),
        $("body").css("--fixed-header-top", headerScrollTop + "px");
    });
  let footerContactForm = $("#footerContactForm"),
    passwordContactForm = $("#passwordContactForm");
  $(document).ready(function () {
    window.location.hash === "#footerContactForm" &&
      $("html, body").scrollTop(footerContactForm.offset().top),
      window.location.hash === "#passwordContactForm" &&
        $("html, body").scrollTop(passwordContactForm.offset().top),
      document
        .querySelectorAll(".newsletter-wrapper form")
        .forEach(function (newsLetterForm) {
          let formID = "#" + newsLetterForm.getAttribute("id");
          if (window.location.hash === formID) {
            let htmlBody = document.querySelector("html, body"),
              offset =
                document.querySelector(formID).closest("section").offsetTop -
                header_group_height;
            htmlBody.scrollTo({ top: offset });
          }
        });
  });
  var scrollHeight = 50 + topAnnouncementHeight;
  $(window).scroll(function () {
    $(".fixed-header").data("behavior") == "sticky" &&
      transparentHeaderScroll();
  }),
    document.addEventListener("shopify:section:load", function () {
      $(".fixed-header").data("behavior") == "sticky" &&
        transparentHeaderScroll();
    });
  function transparentHeaderScroll() {
    const transparentHeader = $(".transparent-header"),
      slideBgHeader = $(".transparent-header[data-slide-bg]");
    $(window).scrollTop() >= scrollHeight
      ? (transparentHeader.addClass("scrolled"),
        slideBgHeader
          .children(".content-container")
          .removeClass("text-inherit"),
        slideBgHeader.find(".bottom-menu-content").length > 0 &&
          slideBgHeader
            .find(".bottom-menu-content")
            .removeClass("text-inherit"))
      : (transparentHeader.removeClass("scrolled"),
        slideBgHeader.children(".content-container").addClass("text-inherit"),
        slideBgHeader.find(".bottom-menu-content").length > 0 &&
          slideBgHeader.find(".bottom-menu-content").addClass("text-inherit"));
  }
}
function handleStickyHeader() {
  $(".fixed-header").data("behavior") == "normal" &&
    $(".section-header").removeClass("fixed-header-section");
}
document.addEventListener("shopify:section:load", function (event) {
  handleStickyHeader(),
    main_height(),
    sectionAllowTransparent(),
    $("footer").removeAttr("x-footer");
}),
  document.addEventListener("shopify:section:reorder", function (event) {
    handleStickyHeader(), main_height(), sectionAllowTransparent();
  }),
  $(window).on("DOMContentLoaded", sectionAllowTransparent);
function sectionAllowTransparent() {
  const defaultHeader = $(".ic-header"),
    transparentHeader = $(".transparent-header"),
    sectionHeader = $(".section-header"),
    headerGroup = $(".header-group");
  $(".allow-transparent-header").closest(".shopify-section").is(":first-child")
    ? defaultHeader.hasClass("transparent-header") &&
      (transparentHeader.addClass("section-allow"),
      sectionHeader.addClass("transparent-header-section"),
      headerGroup.addClass("transparent-header-group"),
      $(".allow-transparent-header")
        .closest(".shopify-section:first-child")
        .addClass("section-allow"))
    : (transparentHeader.removeClass("section-allow"),
      sectionHeader.removeClass("transparent-header-section"),
      headerGroup.removeClass("transparent-header-group"));
}
function shareButton() {
  $(".btn--share").on("click", function () {
    $(".social-sharing-wrapper").toggleClass("opened"),
      $(this).attr("aria-expanded") == "false"
        ? $(this).attr("aria-expanded", "true")
        : $(this).attr("aria-expanded", "false");
  }),
    $(document).mouseup(function (e) {
      $(e.target).closest(".social-sharing-wrapper").length === 0 &&
        ($(".social-sharing-wrapper").removeClass("opened"),
        $(".btn--share").attr("aria-expanded", "false")),
        $(e.target).closest(".selectbox").length === 0 &&
          $(".selectbox").removeClass("opened");
    });
}
function LinkCopy() {
  const linkCopyBtnArr = document.querySelectorAll(".link-copy-button");
  for (let i2 = 0; i2 < linkCopyBtnArr.length; i2++)
    linkCopyBtnArr[i2].addEventListener("click", function () {
      var copyText = linkCopyBtnArr[i2]
        .closest(".link-copy")
        .querySelector(".copy-link");
      const textToCopy = copyText.innerText,
        tempInput = document.createElement("input");
      (tempInput.value = textToCopy),
        (tempInput.style.position = "absolute"),
        (tempInput.style.left = "-9999px"),
        document.body.appendChild(tempInput),
        tempInput.select(),
        document.addEventListener("copy", (event) => {
          event.preventDefault(),
            event.clipboardData.setData("text/plain", textToCopy);
        }),
        document.execCommand("copy"),
        document.body.removeChild(tempInput),
        document.querySelector(".copied-message").classList.add("show"),
        setTimeout(() => {
          document.querySelector(".copied-message").classList.remove("show");
        }, 2e3);
    });
}
window.addEventListener("load", shareButton),
  document.addEventListener("shopify:section:load", shareButton),
  window.addEventListener("load", LinkCopy),
  document.addEventListener("shopify:section:load", LinkCopy);
try {
  for (
    var heroSwiper = document.querySelectorAll(".hero-swiper"), i = 0;
    i < video_preview_elements.length;
    i++
  )
    slide_show_count = video_preview_elements.length;
} catch {}
class VariantSelector extends HTMLElement {
  constructor() {
    super(), this.addEventListener("change", this.onVariantChange);
  }
  onVariantChange() {
    this.addLoader(),
      this.getSelectedOptions(),
      this.getSelectedVariant(),
      this.updateVariant(),
      this.updateBuyButton(),
      this.updateURL(),
      this.updateFormID(),
      this.updateProductDetails();
  }
  getSelectedOptions() {
    this.options = Array.from(
      this.querySelectorAll('input[type="radio"]:checked'),
      (select) => select.value
    );
  }
  getVariantJSON() {
    return (
      (this.variantData =
        this.variantData ||
        JSON.parse(
          this.querySelector('[type="application/json"]').textContent
        )),
      this.variantData
    );
  }
  getSelectedVariant() {
    this.currentVariant = this.getVariantJSON().find((variant) => {
      if (
        !variant.options
          .map((option, index) => this.options[index] === option)
          .includes(!1)
      )
        return variant;
    });
  }
  updateURL() {
    this.currentVariant &&
      this.dataset.urlUpdate == "true" &&
      window.history.replaceState(
        {},
        "",
        `${this.dataset.url}?variant=${this.currentVariant.id}`
      );
  }
  updateFormID() {
    if (!this.currentVariant) return;
    const form_inputs = this.closest(".product-form-wrapper").querySelectorAll(
      'input[name="id"]'
    );
    for (let i2 = 0; i2 < form_inputs.length; i2++)
      form_inputs[i2].value = this.currentVariant.id;
  }
  updateProductDetails() {
    let fetchURL = "";
    this.currentVariant
      ? (fetchURL = `${this.dataset.url}?variant=${this.currentVariant.id}&section_id=${this.dataset.section}`)
      : (fetchURL = ""),
      fetch(fetchURL)
        .then((response) => {
          if (response.ok) return response.text();
          throw new Error("Something went wrong");
        })
        .then((responseText) => {
          const html = new DOMParser().parseFromString(
              responseText,
              "text/html"
            ),
            oldSectionId = this.closest(".product-detail").getAttribute("id"),
            oldSection = this.closest(".product-detail"),
            newSection = html.querySelector(`#${oldSectionId}`),
            id = `price-${this.dataset.section}`,
            oldPrice = document.getElementById(id);
          oldPrice.style.opacity = "1";
          const newPrice = html.getElementById(id);
          oldPrice && newPrice && (oldPrice.innerHTML = newPrice.innerHTML);
          const buttonId = `buy-${this.dataset.section}`,
            oldButtons = document.getElementById(buttonId),
            oldQuantityId = `quantity-${this.dataset.section}`,
            oldQuantityContainer = document
              .getElementById(oldQuantityId)
              .closest(".quantity-container"),
            oldQuantityPlus =
              oldQuantityContainer.querySelector(".quantity-btn.plus"),
            oldQuantityMinus = oldQuantityContainer.querySelector(
              ".quantity-btn.minus"
            ),
            oldQuantityInput = document.getElementById(oldQuantityId),
            newButtons = html.getElementById(buttonId),
            buy_buttons = oldButtons.querySelectorAll("button");
          if (this.currentVariant.available) {
            if (this.currentVariant.available) {
              for (let i2 = 0; i2 < buy_buttons.length; i2++)
                (buy_buttons[i2].disabled = !1),
                  buy_buttons[i2].getAttribute("name") == "add" &&
                    (buy_buttons[i2].innerHTML =
                      window.variantStrings.addToCart);
              oldQuantityContainer.classList.remove("disabled"),
                (oldQuantityPlus.disabled = !1),
                (oldQuantityMinus.disabled = !1),
                (oldQuantityInput.disabled = !1);
            }
          } else {
            for (let i2 = 0; i2 < buy_buttons.length; i2++)
              (buy_buttons[i2].disabled = !0),
                buy_buttons[i2].getAttribute("name") == "add" &&
                  (buy_buttons[i2].innerHTML = window.variantStrings.soldOut);
            oldQuantityContainer.classList.add("disabled"),
              (oldQuantityPlus.disabled = !0),
              (oldQuantityMinus.disabled = !0),
              (oldQuantityInput.disabled = !0);
          }
          const oldRadioElement = this.querySelectorAll('input[type="radio"]'),
            newRadioElement = html
              .querySelector("variant-selector")
              .querySelectorAll('input[type="radio"]');
          for (let i2 = 0; i2 < newRadioElement.length; i2++)
            newRadioElement[i2]
              .closest(".radio-container")
              .classList.contains("unavailable")
              ? oldRadioElement[i2]
                  .closest(".radio-container")
                  .classList.add("unavailable")
              : oldRadioElement[i2]
                  .closest(".radio-container")
                  .classList.remove("unavailable");
          const oldSku = oldSection.querySelector(".variant-sku"),
            skuWrapper = oldSection.querySelector(".sku-wrapper"),
            newSku = newSection.querySelector(".variant-sku");
          oldSku && newSku
            ? (oldSku.innerHTML = newSku.innerHTML)
            : !oldSku && newSku
            ? skuWrapper.append(newSku)
            : !newSku && oldSku && oldSku.remove();
          const mediaId = `media-${this.dataset.section}`,
            oldMedia = document.getElementById(mediaId);
          if (!oldMedia.classList.contains("em-vdapp--initiated")) {
            const newMedia = html.getElementById(mediaId);
            oldMedia && newMedia && (oldMedia.innerHTML = newMedia.innerHTML),
              productSectionSlider(),
              thumbProductModel(),
              shopifyXr(),
              cleanUpVideoPlayers(),
              videoPlayerInitialise(`#${mediaId}`);
          }
          const shareId = ".product_feature",
            oldShare = oldSection.querySelector(shareId),
            newShare = newSection.querySelector(shareId);
          oldShare && newShare && (oldShare.innerHTML = newShare.innerHTML),
            shareButton(),
            LinkCopy();
          const inventoryId = `inventory-${this.dataset.section}`,
            inventoryWrapper = document.getElementById(
              `inventory-wrapper-${this.dataset.section}`
            ),
            oldInventory = document.getElementById(inventoryId);
          oldInventory && (oldInventory.style.visibility = "visible");
          const newInventory = html.getElementById(inventoryId);
          oldInventory && newInventory
            ? (oldInventory.innerHTML = newInventory.innerHTML)
            : !oldInventory && newInventory
            ? inventoryWrapper.append(newInventory)
            : !newInventory && oldInventory && oldInventory.remove();
          const oldVariantCartCountEl =
              oldSection.querySelector("[data-cart-count]"),
            newVariantCartCount = newSection
              .querySelector("[data-cart-count]")
              .getAttribute("data-cart-count");
          oldVariantCartCountEl.setAttribute(
            "data-cart-count",
            newVariantCartCount
          );
          const quantityId = `quantity-${this.dataset.section}`,
            oldQuantity = document.getElementById(quantityId),
            oldFormInput = oldSection.querySelector(
              'input[name="quantity"][type="hidden"]'
            ),
            oldMaxQuantity = oldQuantity.getAttribute("max"),
            newQuantity_el = html.getElementById(quantityId),
            newQuantity = newQuantity_el.hasAttribute("max");
          newQuantity &&
            oldQuantity.setAttribute("max", newQuantity_el.getAttribute("max")),
            newQuantity || oldQuantity.removeAttribute("max"),
            newQuantity &&
              oldQuantity.value * 1 > newQuantity_el.getAttribute("max") * 1 &&
              ((oldQuantity.value = newQuantity_el.getAttribute("max")),
              (oldFormInput.value = newQuantity_el.getAttribute("max"))),
            hidequantityError(oldSection),
            hideAddToCartError(oldSection);
          const oldVariantAvailabilityEl = oldSection.querySelector(
              "[data-availibility]"
            ),
            newVariantAvailability = newSection
              .querySelector("[data-availibility]")
              .getAttribute("data-availibility");
          oldVariantAvailabilityEl.setAttribute(
            "data-availibility",
            newVariantAvailability
          );
          const pickupId = `pickup-${this.dataset.section}`,
            wrapperId = `pickup-wrapper-${this.dataset.section}`,
            pickupWrapper = document.getElementById(wrapperId),
            oldPickup = document.getElementById(pickupId);
          oldPickup && (pickupWrapper.style.display = "block");
          const newPickup = html.getElementById(pickupId);
          oldPickup && newPickup
            ? (oldPickup.innerHTML = newPickup.innerHTML)
            : !oldPickup && newPickup
            ? pickupWrapper.append(newPickup)
            : !newPickup && oldPickup && oldPickup.remove();
          const pickupLocationId = `pickup-location-${this.dataset.section}`,
            locationWrapperId = `pickup-location-wrapper-${this.dataset.section}`,
            pickupLocationWrapper = document.getElementById(locationWrapperId),
            oldPickupLocation = document.getElementById(pickupLocationId),
            newPickupLocation = html.getElementById(pickupLocationId);
          oldPickupLocation && newPickupLocation
            ? (oldPickupLocation.innerHTML = newPickupLocation.innerHTML)
            : !oldPickupLocation && newPickupLocation
            ? pickupLocationWrapper.append(newPickupLocation)
            : !newPickupLocation &&
              oldPickupLocation &&
              oldPickupLocation.remove(),
            this.removeLoader();
        })
        .catch((error) => {
          console.log(error);
          const id = `price-${this.dataset.section}`,
            oldPrice = document.getElementById(id);
          oldPrice.style.opacity = "0.5";
          const inventoryId = `inventory-${this.dataset.section}`,
            oldInventory = document.getElementById(inventoryId);
          oldInventory && (oldInventory.style.visibility = "hidden");
          const pickupId = `pickup-${this.dataset.section}`,
            wrapperId = `pickup-wrapper-${this.dataset.section}`,
            pickupWrapper = document.getElementById(wrapperId);
          document.getElementById(pickupId) &&
            (pickupWrapper.style.display = "none"),
            this.removeLoader();
        });
  }
  updateVariant() {
    const radio_element = this.querySelectorAll('input[type="radio"]');
    for (let i2 = 0; i2 < radio_element.length; i2++) {
      radio_element[i2].checked
        ? (radio_element[i2].setAttribute("checked", "checked"),
          radio_element[i2].closest(".radio-container").classList.add("active"),
          (radio_element[i2]
            .closest(".option-group")
            .querySelector(".option-label span").innerHTML =
            radio_element[i2].value))
        : (radio_element[i2].removeAttribute("checked"),
          radio_element[i2]
            .closest(".radio-container")
            .classList.remove("active"));
      let currentVariantTitle = "";
      this.options.map((option, index) => {
        index != 0 && (currentVariantTitle += " / "),
          radio_element[i2].closest(".option-group").dataset.option == index + 1
            ? (currentVariantTitle += radio_element[i2].value)
            : (currentVariantTitle += option);
      });
      for (let j = 0; j < this.variantData.length; j++) {
        let variant = this.variantData[j];
        if (variant.title == currentVariantTitle) {
          radio_element[i2]
            .closest(".radio-container")
            .classList.remove("unavailable"),
            variant.available
              ? radio_element[i2]
                  .closest(".radio-container")
                  .classList.remove("sold-out")
              : radio_element[i2]
                  .closest(".radio-container")
                  .classList.add("sold-out");
          break;
        } else
          radio_element[i2]
            .closest(".radio-container")
            .classList.add("unavailable");
      }
    }
  }
  updateBuyButton() {
    const updatedButtonId = `buy-${this.dataset.section}`,
      updateOldButtons = document.getElementById(updatedButtonId),
      oldQuantityId = `quantity-${this.dataset.section}`,
      oldQuantityContainer = document
        .getElementById(oldQuantityId)
        .closest(".quantity-container"),
      oldQuantityPlus =
        oldQuantityContainer.querySelector(".quantity-btn.plus"),
      oldQuantityMinus = oldQuantityContainer.querySelector(
        ".quantity-btn.minus"
      ),
      oldQuantityInput = document.getElementById(oldQuantityId),
      updateUnavailableButton = updateOldButtons.querySelectorAll("button"),
      activeOptions = this.querySelectorAll('input[type="radio"][checked]');
    let variantNotAvailable = !1;
    for (let i2 = 0; i2 < activeOptions.length; i2++)
      activeOptions[i2]
        .closest(".radio-container")
        .classList.contains("unavailable") && (variantNotAvailable = !0);
    if (variantNotAvailable) {
      const updateBuyButtons = updateOldButtons.querySelectorAll("button");
      for (let i2 = 0; i2 < updateBuyButtons.length; i2++)
        (updateBuyButtons[i2].disabled = !0),
          updateBuyButtons[i2].getAttribute("name") == "add" &&
            (updateBuyButtons[i2].innerHTML =
              window.variantStrings.unavailable);
      oldQuantityContainer.classList.add("disabled"),
        (oldQuantityPlus.disabled = !0),
        (oldQuantityMinus.disabled = !0),
        (oldQuantityInput.disabled = !0);
    }
  }
  addLoader() {
    let loaderWrappers =
      this.closest(".product-detail").querySelectorAll(".load-wrapper");
    for (let i2 = 0; i2 < loaderWrappers.length; i2++)
      loaderWrappers[i2].setAttribute("data-loading", "loading");
  }
  removeLoader() {
    let loaderWrappers =
      this.closest(".product-detail").querySelectorAll(".load-wrapper");
    for (let i2 = 0; i2 < loaderWrappers.length; i2++)
      loaderWrappers[i2].removeAttribute("data-loading");
  }
}
customElements.define("variant-selector", VariantSelector),
  window.addEventListener("DOMContentLoaded", function () {
    cloneScrollingText();
  }),
  window.addEventListener("resize", function () {
    cloneScrollingText();
  }),
  document.addEventListener("shopify:section:load", function () {
    cloneScrollingText();
  });
function cloneScrollingText() {
  const scrollingSections = document.querySelectorAll(
    ".scrollign-text-section"
  );
  for (let i2 = 0; i2 < scrollingSections.length; i2++) {
    const scrollingSection = scrollingSections[i2],
      scrollingWrapper =
        scrollingSections[i2].querySelector(".scrolling-wrapper");
    scrollingWrapper.classList.add("no-scrolling");
    const scrollingText = scrollingSections[i2].querySelector(
      ".scrolling-text-wrapper"
    );
    scrollingText
      ? (calculateAnimationDuration(scrollingWrapper, scrollingText),
        duplicateText(scrollingWrapper, scrollingText))
      : scrollingWrapper.classList.remove("no-scrolling");
  }
}
function duplicateText(scrollingWrapper, scrollingText) {
  const screenWidth = window.innerWidth,
    scrollingTextWidth = scrollingText.offsetWidth,
    duplicatesNeeded = Math.ceil(screenWidth / scrollingTextWidth);
  for (let i2 = 0; i2 < duplicatesNeeded; i2++) {
    const duplicatedText = scrollingText.cloneNode(!0);
    if (i2 == 0) {
      scrollingWrapper.replaceChildren(duplicatedText);
      continue;
    }
    duplicatedText.setAttribute("aria-hidden", !0),
      scrollingWrapper.appendChild(duplicatedText);
  }
  const additionalDuplicatedText = scrollingText.cloneNode(!0);
  additionalDuplicatedText.setAttribute("aria-hidden", !0),
    scrollingWrapper.appendChild(additionalDuplicatedText),
    scrollingWrapper.classList.remove("no-scrolling");
}
function calculateAnimationDuration(scrollingWrapper, scrollingText) {
  const wrapperWidth = scrollingWrapper.offsetWidth,
    animationSpeed = scrollingWrapper.getAttribute("animation-duration");
  let animationDuration = scrollingText.offsetWidth / wrapperWidth;
  window.innerWidth >= 1280
    ? (animationDuration *= animationSpeed * 2)
    : window.innerWidth >= 1024 && window.innerWidth <= 1279
    ? (animationDuration *= animationSpeed * 1.5)
    : window.innerWidth >= 768 && window.innerWidth <= 1023
    ? (animationDuration *= animationSpeed * 1)
    : window.innerWidth <= 767 && (animationDuration *= animationSpeed * 0.5),
    scrollingWrapper.style.setProperty(
      "--animation-duration",
      `${animationDuration}s`
    );
}
document.addEventListener("DOMContentLoaded", productSectionSlider),
  document.addEventListener("shopify:section:load", productSectionSlider);
function productSectionSlider() {
  document
    .querySelectorAll(".product-medias")
    .forEach((productSectionSlider2) => {
      const section = "#" + productSectionSlider2.id;
      productSlider(section);
    });
}
function productSlider(section) {
  let thumbSwiper = section + " .thumb-swiper",
    mainSwiper = section + " .main-swiper",
    swiperPrev = document.querySelector(
      `${mainSwiper} ~ button.main-swiper-prev`
    ),
    swiperNext = document.querySelector(
      `${mainSwiper} ~ button.main-swiper-next`
    );
  try {
    let swiperNavDisplay2 = function () {
      window.innerWidth <= 767
        ? (swiper_main.isEnd
            ? swiperNext.classList.remove("show")
            : swiperNext.classList.add("show"),
          swiper_main.isBeginning
            ? swiperPrev.classList.remove("show")
            : swiperPrev.classList.add("show"))
        : (swiperNext?.classList.remove("show"),
          swiperPrev?.classList.remove("show"));
    };
    var swiperNavDisplay = swiperNavDisplay2,
      swiper = new Swiper(thumbSwiper, {
        direction: "horizontal",
        loop: !1,
        spaceBetween: 20,
        slidesPerView: 3,
        allowTouchMove: !0,
        autoHeight: !0,
        navigation: !1,
        breakpoints: {
          568: { slidesPerView: 4 },
          768: { slidesPerView: 4 },
          1024: { slidesPerView: 5 },
        },
        on: {
          init: function () {
            $(thumbSwiper).removeAttr("x-swiper");
          },
        },
        a11y: {
          slideLabelMessage: `${window.slideLabels.goTo} {{index}}`,
          itemRoleDescriptionMessage: `${window.slideLabels.slide}`,
        },
      }),
      swiper_main = new Swiper(mainSwiper, {
        loop: !1,
        spaceBetween: 58,
        allowTouchMove: !1,
        autoHeight: !0,
        thumbs: { swiper },
        navigation: {
          nextEl: ".main-swiper-next",
          prevEl: ".main-swiper-prev",
        },
        breakpoints: { 1281: { allowTouchMove: !0 } },
        on: {
          init: function () {
            $(mainSwiper).removeAttr("x-swiper"),
              window.innerWidth <= 767 &&
                (this.slides.length > 1
                  ? (swiperPrev.classList.remove("show"),
                    swiperNext.classList.add("show"))
                  : (swiperPrev.classList.remove("show"),
                    swiperNext.classList.remove("show")),
                swiperPrev.addEventListener("click", () => {
                  swiper_main.slidePrev();
                }),
                swiperNext.addEventListener("click", () => {
                  swiper_main.slideNext();
                }));
          },
          reachEnd: function () {
            window.innerWidth <= 767 &&
              (swiperPrev.classList.add("show"),
              swiperNext.classList.remove("show"));
          },
          reachBeginning: function () {
            window.innerWidth <= 767 &&
              (swiperPrev.classList.remove("show"),
              swiperNext.classList.add("show"));
          },
          slideChange: function () {
            window.innerWidth <= 767 &&
              (swiper_main.isEnd
                ? swiperNext.classList.remove("show")
                : swiperNext.classList.add("show"),
              swiper_main.isBeginning
                ? swiperPrev.classList.remove("show")
                : swiperPrev.classList.add("show"));
          },
          slideChangeTransitionEnd: () => activeProductModel(swiper_main),
        },
        a11y: {
          slideLabelMessage: `${window.slideLabels.item} {{index}}`,
          itemRoleDescriptionMessage: `${window.slideLabels.slide}`,
        },
      });
    window.addEventListener("resize", swiperNavDisplay2);
    var thumbSlides = document.querySelectorAll(thumbSwiper + " .swiper-slide");
    for (let i2 = 0; i2 < thumbSlides.length; i2++)
      thumbSlides[i2].addEventListener("keydown", function (event) {
        if (event.key === "Enter" && this === document.activeElement) {
          var slideIndex = Array.prototype.indexOf.call(
            this.parentNode.children,
            this
          );
          swiper.slideTo(slideIndex), swiper_main.slideTo(slideIndex);
        }
      });
  } catch (e) {
    console.log("Swiper JS is not defined", e);
  }
  setImageZoom(),
    swiper_main.on("transitionEnd", function () {
      var tarnsitionActiveSlide = document.querySelector(
        thumbSwiper + " .swiper-slide-thumb-active"
      );
    });
  function setImageZoom() {
    var ImageZoomElWrapper = document.querySelectorAll(
      mainSwiper + " .swiper-slide"
    );
    for (let i2 = 0; i2 < ImageZoomElWrapper.length; i2++) {
      var imageZoomEl = ImageZoomElWrapper[i2].querySelector(".zoom-wrapper");
      if (imageZoomEl) {
        var imageZoomUrl = imageZoomEl
          .querySelector("img")
          .getAttribute("data-zoom");
        typeof $(imageZoomEl).zoom == "function"
          ? $(imageZoomEl).zoom({
              url: imageZoomUrl,
              magnify: 1.25,
              onZoomIn: function () {
                var mainImage = this.parentNode.querySelector("[data-zoom]");
                mainImage.style.opacity = "0";
              },
              onZoomOut: function () {
                var mainImage = this.parentNode.querySelector("[data-zoom]");
                mainImage.style.opacity = "1";
              },
            })
          : console.error("Zoom function is not available.");
      }
    }
  }
}
function activeProductModel(productSwiper) {
  let productSwiperEl = productSwiper.el,
    firstModelID = productSwiperEl.dataset.firstModel,
    modelXrButton = productSwiperEl.querySelector(".btn-xr"),
    activeModel = productSwiperEl
      .querySelector(".swiper-slide-active")
      .querySelector("product-model");
  if (activeModel) {
    let modelMediaID = activeModel.dataset.mediaId;
    modelXrButton.setAttribute("data-shopify-model3d-id", modelMediaID);
  } else
    firstModelID != "" &&
      modelXrButton.setAttribute("data-shopify-model3d-id", firstModelID);
}
document.addEventListener("DOMContentLoaded", sectionSlider),
  document.addEventListener("shopify:section:load", sectionSlider);
function sectionSlider() {
  const featureSliders = document.querySelectorAll(
    ".featured-collection-slider"
  );
  for (let i2 = 0; i2 < featureSliders.length; i2++) {
    const section = "#" + featureSliders[i2].id;
    collectionSlider(section);
  }
}
function collectionSlider(section) {
  try {
    let swiper = new Swiper(section, {
      spaceBetween: 20,
      slidesPerView: 1,
      allowTouchMove: !0,
      navigation: { prevEl: ".slider-btn-prev", nextEl: ".slider-btn-next" },
      clickable: !0,
      breakpoints: {
        568: { slidesPerView: 2 },
        768: { slidesPerView: 1 },
        1024: { slidesPerView: 2 },
        1280: { slidesPerView: 3 },
        1536: { slidesPerView: 4 },
      },
      on: {
        init: function () {
          $(section).removeAttr("x-swiper");
        },
      },
    });
  } catch (e) {
    console.log("Swiper JS is not defined"), console.log(e);
  }
}
window.addEventListener("resize", collectionSectionSlider),
  document.addEventListener("DOMContentLoaded", collectionSectionSlider),
  document.addEventListener("shopify:section:load", collectionSectionSlider);
function collectionSectionSlider() {
  const featureSliders = document.querySelectorAll(".collection-list-slider");
  for (let i2 = 0; i2 < featureSliders.length; i2++) {
    const featureSlider = featureSliders[i2],
      section = "#" + featureSlider.id,
      prevBtn = featureSlider
        .closest(".collection-slider-container")
        .querySelector(".slider-btn-prev"),
      nextBtn = featureSlider
        .closest(".collection-slider-container")
        .querySelector(".slider-btn-next"),
      dtSlides = featureSlider.dataset.desktopSlides,
      sdtSlides = featureSlider.dataset.smalldesktopSlides,
      ltSlides = featureSlider.dataset.laptopSlides,
      tbSlides = featureSlider.dataset.tabletSlides,
      mbSlides = featureSlider.dataset.mobileSlides,
      slideAlignment = featureSlider.dataset.itemAlign,
      slidesLength = featureSlider.querySelectorAll(".swiper-slide").length,
      swiperWrapper = featureSlider.querySelector(".swiper-wrapper");
    let screenWidth = window.innerWidth,
      slidesShown;
    switch (!0) {
      case screenWidth >= 520 && screenWidth < 768:
        slidesShown = mbSlides;
        break;
      case screenWidth >= 768 && screenWidth < 1024:
        slidesShown = tbSlides;
        break;
      case screenWidth >= 1024 && screenWidth < 1280:
        slidesShown = ltSlides;
        break;
      case screenWidth >= 1280 && screenWidth < 1536:
        slidesShown = sdtSlides;
        break;
      case screenWidth >= 1536:
        slidesShown = dtSlides;
        break;
      default:
        slidesShown = 1;
    }
    slidesLength < slidesShown && slideAlignment == "item-center"
      ? swiperWrapper.classList.add("slides-center")
      : swiperWrapper.classList.remove("slides-center"),
      collectionListSlider(
        section,
        prevBtn,
        nextBtn,
        dtSlides,
        sdtSlides,
        ltSlides,
        tbSlides,
        mbSlides
      );
  }
}
function collectionListSlider(
  section,
  prevBtn,
  nextBtn,
  dtSlides,
  sdtSlides,
  ltSlides,
  tbSlides,
  mbSlides
) {
  try {
    let swiper = new Swiper(section, {
      spaceBetween: 20,
      slidesPerView: 1,
      allowTouchMove: !0,
      navigation: { prevEl: prevBtn, nextEl: nextBtn },
      clickable: !0,
      breakpoints: {
        520: { slidesPerView: mbSlides },
        768: { slidesPerView: tbSlides },
        1024: { slidesPerView: ltSlides },
        1280: { slidesPerView: sdtSlides },
        1536: { slidesPerView: dtSlides },
      },
      on: {
        init: function () {
          $(section).removeAttr("x-swiper");
        },
      },
    });
  } catch (e) {
    console.log("Swiper JS is not defined"), console.log(e);
  }
}
document.addEventListener("DOMContentLoaded", slideshowSectionSlider),
  document.addEventListener("shopify:section:load", slideshowSectionSlider),
  document.addEventListener("shopify:section:reorder", slideshowSectionSlider);
function slideshowSectionSlider() {
  const slideshows = document.querySelectorAll(".hero-swiper");
  for (let i2 = 0; i2 < slideshows.length; i2++) {
    const slideshow = slideshows[i2],
      autoplayToggle = slideshows[i2].querySelector(".autoplay-toggle"),
      section = "#" + slideshow.id;
    let slideshowAutoplay;
    slideshow.classList.contains("autoplay")
      ? (slideshowAutoplay = !0)
      : (slideshowAutoplay = !1);
    const initSlideshow = slideshow.swiper;
    initSlideshow && slideShowBg(slideshow),
      initSlideshow == null &&
        (slideshowSlider(section, slideshowAutoplay),
        autoplayToggle &&
          autoplayToggle.addEventListener("click", function () {
            const slideshowEl = this.closest(".swiper"),
              playIcon = this.querySelector(".play-icon"),
              pauseIcon = this.querySelector(".pause-icon");
            slideshowEl.swiper.autoplay.running
              ? (slideshowEl.swiper.autoplay.stop(),
                pauseIcon.classList.add("ic-display-none"),
                playIcon.classList.remove("ic-display-none"))
              : (slideshowEl.swiper.autoplay.start(),
                playIcon.classList.add("ic-display-none"),
                pauseIcon.classList.remove("ic-display-none"));
          }),
        slideShowBg(slideshow),
        slideshow.swiper.on("slideChangeTransitionEnd", function () {
          const activeSlideIndex = slideshow.swiper.activeIndex,
            activeSlide = slideshow.swiper.slides[activeSlideIndex],
            activeSlideBg =
              activeSlide.querySelector(".hero-container").dataset.bg,
            slideOuterBg =
              slideshow.closest(".slideshow-wrapper").dataset.outerBg,
            activeSlideColorScheme =
              activeSlide.querySelector(".hero-container").dataset.colorScheme;
          slideshow.setAttribute("data-bg-active", activeSlideBg);
          const slideshowClasses = slideshow.classList;
          for (let i3 = 0; i3 < slideshowClasses.length; i3++)
            slideshowClasses[i3].includes("color-scheme")
              ? slideshowClasses[i3] != activeSlideColorScheme &&
                (slideshow.classList.remove(slideshowClasses[i3]),
                slideshow.classList.add(activeSlideColorScheme))
              : slideshow.classList.add(activeSlideColorScheme);
          const parentContainer = slideshow.parentElement,
            parentSection = parentContainer.closest(".slideshow-section"),
            transparentHeader = document.querySelector(".transparent-header"),
            transparentHeaderSection = parentContainer.classList.contains(
              "allow-transparent-header"
            ),
            transparentHeaderFullSection = parentContainer.classList.contains(
              "full-width-slideshow"
            );
          transparentHeader && transparentHeaderSection
            ? parentSection.parentElement.firstElementChild === parentSection &&
              (transparentHeaderFullSection
                ? transparentHeader.setAttribute("data-slide-bg", activeSlideBg)
                : transparentHeader.setAttribute("data-slide-bg", slideOuterBg))
            : transparentHeader &&
              !transparentHeader.classList.contains("section-allow") &&
              transparentHeader.removeAttribute("data-slide-bg");
        }));
  }
}
function slideshowSlider(section, slideshowAutoplay) {
  try {
    let swiper = new Swiper(section, {
      navigation: { prevEl: ".slider-prev", nextEl: ".slider-next" },
      pagination: { el: ".slider-pagination", type: "bullets", clickable: !0 },
      autoplay: { enabled: slideshowAutoplay, disableOnInteraction: !1 },
      loop: !0,
      observer: !0,
    });
  } catch (e) {
    console.log("Swiper JS is not defined"), console.log(e);
  }
}
function slideShowBg(slideshow) {
  const firstSlideIndex = slideshow.swiper.activeIndex,
    firstSlide = slideshow.swiper.slides[firstSlideIndex],
    firstSlideBg = firstSlide.querySelector(".hero-container").dataset.bg,
    slideOuterBg = slideshow.closest(".slideshow-wrapper").dataset.outerBg,
    firstSlideColorScheme =
      firstSlide.querySelector(".hero-container").dataset.colorScheme,
    parentContainer = slideshow.parentElement,
    parentSection = parentContainer.closest(".slideshow-section"),
    transparentHeader = document.querySelector(".transparent-header"),
    transparentHeaderSection = parentContainer.classList.contains(
      "allow-transparent-header"
    ),
    transparentHeaderFullSection = parentContainer.classList.contains(
      "full-width-slideshow"
    );
  transparentHeader &&
    transparentHeaderSection &&
    (transparentHeader
      .querySelector(".content-container")
      .classList.add("text-inherit"),
    transparentHeader &&
      transparentHeader.querySelector(".bottom-menu-content") &&
      transparentHeader
        .querySelector(".bottom-menu-content")
        .classList.add("text-inherit"),
    parentSection.parentElement.firstElementChild === parentSection
      ? transparentHeaderFullSection
        ? transparentHeader.setAttribute("data-slide-bg", firstSlideBg)
        : transparentHeader.setAttribute("data-slide-bg", slideOuterBg)
      : transparentHeader &&
        !transparentHeader.classList.contains("section-allow") &&
        transparentHeader.removeAttribute("data-slide-bg")),
    slideshow.setAttribute("data-bg-active", firstSlideBg);
  const slideshowClasses = slideshow.classList;
  for (let i2 = 0; i2 < slideshowClasses.length; i2++)
    slideshowClasses[i2].includes("color-scheme")
      ? slideshowClasses[i2] != firstSlideColorScheme &&
        (slideshow.classList.remove(slideshowClasses[i2]),
        slideshow.classList.add(firstSlideColorScheme))
      : slideshow.classList.add(firstSlideColorScheme);
}
window.addEventListener("load", function () {
  setBanner();
}),
  window.addEventListener("resize", function () {
    setBanner();
  }),
  document.addEventListener("shopify:section:load", function () {
    setBanner();
  }),
  document.addEventListener("shopify:section:reorder", function () {
    setBanner();
  });
function setBanner() {
  const bannerWrapper = document.querySelectorAll(".banner-wrapper");
  for (let i2 = 0; i2 < bannerWrapper.length; i2++) {
    const bannerWrapperInner =
        bannerWrapper[i2].querySelector(".inner-container"),
      aspectRatioDecimal = bannerWrapper[i2].dataset.ratio * 1,
      elementId = bannerWrapper[i2];
    setBannerHeight(bannerWrapperInner, aspectRatioDecimal, elementId);
    const parentContainer = bannerWrapper[i2].parentElement,
      bannerBg = parentContainer.parentElement.dataset.bg,
      parentSection = parentContainer.closest(".banner-section"),
      transparentHeader = document.querySelector(".transparent-header"),
      transparentHeaderSection = parentContainer.classList.contains(
        "allow-transparent-header"
      );
    transparentHeader && transparentHeaderSection
      ? parentSection.parentElement.firstElementChild === parentSection &&
        transparentHeader.setAttribute("data-slide-bg", bannerBg)
      : transparentHeader &&
        !transparentHeader.classList.contains("section-allow") &&
        transparentHeader.removeAttribute("data-slide-bg");
  }
}
function setBannerHeight(bannerWrapperInner, aspectRatioDecimal, elementId) {
  const height = calculateHeightPixels(aspectRatioDecimal, elementId);
  bannerWrapperInner.style.minHeight = height + "px";
}
function calculateHeightPixels(aspectRatioDecimal, elementId) {
  const widthElement = elementId.getBoundingClientRect().width;
  return Math.round(widthElement / aspectRatioDecimal);
}
document.addEventListener("DOMContentLoaded", sectionBeforeAfter),
  document.addEventListener("shopify:section:load", sectionBeforeAfter);
function sectionBeforeAfter() {
  const beforeAfterSections = document.querySelectorAll(
    ".before-after-section"
  );
  for (let i2 = 0; i2 < beforeAfterSections.length; i2++) {
    let beforeAfterScrollIt2 = function (percentage) {
      let transform = Math.max(0, Math.min(percentage, 100));
      beforeAFterContainer.style.setProperty("--before-after", transform + "%");
    };
    var beforeAfterScrollIt = beforeAfterScrollIt2;
    const beforeAFterSection = beforeAfterSections[i2],
      beforeAFterContainer = beforeAFterSection.querySelector(
        ".before-after-container"
      ),
      revealer = beforeAFterSection.querySelector(".revealer");
    let scrolling = !1;
    revealer.addEventListener("mousedown", function () {
      (scrolling = !0), revealer.classList.add("scrolling");
    }),
      document.body.addEventListener("mouseup", function () {
        (scrolling = !1), revealer.classList.remove("scrolling");
      }),
      document.body.addEventListener("mouseleave", function () {
        (scrolling = !1), revealer.classList.remove("scrolling");
      }),
      document.body.addEventListener("mousemove", function (e) {
        if (!scrolling) return;
        let x = e.pageX;
        x -= beforeAFterContainer.getBoundingClientRect().left;
        let percentage = (x / beforeAFterContainer.offsetWidth) * 100;
        beforeAfterScrollIt2(percentage);
      }),
      (initialRevealerPosition = beforeAFterContainer.dataset.initialDrag),
      beforeAfterScrollIt2(initialRevealerPosition),
      revealer.addEventListener("touchstart", function (event) {
        event.preventDefault(),
          (scrolling = !0),
          revealer.classList.add("scrolling");
      }),
      revealer.addEventListener("touchend", function () {
        (scrolling = !1), revealer.classList.remove("scrolling");
      }),
      revealer.addEventListener("touchcancel", function () {
        (scrolling = !1), revealer.classList.remove("scrolling");
      }),
      revealer.addEventListener("touchmove", function (e) {
        if (!scrolling) return;
        let x = e.touches[0].pageX;
        x -= beforeAFterContainer.getBoundingClientRect().left;
        let percentage = (x / beforeAFterContainer.offsetWidth) * 100;
        beforeAfterScrollIt2(percentage);
      });
  }
}
document.addEventListener("DOMContentLoaded", setCountDown),
  document.addEventListener("shopify:section:load", setCountDown);
function setCountDown() {
  const countDowns = document.querySelectorAll(".count-down-section");
  for (let i2 = 0; i2 < countDowns.length; i2++) {
    const countDown = countDowns[i2],
      countDownData = countDown.querySelector(".count-down-data"),
      inputMonth = countDownData.dataset.month,
      inputDate = countDownData.dataset.date,
      inputYear = countDownData.dataset.year,
      countDownDate = new Date(inputYear, inputMonth - 1, inputDate).getTime(),
      current = new Date().getTime();
    if (countDownDate >= current) {
      const myfunc = setInterval(function () {
        const now = new Date().getTime(),
          timeleft = countDownDate - now,
          days = Math.floor(timeleft / (1e3 * 60 * 60 * 24)),
          hours = Math.floor(
            (timeleft % (1e3 * 60 * 60 * 24)) / (1e3 * 60 * 60)
          ),
          minutes = Math.floor((timeleft % (1e3 * 60 * 60)) / (1e3 * 60)),
          seconds = Math.floor((timeleft % (1e3 * 60)) / 1e3),
          dayField = countDown.querySelector('[data-type="days"]'),
          hourField = countDown.querySelector('[data-type="hours"]'),
          minuteField = countDown.querySelector('[data-type="mins"]'),
          secondField = countDown.querySelector('[data-type="secs"]');
        (dayField.innerHTML = days),
          (hourField.innerHTML = hours),
          (minuteField.innerHTML = minutes),
          (secondField.innerHTML = seconds),
          timeleft < 0 &&
            (clearInterval(myfunc),
            (dayField.innerHTML = ""),
            (hourField.innerHTML = ""),
            (minuteField.innerHTML = ""),
            (secondField.innerHTML = ""));
      }, 1e3);
    }
  }
}
class LocalizationForm extends HTMLElement {
  constructor() {
    super(),
      (this.elements = {
        input: this.querySelector(
          'input[name="language_code"], input[name="country_code"]'
        ),
        button: this.querySelector("button"),
        panel: this.querySelector("ul"),
      }),
      (this.toggleDropdownHandler = this.toggleDropdown.bind(this)),
      (this.closeSelectorHandler = this.closeSelector.bind(this)),
      (this.openSelectorHandler = this.openSelector.bind(this)),
      (this.onContainerKeyUpHandler = this.onContainerKeyUp.bind(this)),
      (this.onItemClickHandler = this.onItemClick.bind(this)),
      this.querySelectorAll("a").forEach((item) =>
        item.addEventListener("click", this.onItemClickHandler)
      ),
      (this.isPanelVisible = !1),
      window.matchMedia("(max-width: 1023px)").matches
        ? this.bindCountryLanguageDropdown()
        : this.bindClassFunction(),
      window.addEventListener("resize", () => {
        window.matchMedia("(max-width: 1023px)").matches
          ? (this.unbindClassFunction(), this.bindCountryLanguageDropdown())
          : (this.unbindCountryLanguageDropdown(), this.bindClassFunction());
      });
  }
  bindCountryLanguageDropdown() {
    (this.isPanelVisible = !1),
      (this.elements.panel.style.paddingTop = ""),
      (this.elements.panel.style.paddingBottom = ""),
      (this.elements.panel.style.height = ""),
      this.elements.button.addEventListener(
        "click",
        this.toggleDropdownHandler
      );
  }
  unbindCountryLanguageDropdown() {
    this.elements.button.removeEventListener(
      "click",
      this.toggleDropdownHandler
    );
  }
  bindClassFunction() {
    this.elements.button.addEventListener("click", this.openSelectorHandler),
      this.addEventListener("keyup", this.onContainerKeyUpHandler),
      document.addEventListener("click", this.closeSelectorHandler),
      window.matchMedia("(max-width: 1023px)").matches ||
        window.addEventListener("scroll", () => {
          this.elements.button.setAttribute("aria-expanded", !1),
            this.elements.panel.setAttribute("hidden", !0);
        });
  }
  unbindClassFunction() {
    this.elements.button.removeEventListener("click", this.openSelectorHandler),
      this.removeEventListener("keyup", this.onContainerKeyUpHandler),
      document.removeEventListener("click", this.closeSelectorHandler),
      window.matchMedia("(max-width: 1023px)").matches ||
        window.removeEventListener("scroll", this.closeScrollHandler);
  }
  toggleDropdown() {
    if (((this.isPanelVisible = !this.isPanelVisible), this.isPanelVisible)) {
      const buttonDropdownChilds = this.elements.panel.querySelectorAll("li");
      let dropDownHeight = 0;
      for (let i2 = 0; i2 < buttonDropdownChilds.length; i2++) {
        const buttonDropdownChild = buttonDropdownChilds[i2],
          dropdownChildComputedStyle =
            window.getComputedStyle(buttonDropdownChild),
          dropdownChildHeight = parseInt(
            dropdownChildComputedStyle.getPropertyValue("height"),
            10
          ),
          dropdownChildMarginBottom = parseInt(
            dropdownChildComputedStyle.getPropertyValue("margin-bottom"),
            10
          );
        dropDownHeight =
          dropDownHeight + dropdownChildHeight + dropdownChildMarginBottom;
      }
      (dropDownHeight += 48), this.elements.panel.toggleAttribute("hidden");
      let popupPadding;
      window.matchMedia("(max-width: 1023px)").matches
        ? (popupPadding = 8)
        : (popupPadding = 24),
        (this.elements.panel.style.paddingTop = popupPadding + "px"),
        (this.elements.panel.style.paddingBottom = popupPadding + "px"),
        (this.elements.panel.style.height = dropDownHeight + "px"),
        this.elements.button.setAttribute(
          "aria-expanded",
          (
            this.elements.button.getAttribute("aria-expanded") === "false"
          ).toString()
        );
    } else
      (this.elements.panel.style.paddingTop = ""),
        (this.elements.panel.style.paddingBottom = ""),
        (this.elements.panel.style.height = ""),
        setTimeout(() => {
          this.elements.button.setAttribute("aria-expanded", "false"),
            this.elements.panel.setAttribute("hidden", !0);
        }, 300);
  }
  hidePanel() {
    this.elements.button.setAttribute("aria-expanded", "false"),
      this.elements.panel.setAttribute("hidden", !0);
  }
  onContainerKeyUp(event) {
    event.code.toUpperCase() === "ESCAPE" &&
      (this.hidePanel(), this.elements.button.focus());
  }
  onItemClick(event) {
    event.preventDefault();
    const form = this.querySelector("form");
    (this.elements.input.value = event.currentTarget.dataset.value),
      form && form.submit();
  }
  openSelector() {
    setTimeout(() => {}, 100),
      this.elements.panel.toggleAttribute("hidden"),
      this.elements.button.setAttribute(
        "aria-expanded",
        (
          this.elements.button.getAttribute("aria-expanded") === "false"
        ).toString()
      );
  }
  closeSelector(event) {
    if (!window.matchMedia("(max-width: 1023px)").matches) {
      const isButton = event.target === this.elements.button,
        isInsidePanel = this.elements.panel.contains(event.target),
        isInsideDropdown = this.contains(event.target);
      !isButton &&
        !isInsidePanel &&
        !isInsideDropdown &&
        ((this.isPanelVisible = !1), this.hidePanel());
    }
  }
}
customElements.define("localization-form", LocalizationForm);
let isKeyboardFocus = !1;
document.addEventListener("keydown", function (event) {
  event.key === "Tab" && (isKeyboardFocus = !0);
}),
  document.addEventListener("mousedown", function () {
    isKeyboardFocus = !1;
  });
class FilterForm extends HTMLElement {
  constructor() {
    super(),
      this.querySelector("form").addEventListener(
        "input",
        this.handleFormChange.bind(this)
      );
  }
  handleFormChange(event) {
    this.handleCheckboxChange(event);
  }
  handleCheckboxChange(event) {
    if (event.target.type === "checkbox") {
      const root_url = this.dataset.url;
      if (event.target.checked)
        if (root_url.includes("?")) {
          const url =
            root_url +
            "&" +
            event.target.name +
            "=" +
            event.target.value.replace(" ", "+");
          this.setUrl(url);
        } else {
          const url =
            root_url +
            "?" +
            event.target.name +
            "=" +
            event.target.value.replace(" ", "+");
          this.setUrl(url);
        }
      else {
        const urlQuery = root_url.split("?"),
          queryRoot = urlQuery[0],
          queryParams = urlQuery[1].split("&"),
          urlRemove =
            event.target.name + "=" + event.target.value.replace(" ", "+");
        let url = queryRoot,
          firstQueryParam = !0;
        for (let i2 = 0; i2 < queryParams.length; i2++)
          queryParams[i2] != urlRemove &&
            (firstQueryParam
              ? ((url = url + "?" + queryParams[i2]), (firstQueryParam = !1))
              : (url = url + "&" + queryParams[i2]));
        this.setUrl(url);
      }
    }
  }
  setUrl(url, sort_by) {
    (this.dataset.url = url),
      document
        .querySelector(".load-wrapper")
        .setAttribute("data-loading", "loading"),
      this.fetchNewDoc(url, sort_by);
  }
  fetchNewDoc(url, sort_by) {
    fetch(url)
      .then((response) => response.text())
      .then((responseText) => {
        const html = new DOMParser().parseFromString(responseText, "text/html");
        window.history.replaceState({}, "", url),
          this.renderFilter(html),
          this.renderPage(html);
        const sortByWrapper = this.closest(
          ".search-filter-wrapper, .product-filter-wrapper"
        );
        sort_by &&
          setTimeout(() => {
            const sortByEl = sortByWrapper.querySelector(
              ".result-container .sort-by"
            );
            sortByEl &&
              (sortByEl.focus(),
              isKeyboardFocus &&
                sortByEl.classList.add("select-keyboard-focused"));
          }, 0);
      });
  }
  renderFilter(html) {
    [".filter-head", ".active-filters"].forEach((wrapper) => {
      const activeFilter = html.querySelector(wrapper);
      activeFilter &&
        (document.querySelector(wrapper).innerHTML = activeFilter.innerHTML);
    }),
      document
        .querySelectorAll(".filter-group-display")
        .forEach((filterDisplay) => {
          const displayId = filterDisplay.id,
            displayHead = html
              .getElementById(displayId)
              .querySelector(".filter-group-display__header");
          displayHead &&
            (document
              .getElementById(displayId)
              .querySelector(".filter-group-display__header").innerHTML =
              displayHead.innerHTML);
          const displayList = html
            .getElementById(displayId)
            .querySelector(".filter-group-display__list");
          if (displayList) {
            const filterList = document
              .getElementById(displayId)
              .querySelector(".filter-group-display__list");
            (filterList.innerHTML = displayList.innerHTML),
              filterList.classList.contains(
                "filter-group-display__list-color"
              ) && filterColorImage();
          }
        });
    const range = this.querySelector(".price-slider .price-progress"),
      priceMin = this.querySelector(".price-min"),
      priceMax = this.querySelector(".price-max"),
      rangeMin = this.querySelector(".price-range-min"),
      rangeMax = this.querySelector(".price-range-max"),
      newRangeMin = html.querySelector(".price-range-min"),
      newRangeMax = html.querySelector(".price-range-max"),
      priceRangeFilter = this.querySelector("price-range");
    priceRangeFilter &&
      priceRangeFilter.resetPriceRange(
        range,
        priceMin,
        priceMax,
        rangeMin,
        rangeMax,
        newRangeMin,
        newRangeMax
      );
  }
  renderPage(html) {
    [
      ".result-container",
      ".pagination-wrapper-bottom",
      ".pagination-wrapper-top",
    ].forEach((content) => {
      const pageContent = html.querySelector(content);
      pageContent &&
        ((document.querySelector(content).innerHTML = pageContent.innerHTML),
        content == ".result-container" && handleQuickView());
    }),
      document.querySelector(".load-wrapper").removeAttribute("data-loading");
  }
}
customElements.define("filter-form", FilterForm),
  $(document).ready(function () {
    filterColorImage();
  });
function filterColorImage() {
  $(".filter-color-image, .variant-color-image").each(function () {
    let img = $(this),
      canvas = $("<canvas></canvas>")[0],
      context = canvas.getContext("2d");
    function checkImageExists(imageUrl, callback) {
      var image = new Image();
      (image.onload = function () {
        callback(!0);
      }),
        (image.onerror = function () {
          callback(!1);
        }),
        (image.src = imageUrl);
    }
    checkImageExists(img.attr("src"), function (exists) {
      exists
        ? (img.on("load", function () {
            (canvas.width = this.naturalWidth),
              (canvas.height = this.naturalHeight),
              context.drawImage(
                this,
                0,
                0,
                this.naturalWidth,
                this.naturalHeight
              );
            let data = context.getImageData(
                0,
                0,
                canvas.width,
                canvas.height
              ).data,
              colorCount = {};
            for (let i2 = 0; i2 < data.length; i2 += 4) {
              let color = data[i2] + "," + data[i2 + 1] + "," + data[i2 + 2];
              colorCount[color] = (colorCount[color] || 0) + 1;
            }
            let mostFrequentColor = "",
              maxCount = 0;
            for (let color in colorCount)
              colorCount[color] > maxCount &&
                ((maxCount = colorCount[color]), (mostFrequentColor = color));
            let rgbArray = mostFrequentColor.split(","),
              mostUsedRed = parseInt(rgbArray[0]),
              mostUsedGreen = parseInt(rgbArray[1]),
              mostUsedBlue = parseInt(rgbArray[2]),
              checkColor =
                (mostUsedRed * 299 + mostUsedGreen * 587 + mostUsedBlue * 114) /
                  1e3 >
                128
                  ? "#000000"
                  : "#ffffff",
              closestLabel = $(this).closest("label");
            closestLabel.hasClass("checkbox-label")
              ? closestLabel.css("--check-color", checkColor)
              : closestLabel.css("--strike-color", checkColor),
              (canvas = null);
          }),
          img.attr("src", img.attr("src")))
        : img.remove();
    });
  });
}
class FilterRemove extends HTMLElement {
  constructor() {
    super(),
      this.querySelector("a").addEventListener(
        "click",
        this.handleFilterRemove.bind(this)
      );
  }
  setRemoveUrl(url) {
    this.querySelector("a").setAttribute("href", url);
  }
  handleFilterRemove(event) {
    event.preventDefault();
    const url = this.querySelector("a").getAttribute("href");
    this.closest("filter-form").setUrl(url);
  }
}
customElements.define("filter-remove", FilterRemove);
class SortFilter extends HTMLElement {
  constructor() {
    super(), this.attachListeners();
  }
  attachListeners() {
    const sortSelect = this.querySelector("select");
    sortSelect &&
      (sortSelect.addEventListener("change", this.updateSort.bind(this)),
      this.handleFocus(sortSelect));
  }
  handleFocus(selectElement) {
    selectElement.addEventListener("focus", function () {
      isKeyboardFocus && selectElement.classList.add("select-keyboard-focused");
    }),
      selectElement.addEventListener("blur", function () {
        selectElement.classList.remove("select-keyboard-focused");
      });
  }
  updateSort() {
    const sortSelect = this.querySelector("select");
    if (sortSelect) {
      const sortOptions = sortSelect.options;
      for (let i2 = 0; i2 < sortOptions.length; i2++)
        sortOptions[i2].removeAttribute("selected");
      sortOptions[sortSelect.selectedIndex].setAttribute("selected", "");
      const sortValue = sortSelect.value;
      this.handleSortChange(sortValue);
    }
  }
  handleSortChange(sortValue) {
    const filterForm = document.querySelector("filter-form"),
      root_url = filterForm.dataset.url;
    if (root_url.includes("?")) {
      const urlQuery = root_url.split("?");
      let url = urlQuery[0];
      const queryParamString = urlQuery[1];
      if (queryParamString.includes("sort_by")) {
        const queryParams = queryParamString.split("&");
        let prefix = "";
        for (let i2 = 0; i2 < queryParams.length; i2++)
          (prefix = i2 == 0 ? "?" : "&"),
            queryParams[i2].split("=")[0] === "sort_by"
              ? (url = url + prefix + "sort_by=" + sortValue)
              : (url = url + prefix + queryParams[i2]);
      } else url = root_url + "&sort_by=" + sortValue;
      filterForm.setUrl(url, !0);
    } else {
      const url = root_url + "?sort_by=" + sortValue;
      filterForm.setUrl(url, !0);
    }
  }
  connectedCallback() {
    this.attachListeners();
  }
  disconnectedCallback() {
    const sortSelect = this.querySelector("select");
    sortSelect &&
      (sortSelect.removeEventListener("change", this.updateSort.bind(this)),
      sortSelect.removeEventListener("focus", this.handleFocus.bind(this)),
      sortSelect.removeEventListener("blur", this.handleFocus.bind(this)));
  }
}
customElements.define("sort-filter", SortFilter);
class PriceRange extends HTMLElement {
  constructor() {
    super();
    const filterForm = this.closest("form"),
      range = this.querySelector(".price-slider .price-progress"),
      priceMin = this.querySelector(".price-min"),
      priceMax = this.querySelector(".price-max"),
      rangeMin = this.querySelector(".price-range-min"),
      rangeMax = this.querySelector(".price-range-max");
    let priceGap = 0;
    window.addEventListener(
      "load",
      this.handlePriceRangeOnLoad.bind(this, range, rangeMin, rangeMax)
    ),
      priceMax.addEventListener(
        "input",
        this.handleMaxPriceChange.bind(
          this,
          range,
          priceMin,
          priceMax,
          rangeMax,
          priceGap
        )
      ),
      priceMin.addEventListener(
        "input",
        this.handleMinPriceChange.bind(
          this,
          range,
          priceMin,
          priceMax,
          rangeMin,
          rangeMax,
          priceGap
        )
      ),
      rangeMin.addEventListener(
        "input",
        this.handleMinRangeChange.bind(
          this,
          range,
          priceMin,
          priceMax,
          rangeMin,
          rangeMax,
          priceGap
        )
      ),
      rangeMax.addEventListener(
        "input",
        this.handleMaxRangeChange.bind(
          this,
          range,
          priceMin,
          priceMax,
          rangeMin,
          rangeMax,
          priceGap
        )
      ),
      priceMin.addEventListener(
        "change",
        this.handleMinPriceUpdate.bind(
          this,
          priceMin,
          priceMax,
          rangeMin,
          rangeMax,
          priceGap
        )
      ),
      priceMax.addEventListener(
        "change",
        this.handleMaxPriceUpdate.bind(
          this,
          priceMin,
          priceMax,
          rangeMin,
          rangeMax,
          priceGap
        )
      ),
      rangeMin.addEventListener(
        "change",
        this.handlePriceUpdate.bind(this, priceMin, priceMax)
      ),
      rangeMax.addEventListener(
        "change",
        this.handlePriceUpdate.bind(this, priceMin, priceMax)
      );
  }
  handlePriceUpdate(priceMin, priceMax) {
    const priceMinValue = priceMin.value,
      priceMaxValue = priceMax.value,
      priceMinName = priceMin.name,
      priceMaxName = priceMax.name,
      priceMinFilter = priceMinName + "=" + priceMinValue,
      priceMaxFilter = priceMaxName + "=" + priceMaxValue,
      filterForm = document.querySelector("filter-form"),
      root_url = filterForm.dataset.url;
    if (root_url.includes(priceMinName) || root_url.includes(priceMaxName)) {
      const urlQuery = root_url.split("?"),
        queryRoot = urlQuery[0],
        queryParams = urlQuery[1].split("&");
      let url = queryRoot,
        firstQueryParam = !0;
      for (let i2 = 0; i2 < queryParams.length; i2++) {
        const queryParamName = queryParams[i2].split("=")[0];
        queryParamName == priceMinName
          ? firstQueryParam
            ? ((url = url + "?" + priceMinFilter), (firstQueryParam = !1))
            : (url = url + "&" + priceMinFilter)
          : queryParamName == priceMaxName
          ? firstQueryParam
            ? ((url = url + "?" + priceMaxFilter), (firstQueryParam = !1))
            : (url = url + "&" + priceMaxFilter)
          : firstQueryParam
          ? ((url = url + "?" + queryParams[i2]), (firstQueryParam = !1))
          : (url = url + "&" + queryParams[i2]);
      }
      filterForm.setUrl(url);
    } else if (root_url.includes("?")) {
      const url = root_url + "&" + priceMinFilter + "&" + priceMaxFilter;
      filterForm.setUrl(url);
    } else {
      const url = root_url + "?" + priceMinFilter + "&" + priceMaxFilter;
      filterForm.setUrl(url);
    }
  }
  handleMinPriceUpdate(priceMin, priceMax, rangeMin, rangeMax, priceGap) {
    let minPrice = parseInt(priceMin.value),
      maxPrice = Math.ceil(parseFloat(priceMax.value)),
      minPriceValue = Math.ceil(parseFloat(priceMin.value));
    maxPrice - minPrice >= priceGap &&
    minPriceValue <= rangeMax.max &&
    minPriceValue >= 0
      ? ((priceMin.value = minPrice),
        this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap),
        this.handlePriceUpdate(priceMin, priceMax))
      : this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap);
  }
  handleMaxPriceUpdate(priceMin, priceMax, rangeMin, rangeMax, priceGap) {
    let minPrice = parseInt(priceMin.value),
      maxPrice = Math.ceil(parseFloat(priceMax.value));
    maxPrice - minPrice >= priceGap && maxPrice <= rangeMax.max && maxPrice >= 0
      ? ((priceMax.value = maxPrice),
        this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap),
        this.handlePriceUpdate(priceMin, priceMax))
      : this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap);
  }
  handlePriceRangeOnLoad(range, rangeMin, rangeMax) {
    let minPrice = parseInt(rangeMin.value),
      maxPrice = parseInt(rangeMax.value),
      leftPercentage = (minPrice / rangeMin.max) * 100,
      rightPercentage = 100 - (maxPrice / rangeMax.max) * 100;
    (range.style.left = `calc(${leftPercentage}% - 8px)`),
      (range.style.right = `calc(${rightPercentage}% - 8px)`);
  }
  resetPriceRange(
    range,
    priceMin,
    priceMax,
    rangeMin,
    rangeMax,
    newRangeMin,
    newRangeMax
  ) {
    let minPrice = parseInt(newRangeMin.value),
      maxPrice = parseInt(newRangeMax.value),
      leftPercentage = (minPrice / newRangeMax.max) * 100,
      rightPercentage = 100 - (maxPrice / newRangeMax.max) * 100;
    (priceMin.value = minPrice),
      (priceMax.value = maxPrice),
      (rangeMin.value = minPrice),
      (rangeMax.value = maxPrice),
      (range.style.left = `calc(${leftPercentage}% - 8px)`),
      (range.style.right = `calc(${rightPercentage}% - 8px)`);
  }
  handleMaxRangeChange(
    range,
    priceMin,
    priceMax,
    rangeMin,
    rangeMax,
    priceGap
  ) {
    let minVal = parseInt(rangeMin.value),
      maxVal = parseInt(rangeMax.value);
    if (maxVal - minVal < priceGap) {
      (rangeMax.value = minVal + priceGap),
        (priceMax.value = parseInt(rangeMax.value));
      let rightPercentage =
        100 - (parseInt(rangeMax.value) / rangeMax.max) * 100;
      (range.style.right = `calc(${rightPercentage}% - 8px)`),
        this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap);
    } else
      this.setPriceAndProgress(
        range,
        priceMin,
        priceMax,
        rangeMin,
        rangeMax,
        minVal,
        maxVal,
        priceGap
      );
  }
  handleMinRangeChange(
    range,
    priceMin,
    priceMax,
    rangeMin,
    rangeMax,
    priceGap
  ) {
    let minVal = parseInt(rangeMin.value),
      maxVal = parseInt(rangeMax.value);
    if (maxVal - minVal < priceGap) {
      (rangeMin.value = maxVal - priceGap),
        (priceMin.value = parseInt(rangeMin.value));
      let leftPercentage = (parseInt(rangeMin.value) / rangeMin.max) * 100;
      (range.style.left = `calc(${leftPercentage}% - 8px)`),
        this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap);
    } else
      this.setPriceAndProgress(
        range,
        priceMin,
        priceMax,
        rangeMin,
        rangeMax,
        minVal,
        maxVal,
        priceGap
      );
  }
  setPriceAndProgress(
    range,
    priceMin,
    priceMax,
    rangeMin,
    rangeMax,
    minVal,
    maxVal,
    priceGap
  ) {
    (priceMin.value = minVal), (priceMax.value = maxVal);
    let leftPercentage = (minVal / rangeMin.max) * 100,
      rightPercentage = 100 - (maxVal / rangeMax.max) * 100;
    (range.style.left = `calc(${leftPercentage}% - 8px)`),
      (range.style.right = `calc(${rightPercentage}% - 8px)`),
      this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap);
  }
  handleMaxPriceChange(range, priceMin, priceMax, rangeMax, priceGap) {
    let minPrice = parseInt(priceMin.value),
      maxPrice = Math.ceil(parseFloat(priceMax.value));
    if (
      maxPrice - minPrice >= priceGap &&
      maxPrice <= rangeMax.max &&
      maxPrice >= 0
    ) {
      rangeMax.value = maxPrice;
      let rightPercentage = 100 - (maxPrice / rangeMax.max) * 100;
      (range.style.right = `calc(${rightPercentage}% - 8px)`),
        this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap);
    } else this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap);
  }
  handleMinPriceChange(
    range,
    priceMin,
    priceMax,
    rangeMin,
    rangeMax,
    priceGap
  ) {
    let minPrice = parseInt(priceMin.value),
      maxPrice = Math.ceil(parseFloat(priceMax.value)),
      minPriceValue = Math.ceil(parseFloat(priceMin.value));
    if (
      maxPrice - minPrice >= priceGap &&
      minPriceValue <= rangeMax.max &&
      minPriceValue >= 0
    ) {
      rangeMin.value = minPrice;
      let leftPercentage = (minPrice / rangeMin.max) * 100;
      (range.style.left = `calc(${leftPercentage}% - 8px)`),
        this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap);
    } else this.toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap);
  }
  toggleErrorMessage(priceMin, priceMax, rangeMax, priceGap) {
    let minPrice = parseInt(priceMin.value),
      maxPrice = Math.ceil(parseFloat(priceMax.value)),
      minPriceValue = Math.ceil(parseFloat(priceMin.value));
    const fromErrorEl = this.querySelector(".filter-price-error.from-error"),
      toErrorEl = this.querySelector(".filter-price-error.to-error"),
      bothErrorEl = this.querySelector(".filter-price-error.both-error");
    maxPrice - minPrice >= priceGap &&
    minPriceValue <= rangeMax.max &&
    maxPrice <= rangeMax.max &&
    minPriceValue >= 0 &&
    maxPrice >= 0
      ? ((fromErrorEl.style.display = "none"),
        (bothErrorEl.style.display = "none"),
        (toErrorEl.style.display = "none"))
      : minPriceValue < 0 || maxPrice < 0
      ? ((fromErrorEl.style.display = "none"),
        (toErrorEl.style.display = "none"),
        (bothErrorEl.style.display = "block"))
      : minPriceValue > maxPrice
      ? ((toErrorEl.style.display = "none"),
        (bothErrorEl.style.display = "none"),
        (fromErrorEl.style.display = "block"))
      : maxPrice > rangeMax.max &&
        ((fromErrorEl.style.display = "none"),
        (bothErrorEl.style.display = "none"),
        (toErrorEl.style.display = "block"));
  }
}
customElements.define("price-range", PriceRange);
class CollapsibleContent extends HTMLElement {
  constructor() {
    super();
    const toggle = this.querySelector(".collapsible-toggle");
    window.addEventListener("load", this.handleCollapseState.bind(this)),
      window.addEventListener("resize", this.handleCollapseState.bind(this)),
      document.addEventListener(
        "shopify:section:load",
        this.handleCollapseState.bind(this)
      ),
      toggle.addEventListener("click", this.handleCollapse.bind(this));
  }
  handleCollapseState() {
    const content = this.querySelector(".collapsible-content");
    this.getAttribute("aria-expanded") == "true"
      ? (content.style.height =
          content.querySelector(".collapsible-content-inner").scrollHeight +
          "px")
      : (content.style.height = "0px");
  }
  handleCollapse() {
    const toggle = this.querySelector(".collapsible-toggle"),
      content = this.querySelector(".collapsible-content"),
      parentGroup = this.closest('[data-behaviour="group"]');
    parentGroup &&
      parentGroup
        .querySelectorAll("collapsible-content")
        .forEach((collapsible) => {
          collapsible !== this && collapsible.close();
        }),
      content.style.height === "0px"
        ? ((content.style.height = content.scrollHeight + "px"),
          this.setAttribute("aria-expanded", !0))
        : ((content.style.height = "0px"),
          this.setAttribute("aria-expanded", !1));
  }
  close() {
    const content = this.querySelector(".collapsible-content");
    (content.style.height = "0px"), this.setAttribute("aria-expanded", !1);
  }
}
customElements.define("collapsible-content", CollapsibleContent),
  document.addEventListener("DOMContentLoaded", thumbProductModel),
  document.addEventListener("shopify:section:load", thumbProductModel);
function thumbProductModel() {
  for (
    var thumb_image = document.querySelectorAll(".thumb-image"), i2 = 0;
    i2 < thumb_image.length;
    i2++
  )
    thumb_image[i2].addEventListener("click", function (event) {
      var model = document.querySelector(".product-model-inner");
      model.style.display = "block";
    });
  var model_close = document.querySelector(".product-model-close");
  model_close.addEventListener("click", function (event) {
    var model = document.querySelector(".product-model-inner");
    model.style.display = "none";
  });
}
function trapFocus(event, trapcontainer) {
  const focusableElements = trapcontainer.querySelectorAll(
      'a[href], button:not([tabindex="-1"]), textarea, input[type="text"], input[type="radio"], input[type="tel"], input[type="checkbox"], select'
    ),
    firstFocusableElement = focusableElements[0],
    lastFocusableElement = focusableElements[focusableElements.length - 1];
  (event.key === "Tab" || event.keyCode === 9) &&
    (event.shiftKey
      ? document.activeElement === firstFocusableElement &&
        (event.preventDefault(), lastFocusableElement.focus())
      : document.activeElement === lastFocusableElement &&
        (event.preventDefault(), firstFocusableElement.focus()));
}
document.addEventListener("shopify:section:load", countryListFocus),
  document.addEventListener("DOMContentLoaded", countryListFocus);
function countryListFocus() {
  var countryListEl = document.getElementById("CountryList");
  countryListEl &&
    countryListEl.addEventListener("keydown", function (event) {
      trapFocus(event, countryListEl);
    });
}
document.addEventListener("shopify:section:load", addressFormFocus),
  document.addEventListener("DOMContentLoaded", addressFormFocus);
function addressFormFocus() {
  var addressFormArr = document.querySelectorAll(".address-form-popup-wrapper");
  for (let i2 = 0; i2 < addressFormArr.length; i2++) {
    let addressForm = addressFormArr[i2];
    addressForm.addEventListener("keydown", function (event) {
      trapFocus(event, addressForm);
    });
  }
}
window.addEventListener("pageshow", function (event) {
  event.persisted && updateCartCount();
});
function updateCartCount() {
  fetch("/cart.js")
    .then((res) => res.json())
    .then((cart) => {
      const cartCountElement = document.querySelector(".cart-count");
      cartCountElement && (cartCountElement.textContent = cart.item_count),
        document
          .querySelectorAll(".product-section-wrapper")
          .forEach((section) => {
            const variantId = section
                .querySelector(".shopify-product-form")
                .querySelector('[name="id"]').value,
              cartItems = cart.items;
            let variantQuantity = 0;
            cartItems.forEach((cartItem) => {
              cartItem.variant_id == variantId &&
                (variantQuantity += cartItem.quantity);
            }),
              section
                .querySelector("[data-cart-count]")
                .setAttribute("data-cart-count", variantQuantity);
          });
    })
    .catch((error) => {
      console.error("Error fetching cart data:", error);
    });
}
window.addEventListener("pageshow", function (event) {
  document
    .querySelectorAll(".featured-product-section .product-detail")
    .forEach((productDetail) => {
      let variantSelector = productDetail.querySelector("variant-selector");
      if (variantSelector) {
        let handleSectionResponse2 = function () {
          if (this.status === 200) {
            var newVariantSelector = new DOMParser()
              .parseFromString(this.responseText, "text/html")
              .querySelector("variant-selector");
            variantSelector.innerHTML = newVariantSelector.innerHTML;
          } else console.log(this.statusText);
        };
        var handleSectionResponse = handleSectionResponse2;
        let variantSection = variantSelector.dataset.section;
        const request = new XMLHttpRequest();
        request.addEventListener("load", handleSectionResponse2),
          request.open(
            "GET",
            window.location.pathname + "?section_id=" + variantSection,
            !0
          ),
          request.send();
      }
    });
}),
  document.addEventListener("shopify:section:load", handleQuickView),
  document.addEventListener("shopify:section:unload", handleQuickView),
  document.addEventListener("DOMContentLoaded", handleQuickView);
let isQuickViewSelected = !1,
  isQuickViewOpen = !1;
Shopify.designMode &&
  (document.addEventListener("shopify:section:select", (event) =>
    handleSectionEvent(event, quickViewShow, quickViewClose)
  ),
  document.addEventListener("shopify:section:deselect", (event) =>
    handleSectionEvent(event, null, quickViewClose)
  ),
  document.addEventListener("shopify:section:load", (event) =>
    handleSectionEvent(event, quickViewShow, quickViewClose)
  ),
  document.addEventListener("shopify:section:unload", (event) =>
    handleSectionEvent(event, null, quickViewClose)
  ));
function handleQuickView() {
  setTimeout(() => {
    const quickViewSection = document.querySelector(".quick-view-section");
    if (
      (document.querySelectorAll(".quick-view-wrapper").forEach((wrapper) => {
        const quickViewButton = wrapper.querySelector(".quick-view-button");
        if (quickViewButton) {
          const newButton = quickViewButton.cloneNode(!0);
          quickViewButton.parentNode.replaceChild(newButton, quickViewButton),
            (Shopify.designMode ? setupDesignMode : setupNonDesignMode)(
              wrapper,
              quickViewSection,
              newButton
            );
        }
      }),
      quickViewSection
        ? quickViewSection.querySelector("#quick-view-modal")
        : null)
    ) {
      const quickViewCloseBtn =
        quickViewSection.querySelector(".quick-view-close");
      if (quickViewCloseBtn) {
        const newCloseButton = quickViewCloseBtn.cloneNode(!0);
        quickViewCloseBtn.parentNode.replaceChild(
          newCloseButton,
          quickViewCloseBtn
        ),
          newCloseButton.addEventListener("click", () =>
            quickViewClose(quickViewSection.id)
          );
      }
      document.quickViewClickListenerAdded &&
        document.removeEventListener("click", document.quickViewClickListener),
        (document.quickViewClickListener = (event) => {
          const quickViewCard = quickViewSection.querySelector(".product-page"),
            quickViewCartPopup = document.querySelector(".cart-popup-wrapper"),
            quickViewButtonClicked = event.target.closest(".quick-view-button");
          quickViewCard &&
            !quickViewCard.contains(event.target) &&
            quickViewCartPopup &&
            !quickViewCartPopup.contains(event.target) &&
            !quickViewButtonClicked &&
            quickViewClose(quickViewSection.id);
        }),
        document.addEventListener("click", document.quickViewClickListener),
        (document.quickViewClickListenerAdded = !0);
    }
  }, 100);
}
function setupDesignMode(wrapper, quickViewSection, quickViewButton) {
  const quickViewModal = quickViewSection.querySelector("#quick-view-modal");
  wrapper.classList.toggle("show", !!quickViewModal),
    quickViewModal && bindQuickViewButton(quickViewButton, quickViewSection.id);
}
function setupNonDesignMode(wrapper, quickViewSection, quickViewButton) {
  quickViewSection.querySelector("#quick-view-modal")
    ? (wrapper.classList.add("show"),
      bindQuickViewButton(quickViewButton, quickViewSection.id))
    : wrapper.remove();
}
function bindQuickViewButton(button, sectionId) {
  const newButton = button.cloneNode(!0);
  button.parentNode.replaceChild(newButton, button),
    newButton.addEventListener("click", () =>
      fetchQuickView(sectionId, newButton)
    );
}
function fetchQuickView(sectionId, button) {
  const separator = button.dataset.url.includes("?") ? "&" : "?",
    fetchId = sectionId.replace("shopify-section-", ""),
    productURL = `${button.dataset.url}${separator}section_id=${fetchId}`;
  fetch(productURL)
    .then((response) => response.text())
    .then((htmlString) => {
      const tempDiv = document.createElement("div");
      tempDiv.innerHTML = htmlString;
      const fetchedProductGrid = tempDiv.querySelector(
          `#${sectionId} .product-grid`
        ),
        fetchedSectionContent = fetchedProductGrid.innerHTML,
        fetchedProductGridClasses = fetchedProductGrid.className,
        currentProductGrid = document.querySelector(
          `#${sectionId} .product-grid`
        );
      (currentProductGrid.innerHTML = fetchedSectionContent),
        (currentProductGrid.className = fetchedProductGridClasses);
      const quickViewMedia = tempDiv.querySelector(
        `#${sectionId} .product-medias`
      );
      productSectionSlider(),
        thumbProductModel(),
        shopifyXr(),
        cleanUpVideoPlayers(),
        productForm(),
        quantityBtnHandle(),
        quantityInputHandle(),
        quickViewMedia && videoPlayerInitialise(`#${quickViewMedia.id}`),
        (isQuickViewOpen = !0),
        quickViewShow(sectionId);
    })
    .catch((error) => console.error("Error loading quick view:", error));
}
function quickViewShow(sectionId) {
  const htmlEl = document.querySelector("html"),
    quickView = document.querySelector(`#${sectionId}`),
    quickViewCard = quickView.querySelector(".product-page");
  quickView.classList.add("show"),
    htmlEl.classList.add("popup-show"),
    Shopify.designMode && quickView.classList.add("fade"),
    setTimeout(() => {
      quickView.classList.add("fade"),
        Shopify.designMode || quickViewCard.focus();
    }, 100),
    quickViewCard.setAttribute("tabindex", "-1"),
    quickViewCard.addEventListener("keydown", (event) =>
      trapFocus(event, quickViewCard)
    );
}
function quickViewClose(sectionId) {
  const htmlEl = document.querySelector("html"),
    quickView = document.querySelector(`#${sectionId}`);
  if (Shopify.designMode && isQuickViewSelected) {
    htmlEl.classList.remove("popup-show");
    return;
  }
  quickView.classList.remove("fade"),
    setTimeout(() => {
      isQuickViewSelected ||
        (quickView.classList.remove("show"),
        htmlEl.classList.remove("popup-show"));
    }, 400);
}
function handleSectionEvent(event, showAction, closeAction = null) {
  const quickViewSection = document.querySelector(".quick-view-section"),
    quickViewModal = event.target.querySelector("#quick-view-modal");
  event.target.classList.contains("quick-view-section") && quickViewModal
    ? showAction && closeAction
      ? event.type == "shopify:section:select"
        ? ((isQuickViewSelected = !0),
          (isQuickViewOpen = !0),
          showAction(quickViewSection.id))
        : isQuickViewSelected &&
          ((isQuickViewOpen = !0), showAction(quickViewSection.id))
      : closeAction &&
        (event.type == "shopify:section:deselect" && (isQuickViewSelected = !1),
        (isQuickViewOpen = !1),
        closeAction(quickViewSection.id))
    : (closeAction &&
        isQuickViewOpen &&
        !isQuickViewSelected &&
        ((isQuickViewSelected = !1),
        (isQuickViewOpen = !1),
        closeAction(quickViewSection.id)),
      event.type == "shopify:section:deselect"
        ? (isQuickViewSelected = !0)
        : (event.type == "shopify:section:select" ||
            event.type == "shopify:section:load") &&
          (isQuickViewSelected = !1));
}
