class PredictiveSearch extends SearchForm {
  constructor() {
    super();

    this.cachedResults = {};
    this.predictiveSearch = this.querySelector('[data-predictive-search]');
    this.customSuggestions = this.querySelector('.predictive-search__result-group.custom-suggestions');
    this.resultsWrapper = this.querySelector('.predictive-search-results-wrapper');
    this.allPredictiveSearchInstances = document.querySelectorAll('predictive-search');

    this.abortController = new AbortController();
    this.searchTerm = '';
    this.isOpen = false;

    this.setupEventListeners();
  }

  setupEventListeners() {
    this.input.form.addEventListener('submit', this.onFormSubmit.bind(this));
    this.addEventListener('focusout', this.onFocusOut.bind(this));
    this.addEventListener('keyup', this.onKeyup.bind(this));
    this.addEventListener('keydown', this.onKeydown.bind(this));

    // 🔥 Focus par default suggestions
    this.input.addEventListener('focus', () => {
      if (!this.getQuery().length) {
        this.showCustomSuggestions();
        this.open();
      }
    });
  }

  getQuery() {
    return this.input.value.trim();
  }

  /* =======================
     CORE CHANGE HANDLER
  ======================= */
  onChange() {
    super.onChange();

    const newSearchTerm = this.getQuery();
    this.searchTerm = newSearchTerm;

    // 🔥 EMPTY INPUT → DEFAULT SUGGESTIONS
    if (!this.searchTerm.length) {
      this.abortController.abort();
      this.abortController = new AbortController();

      this.clearPredictiveResults();
      this.showCustomSuggestions();
      this.open();
      return;
    }

    // 🔥 USER TYPING → HIDE DEFAULT, SHOW AJAX
    this.hideCustomSuggestions();
    this.getSearchResults(this.searchTerm);
  }

  onFormSubmit(event) {
    if (!this.getQuery().length || this.querySelector('[aria-selected="true"] a')) {
      event.preventDefault();
    }
  }

  onFormReset(event) {
    super.onFormReset(event);

    if (super.shouldResetForm()) {
      this.searchTerm = '';
      this.abortController.abort();
      this.abortController = new AbortController();

      this.clearPredictiveResults();
      this.showCustomSuggestions();
      this.open();
    }
  }

  onFocusOut() {
    setTimeout(() => {
      if (!this.contains(document.activeElement)) {
        this.close();
      }
    });
  }

  onKeyup(event) {
    if (!this.getQuery().length) {
      this.showCustomSuggestions();
      this.open();
      return;
    }

    event.preventDefault();

    switch (event.code) {
      case 'ArrowUp':
        this.switchOption('up');
        break;
      case 'ArrowDown':
        this.switchOption('down');
        break;
      case 'Enter':
        this.selectOption();
        break;
    }
  }

  onKeydown(event) {
    if (event.code === 'ArrowUp' || event.code === 'ArrowDown') {
      event.preventDefault();
    }
  }

  /* =======================
     SHOW / HIDE HELPERS
  ======================= */
  hideCustomSuggestions() {
    if (!this.customSuggestions) return;
    this.customSuggestions.setAttribute('hidden', '');
  }

  showCustomSuggestions() {
    if (!this.customSuggestions) return;
    this.customSuggestions.removeAttribute('hidden');
  }

  clearPredictiveResults() {
    if (!this.resultsWrapper) return;
    this.resultsWrapper.innerHTML = '';
    this.removeAttribute('results');
  }

  /* =======================
     KEYBOARD NAV
  ======================= */
  switchOption(direction) {
    if (!this.hasAttribute('open')) return;

    const moveUp = direction === 'up';
    const selected = this.querySelector('[aria-selected="true"]');

    const visibleItems = Array.from(
      this.querySelectorAll('li, button.predictive-search__item')
    ).filter((el) => el.offsetParent !== null);

    if (moveUp && !selected) return;

    let index = visibleItems.indexOf(selected);
    let nextIndex = 0;

    if (!moveUp && selected) {
      nextIndex = index === visibleItems.length - 1 ? 0 : index + 1;
    } else if (moveUp) {
      nextIndex = index === 0 ? visibleItems.length - 1 : index - 1;
    }

    const active = visibleItems[nextIndex];
    if (!active) return;

    selected?.setAttribute('aria-selected', false);
    active.setAttribute('aria-selected', true);
    this.input.setAttribute('aria-activedescendant', active.id);
  }

  selectOption() {
    const selected = this.querySelector('[aria-selected="true"] a, button[aria-selected="true"]');
    if (selected) selected.click();
  }

  /* =======================
     FETCH & RENDER
  ======================= */
  getSearchResults(term) {
    const queryKey = term.replace(/\s+/g, '-').toLowerCase();
    this.setLiveRegionLoadingState();

    if (this.cachedResults[queryKey]) {
      this.renderSearchResults(this.cachedResults[queryKey]);
      return;
    }

    fetch(
      `${routes.predictive_search_url}?q=${encodeURIComponent(term)}&section_id=predictive-search`,
      { signal: this.abortController.signal }
    )
      .then((res) => {
        if (!res.ok) throw new Error(res.status);
        return res.text();
      })
      .then((text) => {
        const markup = new DOMParser()
          .parseFromString(text, 'text/html')
          .querySelector('#shopify-section-predictive-search').innerHTML;

        this.allPredictiveSearchInstances.forEach((instance) => {
          instance.cachedResults[queryKey] = markup;
        });

        this.renderSearchResults(markup);
      })
      .catch((err) => {
        if (err?.code === 20) return;
        this.close();
      });
  }

  renderSearchResults(markup) {
    if (!this.resultsWrapper) return;

    this.resultsWrapper.innerHTML = markup;
    this.setAttribute('results', true);
    this.setLiveRegionResults();
    this.open();
  }

  /* =======================
     ACCESSIBILITY
  ======================= */
  setLiveRegionLoadingState() {
    this.statusElement = this.statusElement || this.querySelector('.predictive-search-status');
    this.loadingText = this.loadingText || this.getAttribute('data-loading-text');

    this.setLiveRegionText(this.loadingText);
    this.setAttribute('loading', true);
  }

  setLiveRegionResults() {
    this.removeAttribute('loading');
    const text = this.querySelector('[data-predictive-search-live-region-count-value]')?.textContent;
    if (text) this.setLiveRegionText(text);
  }

  setLiveRegionText(text) {
    if (!this.statusElement) return;

    this.statusElement.setAttribute('aria-hidden', 'false');
    this.statusElement.textContent = text;

    setTimeout(() => {
      this.statusElement.setAttribute('aria-hidden', 'true');
    }, 1000);
  }

  /* =======================
     OPEN / CLOSE
  ======================= */
  open() {
    this.setAttribute('open', true);
    this.input.setAttribute('aria-expanded', true);
    this.isOpen = true;
  }

  close() {
    this.removeAttribute('open');
    this.removeAttribute('loading');
    this.input.setAttribute('aria-expanded', false);
    this.isOpen = false;
  }
}

customElements.define('predictive-search', PredictiveSearch);
