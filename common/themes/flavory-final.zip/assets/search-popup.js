if (!customElements.get('search-popup')) {
  customElements.define(
    'search-popup',
    class SearchPopup extends HTMLElement {
      constructor() {
        super();
        this.modal = this.closest('.search-popup-model');
        this.openTrigger = document.querySelector('.search-popup-icon a');
        this.closeBtn = this.querySelector('.search-modal__close-button');

        this.handleOpen = this.handleOpen.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleKeydown = this.handleKeydown.bind(this);
        this.handleOutsideClick = this.handleOutsideClick.bind(this);
      }

      connectedCallback() {
        if (!this.modal || !this.openTrigger) return;

        this.openTrigger.addEventListener('click', this.handleOpen);
        this.closeBtn?.addEventListener('click', this.handleClose);
        document.addEventListener('keydown', this.handleKeydown);
        this.modal.addEventListener('click', this.handleOutsideClick);
      }

      disconnectedCallback() {
        this.openTrigger.removeEventListener('click', this.handleOpen);
        this.closeBtn?.removeEventListener('click', this.handleClose);
        document.removeEventListener('keydown', this.handleKeydown);
        this.modal.removeEventListener('click', this.handleOutsideClick);

        // safety cleanup
        document.body.style.overflow = '';
      }

      handleOpen(e) {
        e.preventDefault();

        this.classList.add('active');
        document.body.style.overflow = 'hidden';

        const input = this.querySelector('.search__input');

        if (!input) return;

        // ✅ Wait for DOM + CSS + animation
        requestAnimationFrame(() => {
          setTimeout(() => {
            input.focus();
            input.setSelectionRange(input.value.length, input.value.length);
          }, 150);
        });
      }

      handleClose() {
        this.modal.classList.remove('active');

        // 🔓 BODY SCROLL UNLOCK
        document.body.style.overflow = '';
      }

      handleKeydown(e) {
        if (e.key === 'Escape' && this.modal.classList.contains('active')) {
          this.handleClose();
        }
      }

      handleOutsideClick(e) {
        if (e.target === this.modal) {
          this.handleClose();
        }
      }
    }
  );
}
