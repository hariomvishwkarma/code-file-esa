function getFocusableElements(container) {
  return Array.from(
    container.querySelectorAll(
      "summary, a[href], button:enabled, [tabindex]:not([tabindex^='-']), [draggable], area, input:not([type=hidden]):enabled, select:enabled, textarea:enabled, object, iframe"
    )
  );
}

document.querySelectorAll('[id^="Details-"] summary').forEach((summary) => {
  summary.setAttribute('role', 'button');
  summary.setAttribute('aria-expanded', summary.parentNode.hasAttribute('open'));

  if (summary.nextElementSibling.getAttribute('id')) {
    summary.setAttribute('aria-controls', summary.nextElementSibling.id);
  }

  summary.addEventListener('click', (event) => {
    event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
  });

  if (summary.closest('header-drawer, menu-drawer')) return;
  summary.parentElement.addEventListener('keyup', onKeyUpEscape);
});

const trapFocusHandlers = {};

function trapFocus(container, elementToFocus = container) {
  var elements = getFocusableElements(container);
  var first = elements[0];
  var last = elements[elements.length - 1];

  removeTrapFocus();

  trapFocusHandlers.focusin = (event) => {
    if (event.target !== container && event.target !== last && event.target !== first) return;

    document.addEventListener('keydown', trapFocusHandlers.keydown);
  };

  trapFocusHandlers.focusout = function () {
    document.removeEventListener('keydown', trapFocusHandlers.keydown);
  };

  trapFocusHandlers.keydown = function (event) {
    if (event.code.toUpperCase() !== 'TAB') return; // If not TAB key
    // On the last focusable element and tab forward, focus the first element.
    if (event.target === last && !event.shiftKey) {
      event.preventDefault();
      first.focus();
    }

    //  On the first focusable element and tab backward, focus the last element.
    if ((event.target === container || event.target === first) && event.shiftKey) {
      event.preventDefault();
      last.focus();
    }
  };

  document.addEventListener('focusout', trapFocusHandlers.focusout);
  document.addEventListener('focusin', trapFocusHandlers.focusin);

  elementToFocus.focus();

  if (
    elementToFocus.tagName === 'INPUT' &&
    ['search', 'text', 'email', 'url'].includes(elementToFocus.type) &&
    elementToFocus.value
  ) {
    elementToFocus.setSelectionRange(0, elementToFocus.value.length);
  }
}

// Here run the querySelector to figure out if the browser supports :focus-visible or not and run code based on it.
try {
  document.querySelector(':focus-visible');
} catch (e) {
  focusVisiblePolyfill();
}

function focusVisiblePolyfill() {
  const navKeys = [
    'ARROWUP',
    'ARROWDOWN',
    'ARROWLEFT',
    'ARROWRIGHT',
    'TAB',
    'ENTER',
    'SPACE',
    'ESCAPE',
    'HOME',
    'END',
    'PAGEUP',
    'PAGEDOWN',
  ];
  let currentFocusedElement = null;
  let mouseClick = null;

  window.addEventListener('keydown', (event) => {
    if (navKeys.includes(event.code.toUpperCase())) {
      mouseClick = false;
    }
  });

  window.addEventListener('mousedown', (event) => {
    mouseClick = true;
  });

  window.addEventListener(
    'focus',
    () => {
      if (currentFocusedElement) currentFocusedElement.classList.remove('focused');

      if (mouseClick) return;

      currentFocusedElement = document.activeElement;
      currentFocusedElement.classList.add('focused');
    },
    true
  );
}

function pauseAllMedia() {
  document.querySelectorAll('.js-youtube[playonclick]').forEach((video) => {
    video.contentWindow.postMessage('{"event":"command","func":"' + 'pauseVideo' + '","args":""}', '*');
  });
  document.querySelectorAll('.js-vimeo[playonclick]').forEach((video) => {
    video.contentWindow.postMessage('{"method":"pause"}', '*');
  });
  document.querySelectorAll('video[playonclick]').forEach((video) => video.pause());
  document.querySelectorAll('product-model').forEach((model) => {
    if (model.modelViewerUI) model.modelViewerUI.pause();
  });
}

function removeTrapFocus(elementToFocus = null) {
  document.removeEventListener('focusin', trapFocusHandlers.focusin);
  document.removeEventListener('focusout', trapFocusHandlers.focusout);
  document.removeEventListener('keydown', trapFocusHandlers.keydown);

  if (elementToFocus) elementToFocus.focus();
}

function onKeyUpEscape(event) {
  if (event.code.toUpperCase() !== 'ESCAPE') return;

  const openDetailsElement = event.target.closest('details[open]');
  if (!openDetailsElement) return;

  const summaryElement = openDetailsElement.querySelector('summary');
  openDetailsElement.removeAttribute('open');
  summaryElement.setAttribute('aria-expanded', false);
  summaryElement.focus();
}

class QuantityInput extends HTMLElement {
  constructor() {
    super();
    this.input = this.querySelector('input');
    this.changeEvent = new Event('change', { bubbles: true });
    this.input.addEventListener('change', this.onInputChange.bind(this));
    this.querySelectorAll('button').forEach((button) =>
      button.addEventListener('click', this.onButtonClick.bind(this))
    );
  }

  quantityUpdateUnsubscriber = undefined;

  connectedCallback() {
    this.validateQtyRules();
    this.quantityUpdateUnsubscriber = subscribe(PUB_SUB_EVENTS.quantityUpdate, this.validateQtyRules.bind(this));
  }

  disconnectedCallback() {
    if (this.quantityUpdateUnsubscriber) {
      this.quantityUpdateUnsubscriber();
    }
  }

  onInputChange(event) {
    this.validateQtyRules();
  }

  onButtonClick(event) {
    event.preventDefault();
    const previousValue = this.input.value;

    event.target.name === 'plus' ? this.input.stepUp() : this.input.stepDown();
    if (previousValue !== this.input.value) this.input.dispatchEvent(this.changeEvent);
  }

  validateQtyRules() {
    const value = parseInt(this.input.value);
    if (this.input.min) {
      const min = parseInt(this.input.min);
      const buttonMinus = this.querySelector(".quantity__button[name='minus']");
      buttonMinus.classList.toggle('disabled', value <= min);
    }
    if (this.input.max) {
      const max = parseInt(this.input.max);
      const buttonPlus = this.querySelector(".quantity__button[name='plus']");
      buttonPlus.classList.toggle('disabled', value >= max);
    }
  }
}

customElements.define('quantity-input', QuantityInput);

function debounce(fn, wait) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

function throttle(fn, delay) {
  let lastCall = 0;
  return function (...args) {
    const now = new Date().getTime();
    if (now - lastCall < delay) {
      return;
    }
    lastCall = now;
    return fn(...args);
  };
}

function fetchConfig(type = 'json') {
  return {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: `application/${type}` },
  };
}

/*
 * Shopify Common JS
 *
 */
if (typeof window.Shopify == 'undefined') {
  window.Shopify = {};
}

Shopify.bind = function (fn, scope) {
  return function () {
    return fn.apply(scope, arguments);
  };
};

Shopify.setSelectorByValue = function (selector, value) {
  for (var i = 0, count = selector.options.length; i < count; i++) {
    var option = selector.options[i];
    if (value == option.value || value == option.innerHTML) {
      selector.selectedIndex = i;
      return i;
    }
  }
};

Shopify.addListener = function (target, eventName, callback) {
  target.addEventListener
    ? target.addEventListener(eventName, callback, false)
    : target.attachEvent('on' + eventName, callback);
};

Shopify.postLink = function (path, options) {
  options = options || {};
  var method = options['method'] || 'post';
  var params = options['parameters'] || {};

  var form = document.createElement('form');
  form.setAttribute('method', method);
  form.setAttribute('action', path);

  for (var key in params) {
    var hiddenField = document.createElement('input');
    hiddenField.setAttribute('type', 'hidden');
    hiddenField.setAttribute('name', key);
    hiddenField.setAttribute('value', params[key]);
    form.appendChild(hiddenField);
  }
  document.body.appendChild(form);
  form.submit();
  document.body.removeChild(form);
};

Shopify.CountryProvinceSelector = function (country_domid, province_domid, options) {
  this.countryEl = document.getElementById(country_domid);
  this.provinceEl = document.getElementById(province_domid);
  this.provinceContainer = document.getElementById(options['hideElement'] || province_domid);

  Shopify.addListener(this.countryEl, 'change', Shopify.bind(this.countryHandler, this));

  this.initCountry();
  this.initProvince();
};

Shopify.CountryProvinceSelector.prototype = {
  initCountry: function () {
    var value = this.countryEl.getAttribute('data-default');
    Shopify.setSelectorByValue(this.countryEl, value);
    this.countryHandler();
  },

  initProvince: function () {
    var value = this.provinceEl.getAttribute('data-default');
    if (value && this.provinceEl.options.length > 0) {
      Shopify.setSelectorByValue(this.provinceEl, value);
    }
  },

  countryHandler: function (e) {
    var opt = this.countryEl.options[this.countryEl.selectedIndex];
    var raw = opt.getAttribute('data-provinces');
    var provinces = JSON.parse(raw);

    this.clearOptions(this.provinceEl);
    if (provinces && provinces.length == 0) {
      this.provinceContainer.style.display = 'none';
    } else {
      for (var i = 0; i < provinces.length; i++) {
        var opt = document.createElement('option');
        opt.value = provinces[i][0];
        opt.innerHTML = provinces[i][1];
        this.provinceEl.appendChild(opt);
      }

      this.provinceContainer.style.display = '';
    }
  },

  clearOptions: function (selector) {
    while (selector.firstChild) {
      selector.removeChild(selector.firstChild);
    }
  },

  setOptions: function (selector, values) {
    for (var i = 0, count = values.length; i < values.length; i++) {
      var opt = document.createElement('option');
      opt.value = values[i];
      opt.innerHTML = values[i];
      selector.appendChild(opt);
    }
  },
};

class MenuDrawer extends HTMLElement {
  constructor() {
    super();

    this.mainDetailsToggle = this.querySelector('details');

    this.addEventListener('keyup', this.onKeyUp.bind(this));
    this.addEventListener('focusout', this.onFocusOut.bind(this));
    this.bindEvents();
  }

  bindEvents() {
    this.querySelectorAll('summary').forEach((summary) =>
      summary.addEventListener('click', this.onSummaryClick.bind(this))
    );
    this.querySelectorAll('button:not(.localization-selector)').forEach((button) =>
      button.addEventListener('click', this.onCloseButtonClick.bind(this))
    );
  }

  onKeyUp(event) {
    if (event.code.toUpperCase() !== 'ESCAPE') return;

    const openDetailsElement = event.target.closest('details[open]');
    if (!openDetailsElement) return;

    openDetailsElement === this.mainDetailsToggle
      ? this.closeMenuDrawer(event, this.mainDetailsToggle.querySelector('summary'))
      : this.closeSubmenu(openDetailsElement);
  }

  onSummaryClick(event) {
    const summaryElement = event.currentTarget;
    const detailsElement = summaryElement.parentNode;
    const parentMenuElement = detailsElement.closest('.has-submenu');
    const isOpen = detailsElement.hasAttribute('open');
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

    function addTrapFocus() {
      trapFocus(summaryElement.nextElementSibling, detailsElement.querySelector('button'));
      summaryElement.nextElementSibling.removeEventListener('transitionend', addTrapFocus);
    }

    if (detailsElement === this.mainDetailsToggle) {
      if (isOpen) event.preventDefault();
      isOpen ? this.closeMenuDrawer(event, summaryElement) : this.openMenuDrawer(summaryElement);

      if (window.matchMedia('(max-width: 990px)')) {
        document.documentElement.style.setProperty('--viewport-height', `${window.innerHeight}px`);
      }
    } else {
      setTimeout(() => {
        detailsElement.classList.add('menu-opening');
        summaryElement.setAttribute('aria-expanded', true);
        parentMenuElement && parentMenuElement.classList.add('submenu-open');
        !reducedMotion || reducedMotion.matches
          ? addTrapFocus()
          : summaryElement.nextElementSibling.addEventListener('transitionend', addTrapFocus);
      }, 100);
    }
  }

  openMenuDrawer(summaryElement) {
    setTimeout(() => {
      this.mainDetailsToggle.classList.add('menu-opening');
    });
    summaryElement.setAttribute('aria-expanded', true);
    trapFocus(this.mainDetailsToggle, summaryElement);
    document.body.classList.add(`overflow-hidden-${this.dataset.breakpoint}`);
  }

  closeMenuDrawer(event, elementToFocus = false) {
    if (event === undefined) return;

    this.mainDetailsToggle.classList.remove('menu-opening');
    this.mainDetailsToggle.querySelectorAll('details').forEach((details) => {
      details.removeAttribute('open');
      details.classList.remove('menu-opening');
    });
    this.mainDetailsToggle.querySelectorAll('.submenu-open').forEach((submenu) => {
      submenu.classList.remove('submenu-open');
    });
    document.body.classList.remove(`overflow-hidden-${this.dataset.breakpoint}`);
    removeTrapFocus(elementToFocus);
    this.closeAnimation(this.mainDetailsToggle);

    if (event instanceof KeyboardEvent) elementToFocus?.setAttribute('aria-expanded', false);
  }

  onFocusOut() {
    setTimeout(() => {
      if (this.mainDetailsToggle.hasAttribute('open') && !this.mainDetailsToggle.contains(document.activeElement))
        this.closeMenuDrawer();
    });
  }

  onCloseButtonClick(event) {
    const detailsElement = event.currentTarget.closest('details');
    this.closeSubmenu(detailsElement);
  }

  closeSubmenu(detailsElement) {
    const parentMenuElement = detailsElement.closest('.submenu-open');
    parentMenuElement && parentMenuElement.classList.remove('submenu-open');
    detailsElement.classList.remove('menu-opening');
    detailsElement.querySelector('summary').setAttribute('aria-expanded', false);
    removeTrapFocus(detailsElement.querySelector('summary'));
    this.closeAnimation(detailsElement);
  }

  closeAnimation(detailsElement) {
    let animationStart;

    const handleAnimation = (time) => {
      if (animationStart === undefined) {
        animationStart = time;
      }

      const elapsedTime = time - animationStart;

      if (elapsedTime < 400) {
        window.requestAnimationFrame(handleAnimation);
      } else {
        detailsElement.removeAttribute('open');
        if (detailsElement.closest('details[open]')) {
          trapFocus(detailsElement.closest('details[open]'), detailsElement.querySelector('summary'));
        }
      }
    };

    window.requestAnimationFrame(handleAnimation);
  }
}

customElements.define('menu-drawer', MenuDrawer);

class HeaderDrawer extends MenuDrawer {
  constructor() {
    super();
  }

  openMenuDrawer(summaryElement) {
    this.header = this.header || document.querySelector('.section-header');
    this.borderOffset =
      this.borderOffset || this.closest('.header-wrapper').classList.contains('header-wrapper--border-bottom') ? 1 : 0;
    document.documentElement.style.setProperty(
      '--header-bottom-position',
      `${parseInt(this.header.getBoundingClientRect().bottom - this.borderOffset)}px`
    );
    this.header.classList.add('menu-open');

    setTimeout(() => {
      this.mainDetailsToggle.classList.add('menu-opening');
    });

    summaryElement.setAttribute('aria-expanded', true);
    window.addEventListener('resize', this.onResize);
    trapFocus(this.mainDetailsToggle, summaryElement);
    document.body.classList.add(`overflow-hidden-${this.dataset.breakpoint}`);
  }

  closeMenuDrawer(event, elementToFocus) {
    if (!elementToFocus) return;
    super.closeMenuDrawer(event, elementToFocus);
    this.header.classList.remove('menu-open');
    window.removeEventListener('resize', this.onResize);
  }

  onResize = () => {
    this.header &&
      document.documentElement.style.setProperty(
        '--header-bottom-position',
        `${parseInt(this.header.getBoundingClientRect().bottom - this.borderOffset)}px`
      );
    document.documentElement.style.setProperty('--viewport-height', `${window.innerHeight}px`);
  };
}

customElements.define('header-drawer', HeaderDrawer);

class ModalDialog extends HTMLElement {
  constructor() {
    super();
    this.querySelector('[id^="ModalClose-"]').addEventListener('click', this.hide.bind(this, false));
    this.addEventListener('keyup', (event) => {
      if (event.code.toUpperCase() === 'ESCAPE') this.hide();
    });
    if (this.classList.contains('media-modal')) {
      this.addEventListener('pointerup', (event) => {
        if (event.pointerType === 'mouse' && !event.target.closest('deferred-media, product-model')) this.hide();
      });
    } else {
      this.addEventListener('click', (event) => {
        if (event.target === this) this.hide();
      });
    }
  }

  connectedCallback() {
    if (this.moved) return;
    this.moved = true;
    document.body.appendChild(this);
  }

  show(opener) {
    this.openedBy = opener;
    const popup = this.querySelector('.template-popup');
    document.body.classList.add('overflow-hidden');
    this.setAttribute('open', '');
    if (popup) popup.loadContent();
    trapFocus(this, this.querySelector('[role="dialog"]'));
    window.pauseAllMedia();
  }

  hide() {
    if(this.classList.contains('quick-add-popup')){
      var thisElement = this;
      this.classList.add('close-popup');
      setTimeout(function(){
        thisElement.classList.remove('close-popup');
        document.body.classList.remove('overflow-hidden');
        document.body.dispatchEvent(new CustomEvent('modalClosed'));
        thisElement.removeAttribute('open');
        removeTrapFocus(thisElement.openedBy);
        window.pauseAllMedia();
      },300)
    }else{
      document.body.classList.remove('overflow-hidden');
      document.body.dispatchEvent(new CustomEvent('modalClosed'));
      this.removeAttribute('open');
      removeTrapFocus(this.openedBy);
      window.pauseAllMedia();
    }
  }
}
customElements.define('modal-dialog', ModalDialog);

class ModalOpener extends HTMLElement {
  constructor() {
    super();

    const button = this.querySelector('button');

    if (!button) return;
    button.addEventListener('click', () => {
      const modal = document.querySelector(this.getAttribute('data-modal'));
      if (modal) modal.show(button);
    });
  }
}
customElements.define('modal-opener', ModalOpener);

class DeferredMedia extends HTMLElement {
  constructor() {
    super();
    const poster = this.querySelector('[id^="Deferred-Poster-"]');
    const autoplay = this.dataset.autoplay;
    if (!poster) return;
    if (autoplay == 'true') {
      this.loadContent('autoplay');
      const videoImage = this.querySelector('video img');
      if(videoImage){
        videoImage.setAttribute("alt",'');
      }
    }
    poster.addEventListener('click', this.loadContent.bind(this));
  }

  loadContent(item,focus = true) {
    if(item == 'autoplay'){
      focus = false;
    }
    window.pauseAllMedia();
    if (!this.getAttribute('loaded')) {
      const content = document.createElement('div');
      content.appendChild(this.querySelector('template').content.firstElementChild.cloneNode(true));

      this.setAttribute('loaded', true);
      const deferredElement = this.appendChild(content.querySelector('video, model-viewer, iframe'));
      if (focus) deferredElement.focus();
      if (deferredElement.nodeName == 'VIDEO' && deferredElement.getAttribute('autoplay')) {
       if(item == 'autoplay'){
         deferredElement.muted = true;
         deferredElement.play();
       }else{
         deferredElement.play();
       }
      }
    }
  }
}

customElements.define('deferred-media', DeferredMedia);

class VariantSelects extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('change', this.onVariantChange);
  }

  onVariantChange(event) {
    this.updateSelectedValues();
    this.toggleAddButton(true, '', false);
    this.removeErrorMessage();

    const selectedOptionValueIds = this.getSelectedOptionValueIds();
    const productUrl = this.getCurrentProductUrl();
    this.fetchProductSection(productUrl, selectedOptionValueIds, event.target.id);
  }

  getSelectedOptionValueIds() {
    const radios = this.querySelectorAll('input[type="radio"]:checked');
    const selects = this.querySelectorAll('select');
    let ids = [];

    radios.forEach(radio => {
      const id = radio.dataset?.optionValueId;
      if (id) ids.push(id);
    });

    selects.forEach(select => {
      const selectedOption = select.options[select.selectedIndex];
      const id = selectedOption?.dataset?.optionValueId;
      if (id) ids.push(id);
    });

    return ids.filter(Boolean);
  }

  getCurrentProductUrl() {
    const checkedRadio = this.querySelector('input[type="radio"]:checked[data-product-url]');
    if (checkedRadio && checkedRadio.dataset.productUrl) {
      return checkedRadio.dataset.productUrl;
    }

    const selectedOption = this.querySelector('select option:checked[data-product-url]');
    if (selectedOption && selectedOption.dataset.productUrl) {
      return selectedOption.dataset.productUrl;
    }

    return this.dataset.productUrl || this.dataset.url;
  }

  getSectionId() {
    return this.dataset.originalSection || this.dataset.section;
  }

  getDisplaySectionId() {
    return this.dataset.section;
  }

  isProductPage() {
    return window.location.pathname.includes('/products/') || 
           document.querySelector('body.template-product') !== null;
  }

  isInPopup() {
    return this.closest('quick-add-popup') !== null;
  }

  isCollectionPage() {
    return window.location.pathname.includes('/collections/') || 
           window.location.pathname.includes('/search');
  }

  fetchProductSection(productUrl, optionValueIds, focusId) {
    const originalSectionId = this.getSectionId();
    const displaySectionId = this.getDisplaySectionId();
    const params = optionValueIds.length > 0 
      ? `&option_values=${optionValueIds.join(',')}` 
      : '';

    fetch(`${productUrl}?section_id=${originalSectionId}${params}`)
      .then(response => response.text())
      .then(responseText => {
        let html = new DOMParser().parseFromString(responseText, 'text/html');

        if (this.dataset.originalSection) {
          const tempDiv = document.createElement('div');
          tempDiv.innerHTML = responseText.replaceAll(originalSectionId, displaySectionId);
          html = new DOMParser().parseFromString(tempDiv.innerHTML, 'text/html');
        }

        const oldProductUrl = this.dataset.productUrl;
        const newProductUrl = productUrl;
        const productChanged = newProductUrl && oldProductUrl !== newProductUrl;
        const allowCombinedListing = this.shouldAllowCombinedListing();

        if (productChanged && allowCombinedListing) {
          if (this.isInPopup()) {
            this.handlePopupProductChange(html, newProductUrl, displaySectionId);
            return;
          }
          this.dataset.productUrl = newProductUrl;

          if (this.dataset.updateUrl !== 'false') {
            const variantInput = html.querySelector(`#product-form-${displaySectionId} input[name="id"]`);
            const variantId = variantInput?.value;
            
            const newUrlWithVariant = variantId 
              ? `${newProductUrl}?variant=${variantId}`
              : newProductUrl;
              
            window.history.replaceState({}, '', newUrlWithVariant);
          }

          const sourceSection = html.querySelector(`#shopify-section-${displaySectionId}`) || 
                              html.querySelector(`[data-section-id="${displaySectionId}"]`);
          const destSection = document.querySelector(`#shopify-section-${displaySectionId}`) || 
                            document.querySelector(`.quick-add-popup__content-info`);

          if (sourceSection && destSection) {
            const scrollY = window.scrollY;
            destSection.innerHTML = sourceSection.innerHTML;
            window.scrollTo(0, scrollY);
          }

          return;
        }
        this.updateVariantDetails(html, displaySectionId, optionValueIds, focusId);
      })
      .catch(e => console.error('Error fetching product section:', e));
  }

  shouldAllowCombinedListing() {
    const allowInPopup = this.dataset.allowCombinedInPopup === 'true';
    const allowInCollection = this.dataset.allowCombinedInCollection === 'true';

    if (this.isProductPage() && !this.isInPopup()) {
      return true;
    }

    if (this.isInPopup() && this.isCollectionPage() && allowInCollection && allowInPopup) {
      return true;
    }

    return false;
  }

  handlePopupProductChange(html, newProductUrl, displaySectionId) {
    this.dataset.productUrl = newProductUrl;

    const popup = this.closest('quick-add-popup');
    if (!popup) return;

    const titleSource = html.querySelector('.product__title h1');
    const titleDest = popup.querySelector('a.product__title .h2');
    if (titleSource && titleDest) {
      titleDest.textContent = titleSource.textContent;
    }

    const descriptionSource = html.querySelector('.product__description');
    const descriptionDest = popup.querySelector('.product__description');
    if (descriptionSource && descriptionDest) {
      descriptionDest.innerHTML = descriptionSource.innerHTML;
    }

    const linkSource = html.querySelector('.product__view-details');
    const linkDest = popup.querySelector('.product__view-details');

    if (linkSource && linkDest) {
      linkDest.setAttribute('href', linkSource.getAttribute('href'));
    }

    const productMediaSource = html.querySelector('.product__media-list');
    const productMediaDest = popup.querySelector('.product__media-list');
    if (productMediaSource && productMediaDest) {
      productMediaDest.innerHTML = productMediaSource.innerHTML;
    }

    const imageSource = html.querySelector('.product__media img, .product-image img');
    const imageDest = popup.querySelector('.product__media img, .product-image img');
    if (imageSource && imageDest) {
      imageDest.src = imageSource.src;
      imageDest.srcset = imageSource.srcset || '';
    }

    this.updateVariantDetails(html, displaySectionId, null, null);
  }

  updateVariantDetails(html, displaySectionId, optionValueIds, focusId) {
    const newPicker = html.querySelector(`#${this.id}`);
    if (newPicker) {
      const originalSection = this.dataset.originalSection;
      const currentProductUrl = this.dataset.productUrl;
      const currentSettings = {
        allowCombinedInPopup: this.dataset.allowCombinedInPopup,
        allowCombinedInCollection: this.dataset.allowCombinedInCollection
      };
      
      this.innerHTML = newPicker.innerHTML;
      
      if (originalSection) {
        this.dataset.originalSection = originalSection;
      }
      if (currentProductUrl) {
        this.dataset.productUrl = currentProductUrl;
      }
      Object.entries(currentSettings).forEach(([key, value]) => {
        if (value) this.dataset[key] = value;
      });

      if (optionValueIds) {
        this.restoreSelectedOptions(optionValueIds);
      }
    }

    const priceSource = html.getElementById(`price-${displaySectionId}`);
    const priceDestination = document.getElementById(`price-${displaySectionId}`);
    if (priceSource && priceDestination) {
      priceDestination.innerHTML = priceSource.innerHTML;
      priceDestination.classList.remove('hidden');
    }

    const skuSource = html.getElementById(`Sku-${displaySectionId}`);
    const skuDestination = document.getElementById(`Sku-${displaySectionId}`);
    if (skuSource && skuDestination) {
      skuDestination.innerHTML = skuSource.innerHTML;
      skuDestination.classList.toggle('hidden', skuSource.classList.contains('hidden'));
    }

    const inventorySource = html.getElementById(`Inventory-${displaySectionId}`);
    const inventoryDestination = document.getElementById(`Inventory-${displaySectionId}`);
    if (inventorySource && inventoryDestination) {
      inventoryDestination.innerHTML = inventorySource.innerHTML;
    }

    const addButtonSource = html.getElementById(`ProductSubmitButton-${displaySectionId}`);
    this.toggleAddButton(
      addButtonSource ? addButtonSource.hasAttribute('disabled') : true,
      window.variantStrings?.soldOut || 'Sold out'
    );

    this.updateVariantInput(html, displaySectionId);

    this.updateMedia(html, displaySectionId);

    this.updatePickupAvailability(html, displaySectionId);

    if (!this.dataset.originalSection && !this.isInPopup() && this.isProductPage()) {
      this.updateURL(html);
    }

    if (focusId) {
      const focusElement = document.getElementById(focusId);
      if (focusElement) focusElement.focus();
    }

    if (typeof publish !== 'undefined' && typeof PUB_SUB_EVENTS !== 'undefined') {
      publish(PUB_SUB_EVENTS.variantChange, {
        data: {
          sectionId: displaySectionId,
          html,
          productUrl: this.dataset.productUrl
        }
      });
    }
  }

  restoreSelectedOptions(optionValueIds) {
    optionValueIds.forEach(id => {
      const radio = this.querySelector(`input[type="radio"][data-option-value-id="${id}"]`);
      if (radio) {
        radio.checked = true;
      }

      const option = this.querySelector(`option[data-option-value-id="${id}"]`);
      if (option) {
        option.selected = true;
      }
    });
  }

  updateVariantInput(html, sectionId) {
    const productForms = document.querySelectorAll(
      `#product-form-${sectionId}, #product-form-installment-${sectionId}`
    );
    const sourceInput = html.querySelector(`#product-form-${sectionId} input[name="id"]`);
    
    if (!sourceInput) return;

    productForms.forEach(productForm => {
      const input = productForm.querySelector('input[name="id"]');
      if (input) {
        input.value = sourceInput.value;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
  }

  updateMedia(html, sectionId) {
    const mediaGalleries = document.querySelectorAll(
      `[id^="MediaGallery-${sectionId}"]`
    );
    
    if (!mediaGalleries.length) return;

    const variantInput = html.querySelector(`#product-form-${sectionId} input[name="id"]`);
    if (!variantInput) return;

    const variantId = variantInput.value;

    // Find media with matching variant
    const sourceMedia = html.querySelector(
      `[data-variant-media-id="${variantId}"], [data-media-variant-id="${variantId}"]`
    );
    
    if (!sourceMedia) return;

    const mediaId = sourceMedia.dataset.mediaId;

    mediaGalleries.forEach(gallery => {
      const galleryInstance = gallery.__galleryInstance; // attach instance when gallery is created

      if (galleryInstance && typeof galleryInstance.setActiveMedia === 'function') {
        // ✅ new way: set active media for non-slider galleries
        galleryInstance.setActiveMedia(mediaId, false);
      }

      // 🔹 fallback: click thumbnail for slider galleries
      const thumbnailButton = gallery.querySelector(`[data-target="${mediaId}"] button`);
      if (thumbnailButton) {
        thumbnailButton.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
        thumbnailButton.dispatchEvent(new PointerEvent('pointerup', { bubbles: true }));
        thumbnailButton.dispatchEvent(new MouseEvent('click', { bubbles: true }));
      }
    });
  }

  updatePickupAvailability(html, sectionId) {
    const pickUpAvailability = document.querySelector('pickup-availability');
    if (!pickUpAvailability) return;

    const variantInput = html.querySelector(`#product-form-${sectionId} input[name="id"]`);
    const addButtonSource = html.getElementById(`ProductSubmitButton-${sectionId}`);

    const variantId = variantInput?.value;
    const variantAvailable = addButtonSource && !addButtonSource.hasAttribute('disabled');

    if (variantAvailable && variantId) {
      pickUpAvailability.classList.remove('hidden', 'is-disabled');
      pickUpAvailability.fetchAvailability(variantId);
    } else {
      pickUpAvailability.classList.add('hidden', 'is-disabled');
    }
  }

  updateURL(html) {
    if (this.dataset.updateUrl === 'false') return;

    const input = html.querySelector('input[name="id"]');
    if (!input || !input.value) return;

    const newUrl = `${this.getCurrentProductUrl()}?variant=${input.value}`;
    window.history.replaceState({}, '', newUrl);

    const shareButton = document.querySelector('share-button');
    if (shareButton) {
      shareButton.updateUrl(newUrl);
    }
  }

  updateSelectedValues() {
    if (this.classList.contains('variant-select__options')) return;

    const selects = this.querySelectorAll('select');
    selects.forEach((select, index) => {
      const valueSpan = document.querySelector(`.product .selected__value[data-option-index="${index + 1}"]`);
      if (valueSpan) {
        valueSpan.textContent = select.value;
      }
    });
  }

  toggleAddButton(disable = true, text, modifyClass = true) {
    const sectionId = this.getDisplaySectionId();
    const productForm = document.getElementById(`product-form-${sectionId}`);
    if (!productForm) return;

    const addButton = productForm.querySelector('[name="add"]');
    const addButtonText = productForm.querySelector('[name="add"] > span');
    const suggestions = productForm.querySelector('.animate-suggestions');

    if (!addButton) return;

    if (disable) {
      addButton.setAttribute('disabled', 'disabled');
      if (text) addButtonText.textContent = text;
      if (suggestions) suggestions.classList.add('hidden');
    } else {
      addButton.removeAttribute('disabled');
      addButtonText.textContent = window.variantStrings?.addToCart || 'Add to cart';
      if (suggestions) suggestions.classList.remove('hidden');
    }
  }

  removeErrorMessage() {
    const section = this.closest('section');
    if (!section) return;

    const productForm = section.querySelector('product-form');
    if (productForm) productForm.handleErrorMessage();
  }
}

customElements.define('variant-selects', VariantSelects);

class VariantRadios extends VariantSelects {
  constructor() {
    super();
  }

  getSelectedOptionValueIds() {
    const fieldsets = this.querySelectorAll('fieldset');
    return Array.from(fieldsets).map(fieldset => {
      const checkedInput = fieldset.querySelector('input:checked');
      return checkedInput?.dataset?.optionValueId;
    }).filter(Boolean);
  }

  updateSelectedValues() {
    if (this.classList.contains('variant-select__options')) return;
    
    const fieldsets = this.querySelectorAll('fieldset');
    fieldsets.forEach((fieldset, index) => {
      const checkedInput = fieldset.querySelector('input:checked');
      if (checkedInput) {
        const valueSpan = document.querySelector(`.product .selected__value[data-option-index="${index + 1}"]`);
        if (valueSpan) {
          valueSpan.textContent = checkedInput.value;
        }
      }
    });
  }
}

customElements.define('variant-radios', VariantRadios);

class ProductRecommendations extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    this.handleIntersection();
  }

  handleIntersection() {
    fetch(this.dataset.url)
      .then((response) => response.text())
      .then((text) => {
        const html = document.createElement('div');
        html.innerHTML = text;
        const recommendations = html.querySelector('product-recommendations');

        if (recommendations && recommendations.innerHTML.trim().length) {
          this.innerHTML = recommendations.innerHTML;
        }

        if (!this.querySelector('complementary-products-slider') && this.classList.contains('complementary-products')) {
          this.remove();
        }

        if (html.querySelector('.grid__item')) {
          this.classList.add('product-recommendations--loaded');
        }

        if (recommendations && recommendations.classList.contains('related-products')) {
          const recommendationsId = recommendations.id;
          const recommendationsElement = document.getElementById(recommendationsId);
          if (recommendationsElement) {
            const checkMarquee = recommendationsElement.querySelectorAll('.marquee3k');
            const checkMarqueeElement = recommendationsElement.querySelector('.marquee-scrolling__option');
            if (checkMarquee.length > 0 && checkMarqueeElement) {
              Marquee3k.init(checkMarqueeElement);
            }
          }
        }  
      })
      .catch((e) => {
        console.error(e);
      });
  }
}

customElements.define('product-recommendations', ProductRecommendations);

function customJavascript() {
  (function Accordion() {
    function toggle(trigger) {
      if (trigger.collapseTarget.classList.contains("is-active")) {
        close(trigger);
        activeToggle = null;
      } else {
        activeToggle &&
        activeToggle.collapseTarget.dataset.parent &&
        close(activeToggle);
        trigger.collapseTarget.dataset.parent && (activeToggle = trigger);
        open(trigger);
      }
    }
    function close(trigger) {
      setHeight(trigger.collapseTarget);
      trigger.parentElement.classList.remove("is-active");
      if(trigger.closest('.multicolumn-card')) {
        trigger.closest('.multicolumn-card').classList.add(trigger.dataset.colorPrimary);
        trigger.closest('.multicolumn-card').classList.remove(trigger.dataset.colorSecondary);
        trigger.closest('.multicolumn-card').classList.remove('is-active');
      }
      trigger.classList.remove("is-active");
      trigger.collapseTarget.classList.remove("is-active");
      setTimeout(() => {
        trigger.collapseTarget.style.height = null;
      }, 0);
    }
    function open(trigger) {
      trigger.classList.add("is-active");
      trigger.parentElement.classList.add("is-active");
      if(trigger.closest('.multicolumn-card')) {
        trigger.closest('.multicolumn-card').classList.remove(trigger.dataset.colorPrimary);
        trigger.closest('.multicolumn-card').classList.add(trigger.dataset.colorSecondary);
        trigger.closest('.multicolumn-card').classList.add('is-active');
      }
      setTimeout(() => {
        setHeight(trigger.collapseTarget);
        trigger.collapseTarget.classList.add("is-active");
      }, 0);
    }
    function setHeight(target) {
      target.style.height = target.scrollHeight + "px";
    }
  })();
  
}
customJavascript()

// faq accordion js
class AccordionToggle extends HTMLElement {
  constructor() {
    super();
    this.trigger = this.querySelector('.accordion-toggle-btn');
    this.target = document.querySelector(this.trigger.dataset.toggle || this.trigger.dataset.target);
    this.handleClick = this.handleClick.bind(this);
    this.handleTransitionEnd = this.handleTransitionEnd.bind(this);
  }

  connectedCallback() {
    if (!this.trigger || !this.target) return;

    this.trigger.addEventListener('click', this.handleClick);
    this.target.addEventListener('transitionend', this.handleTransitionEnd);
  }

  disconnectedCallback() {
    this.trigger.removeEventListener('click', this.handleClick);
    this.target.removeEventListener('transitionend', this.handleTransitionEnd);
  }

  handleClick(e) {
    e.preventDefault();
    e.stopPropagation();
    this.toggle();
  }
    toggle() {
      const isActive = this.target.classList.contains('is-active');
      const svg = this.trigger.querySelector('.toggle-svg');
    
      if (this.target.dataset.parent) {
        document.querySelectorAll(this.target.dataset.parent + ' .is-active').forEach(el => {
          if (el !== this.target) {
            el.classList.remove('is-active');
            el.style.height = el.scrollHeight + 'px'; // Set height to trigger transition
            requestAnimationFrame(() => {
              el.style.height = '0px';
            });
    
            // Also remove active class from related svg
            const otherTrigger = document.querySelector(`[data-target="#${el.id}"], [data-toggle="#${el.id}"]`);
            if (otherTrigger) {
              const otherSvg = otherTrigger.querySelector('.toggle-svg');
              if (otherSvg) {
                otherSvg.classList.remove('active');
              }
            }
          }
        });
      }
    
      if (isActive) {
        this.target.style.height = this.target.scrollHeight + 'px'; // Set current height
        requestAnimationFrame(() => {
          this.target.classList.remove('is-active');
          this.target.style.height = '0px';
          if (svg) svg.classList.remove('active');
        });
      } else {
        this.target.style.height = this.target.scrollHeight + 'px'; // Set target height
        this.target.classList.add('is-active');
        if (svg) svg.classList.add('active');
      }
    }

   handleTransitionEnd(e) {
    if (e.target.classList.contains('is-active')) {
      e.target.style.height = null;
    }
  }

}

customElements.define('accordion-toggle', AccordionToggle);

// Swiper slider js
class SwipeSlider extends HTMLElement {
  constructor() {
    super();
    this.swiperInstance = null;
    this.handleResize = this.handleResize.bind(this);
    this.currentDirection = null;
  }

  connectedCallback() {
    this.checkAndInitSwiper();
    window.addEventListener('resize', this.handleResize);
  }

  disconnectedCallback() {
    window.removeEventListener('resize', this.handleResize);
    if (this.swiperInstance) {
      this.swiperInstance.destroy(true, true);
    }
  }

  checkAndInitSwiper() {
    const swiperContainer = this.querySelector('.swiper');
    if (!swiperContainer) return;

    const enableDesktopSlider = swiperContainer.dataset.enableDesktopSlider;
    const enableMobileSlider = swiperContainer.dataset.enableMobileSlider;
    
    if (enableDesktopSlider === undefined && enableMobileSlider === undefined) {
      this.initSwiper();
      return;
    }

    const isDesktopSliderEnabled = enableDesktopSlider === 'true';
    const isMobileSliderEnabled = enableMobileSlider === 'true';
    const isMobile = window.innerWidth < 750;

    if (this.swiperInstance) {
      this.swiperInstance.destroy(true, true);
      this.swiperInstance = null;
    }

    if ((isMobile && isMobileSliderEnabled) || (!isMobile && isDesktopSliderEnabled)) {
      this.initSwiper();
    }
  }

  getDirection() {
    const originalDirection = this.dataset.direction || 'horizontal';
    const isDesktop = window.innerWidth >= 989;
    return isDesktop ? originalDirection : 'horizontal';
  }

  initSwiper() {
    const swiperContainer = this.querySelector('.swiper');
    if (!swiperContainer) return;
    
    const isFullSlider = swiperContainer.dataset.full === 'true';
    const slidesCount = swiperContainer.querySelectorAll('.swiper-slide').length;

    // Get slide counts with fallbacks for backward compatibility
    const desktopSlides = parseInt(swiperContainer.dataset.desktopSlide) || 4;
    const tabletSlides = parseInt(swiperContainer.dataset.tabletSlide);
    const tabletSlidesBase = isNaN(tabletSlides) ? 2 : tabletSlides;
    const mobileSlides = parseInt(swiperContainer.dataset.mobileSlide);
    const mobileSlidesBase = isNaN(mobileSlides) ? 1 : mobileSlides;

    const getSlidesWithPeek = (baseSlides) => {
      if (isFullSlider) return baseSlides;
      return slidesCount > baseSlides ? baseSlides + 0.2 : baseSlides;
    };

    const desktopSlidesFinal = getSlidesWithPeek(desktopSlides);
    const tabletSlidesFinal = getSlidesWithPeek(tabletSlidesBase);
    const mobileSlidesFinal = getSlidesWithPeek(mobileSlidesBase);

    const autoplayEnabled = swiperContainer.dataset.autoplay === 'true';
    const autoplayDelay = parseInt(swiperContainer.dataset.delay) || 3000;
    const loopEnabled = swiperContainer.dataset.loop === 'true';

    const direction = this.getDirection();
    const navWrapper = this.querySelector('.swiper_arrows');

    this.currentDirection = direction;

    // Look for navigation buttons both inside swiper container and in parent element
    const nextBtn = this.querySelector('.swipe-button-next');
    const prevBtn = this.querySelector('.swipe-button-prev');
    const paginationEl = this.querySelector('.swiper-pagination');

    this.swiperInstance = new Swiper(swiperContainer, {
      direction: direction,
      slidesPerView: desktopSlidesFinal,
      speed: 300,
      spaceBetween: 15,
      loop: loopEnabled,
      autoplay: autoplayEnabled ? {
        delay: autoplayDelay,
        disableOnInteraction: false,
        pauseOnMouseEnter: true
      } : false,

      navigation: {
        nextEl: nextBtn,
        prevEl: prevBtn,
      },

      pagination: paginationEl ? {
        el: paginationEl,
        clickable: true,
      } : false,
      
      breakpoints: {
        320: { slidesPerView: mobileSlidesFinal, spaceBetween: 15 },
        750: { slidesPerView: tabletSlidesFinal, spaceBetween: 15 },
        989: { slidesPerView: desktopSlidesFinal },
      },
      on: {
        afterInit: (swiper) => {
          this.toggleArrows(navWrapper, slidesCount, swiper.params.slidesPerView);
        },
        resize: (swiper) => {
          this.toggleArrows(navWrapper, slidesCount, swiper.params.slidesPerView);
        }
      }
    });
  }

  toggleArrows(navWrapper, slidesCount, visibleSlides) {
    if (!navWrapper) return;
    if (slidesCount <= visibleSlides) {
      navWrapper.classList.add('no-arrows');
    } else {
      navWrapper.classList.remove('no-arrows');
    }
  }

  handleResize() {
    const newDirection = this.getDirection();
    
    // For sections with mobile slider settings
    const swiperContainer = this.querySelector('.swiper');
    if (swiperContainer) {
      const hasMobileSliderSettings = swiperContainer.dataset.enableDesktopSlider !== undefined || 
                                     swiperContainer.dataset.enableMobileSlider !== undefined;
      
      if (hasMobileSliderSettings) {
        this.checkAndInitSwiper();
        return;
      }
    }
    
    // Default behavior for other sections
    if (newDirection !== this.currentDirection) {
      this.initSwiper();
    }
  }
}

customElements.define('swipe-slider', SwipeSlider);

// ComplementaryProductsSlider js
class ComplementaryProductsSlider extends HTMLElement {
  constructor() {
    super();
    this.swiperInstance = null;
    this.handleResize = this.handleResize.bind(this);
    this.currentDirection = null;
    this.savedRatio = null;
  }

  connectedCallback() {
    this.initSwiper();
    window.addEventListener('resize', this.handleResize);
  }

  disconnectedCallback() {
    window.removeEventListener('resize', this.handleResize);
  }

  getDirection() {
    const originalDirection = this.dataset.direction || 'horizontal';
    const isDesktop = window.innerWidth >= 989;
    return isDesktop ? originalDirection : 'horizontal';
  }

  calculateRatio() {
    const isDesktop = window.innerWidth >= 989;
    if (isDesktop && this.dataset.direction === 'vertical') {
      const desktopSlides = parseInt(this.dataset.desktopSlide);
      if (!isNaN(desktopSlides) && desktopSlides > 0) {
        return `122%`;
      }
    }
    return null;
  }

  setRatio(ratio) {
    const slides = this.querySelectorAll('.swiper-slide');
    if (slides.length && ratio) {
      slides.forEach(slide => {
        slide.style.setProperty('--aspect-ratio-percent', ratio);
      });
    }
  }

  initSwiper() {
    const swiperContainer = this;

    const desktopSlides = parseInt(swiperContainer.dataset.desktopSlide);
    const tabletSlides = parseInt(swiperContainer.dataset.tabletSlide);
    const tabletSlidesCount = isNaN(tabletSlides) ? 2 : tabletSlides;
    const mobileSlides = parseInt(swiperContainer.dataset.mobileSlide);
    const mobileSlidesCount = isNaN(mobileSlides) ? 1 : mobileSlides;
    const productPerCol = parseInt(swiperContainer.dataset.productPerCol);
    const productPerColCount = isNaN(productPerCol) ? 1 : productPerCol;

    const direction = this.getDirection();
    const isVertical = direction === 'vertical';

    if (this.swiperInstance) {
      this.swiperInstance.destroy(true, true);
    }

    this.currentDirection = direction;

    this.swiperInstance = new Swiper(swiperContainer, {
      direction: direction,
      slidesPerView: desktopSlides,
      speed: 300,
      spaceBetween: 20,
      ...(isVertical ? {
        grid: {
          rows: productPerColCount,
          fill: 'column',
        }
      } : {}),
      navigation: {
        nextEl: swiperContainer.querySelector('.swipe-button-next'),
        prevEl: swiperContainer.querySelector('.swipe-button-prev'),
      },
      breakpoints: {
        320: { slidesPerView: mobileSlidesCount, spaceBetween: 10 },
        750: { slidesPerView: tabletSlidesCount, spaceBetween: 15 },
        989: {
          slidesPerView: desktopSlides,
          ...(isVertical ? {
            grid: {
              rows: productPerColCount,
              fill: 'column',
            }
          } : {}),
        }
      }
    });

    const calculatedRatio = this.calculateRatio();
    this.setRatio(calculatedRatio);
  }

  handleResize() {
    const newDirection = this.getDirection();
    if (newDirection !== this.currentDirection) {
      this.initSwiper();
    } else {
      const calculatedRatio = this.calculateRatio();
      this.setRatio(calculatedRatio);
    }
  }
}

customElements.define('complementary-products-slider', ComplementaryProductsSlider);

// Highlight heading height
class HighlightHeading {
  constructor(element) {
    this.element = element;
    this.updateHeight();
  }
  updateHeight() {
    const totalHeightHighlightHeading = this.element.offsetHeight;
    document.documentElement.style.setProperty('--section-heading__bar', `${totalHeightHighlightHeading}px`);
  }
}
  document.querySelectorAll('.image-with-highlight .section-heading__bar').forEach(el => {
  new HighlightHeading(el);
});

// Highlight image height
class SectionImageWithHighlight {
  connectedCallback() {
    const highlightImageSize = document.querySelector('.image-with-highlight-block-img');
    if (!highlightImageSize) return;

    const totalHeight = highlightImageSize.offsetHeight;
    document.documentElement.style.setProperty('--image-with-highlight-img-height', `${totalHeight}px`);
  }
}
const highlightImageSizeInstance = new SectionImageWithHighlight();
highlightImageSizeInstance.connectedCallback();

class SectionWithHighlightmain {
  connectedCallback() {
    const highlightContainerSize = document.querySelector('.image-with-highlight-block-img-content-container');
    if (!highlightContainerSize) return;

    const totalHeight = highlightContainerSize.offsetHeight;
    document.documentElement.style.setProperty('--image-with-highlight-container-height', `${totalHeight}px`);
  }
}
const highlightSizeContInstance = new SectionWithHighlightmain();
highlightSizeContInstance.connectedCallback();

// articlecards hover animation js
class ArticleCard extends HTMLElement {
  connectedCallback() {
    this.card = this.querySelector('.article-card-content');
    if (!this.card) return;

    this.allCards = [...document.querySelectorAll('article-card')];
    this.index = this.allCards.indexOf(this);

    this.updateHeight = this.updateHeight.bind(this);

    this.resizeObserver = new ResizeObserver(() => {
      this.updateHeight();
    });

    this.resizeObserver.observe(this.card);

    requestAnimationFrame(this.updateHeight);
  }

  updateHeight() {
    const height = this.card.offsetHeight;

    document.documentElement.style.setProperty(
      `--total-height-card-${this.index}`,
      `${height}px`
    );

    this.card.style.bottom = `calc(20px - ${height}px)`;
  }

  disconnectedCallback() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
  }
}

customElements.define('article-card', ArticleCard);
