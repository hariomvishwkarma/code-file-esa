class QuickPurchase extends HTMLElement {
  constructor() {
    super();
  }  

  connectedCallback() {
    this.setupListener();
  }

  setupListener() {
    const marqueeProductItems = this.querySelectorAll('.quick-purchase-product-list li');
    const productDetailItems = this.querySelectorAll('.quick-purchase-product-detail li');
    const marqueeProductsContainer = this.querySelector('.quick-purchase-product-marquee');
    const productDetailContainer = this.querySelector('.quick-purchase-product-detail');
    marqueeProductItems.forEach(item => {
      item.addEventListener('click', () => {
        const clickedProductId = item.getAttribute('product-id');
        
        marqueeProductsContainer?.classList.add('quick-purchase-product-marquee-width');
        productDetailContainer?.classList.add('quick-purchase-product-detail-width');

        productDetailItems.forEach(detailItem => {
          detailItem.classList.add('hidden-active');
        });

        const matchingDetailItem = Array.from(productDetailItems).find(detailItem => {
          return detailItem.getAttribute('product-id') === clickedProductId;
        });

        if (matchingDetailItem) {
          matchingDetailItem.classList.remove('hidden-active');
        }
      });
    });
  }
}
customElements.define('quick-purchase', QuickPurchase);