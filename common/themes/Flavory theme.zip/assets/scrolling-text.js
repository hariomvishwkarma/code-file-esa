!(function (t, e) {
  "function" == typeof define && define.amd
    ? define([], e)
    : "object" == typeof exports
    ? (module.exports = e())
    : (t.Marquee3k = e());
})(this, function () {
  "use strict";
  let t = 0;
  let MARQUEES = [];

  class e {
    constructor(t, e) {
      if (!t || !t.querySelector(".marquee-scrolling-item")) {
        console.warn("Marquee3k: Element has no .marquee-scrolling-item.");
        return;
      }

      this.element = t;
      this.selector = e.selector;
      this.speed = parseFloat(t.dataset.speed) || 1;
      this.pausable = t.dataset.pausable === "true" ? 1 : -1;
      this.reverse = t.dataset.reverse === "true";
      this.paused = false;
      this.parent = t.parentElement;
      this.parentProps = this.parent.getBoundingClientRect();
      this.content = t.children[0];
      this.innerContent = this.content.innerHTML;
      this.offset = 0;
      this.isResizing = false; // Add resize flag
      this._setupWrapper();
      this._setupContent();
      this._setupEvents();
      this.wrapper.appendChild(this.content);
      this.element.appendChild(this.wrapper);
      this.lastFrameTime = null;
    }

    _setupWrapper() {
      this.wrapper = document.createElement("div");
      this.wrapper.classList.add("marquee3k__wrapper");
      this.wrapper.style.whiteSpace = "nowrap";
    }

    _setupContent() {
      this.content.classList.add(`${this.selector}__copy`);
      this.content.style.display = "inline-flex";
      this.contentWidth = this.content.offsetWidth;
      
      // Calculate required repetitions with a maximum limit
      const maxReps = 20; // Prevent excessive clone creation
      this.requiredReps =
        this.contentWidth > this.parentProps.width
          ? 2
          : Math.min(
              Math.ceil((this.parentProps.width - this.contentWidth) / this.contentWidth) + 1,
              maxReps
            );

      for (let i = 0; i < this.requiredReps; i++) this._createClone();
      if (this.reverse) this.offset = -1 * this.contentWidth;
      this.element.classList.add("is-init");
    }

    _setupEvents() {
      this.element.addEventListener("mouseenter", () => {
        if (this.pausable) this.paused = true;
      });
      this.element.addEventListener("mouseleave", () => {
        if (this.pausable) this.paused = false;
      });
    }

    _createClone() {
      const clone = this.content.cloneNode(true);
      clone.style.display = "inline-flex";
      clone.classList.add(`${this.selector}__copy`);
      clone.classList.add(`${this.selector}__clone`); // Add identifier for clones
      this.wrapper.appendChild(clone);
    }

    _removeClones() {
      // Remove all cloned elements, keeping only the original
      const clones = this.wrapper.querySelectorAll(`.${this.selector}__clone`);
      clones.forEach(clone => clone.remove());
    }

    animate() {
      // Skip animation during resize to prevent performance issues
      if (!this.paused && !this.isResizing) {
        const now = Date.now();
        let deltaTime = 0;
        if (this.lastFrameTime) deltaTime = now - this.lastFrameTime;
        this.lastFrameTime = now;

        const distance = this.speed * deltaTime / 16;
        const shouldContinue = this.reverse
          ? this.offset < 0
          : this.offset > -1 * this.contentWidth;
        const direction = this.reverse ? -1 : 1;
        const resetPoint = this.reverse ? -1 * this.contentWidth : 0;

        this.offset = shouldContinue
          ? this.offset - distance * direction
          : resetPoint;

        this.wrapper.style.whiteSpace = "nowrap";
        this.wrapper.style.transform = `translate(${this.offset}px, 0) translateZ(0)`;
      }
    }

    _refresh() {
      this.parentProps = this.parent.getBoundingClientRect();
      this.contentWidth = this.content.offsetWidth;
      
      // Rebuild content with proper number of clones
      this._removeClones();
      
      const maxReps = 20;
      this.requiredReps =
        this.contentWidth > this.parentProps.width
          ? 2
          : Math.min(
              Math.ceil((this.parentProps.width - this.contentWidth) / this.contentWidth) + 1,
              maxReps
            );
      
      for (let i = 0; i < this.requiredReps; i++) this._createClone();
    }

    repopulate(t, e) {
      // Complete rebuild instead of incremental addition
      this._refresh();
    }

    destroy() {
      // Cleanup method for removing event listeners and clones
      this._removeClones();
      this.wrapper.remove();
    }

    static refresh(i) {
      if (MARQUEES[i]) MARQUEES[i]._refresh();
    }

    static pause(i) {
      if (MARQUEES[i]) MARQUEES[i].paused = true;
    }

    static play(i) {
      if (MARQUEES[i]) MARQUEES[i].paused = false;
    }

    static toggle(i) {
      if (MARQUEES[i]) MARQUEES[i].paused = !MARQUEES[i].paused;
    }

    static refreshAll() {
      for (let i = 0; i < MARQUEES.length; i++) {
        if (MARQUEES[i]) MARQUEES[i]._refresh();
      }
    }

    static pauseAll() {
      for (let i = 0; i < MARQUEES.length; i++) {
        if (MARQUEES[i]) MARQUEES[i].paused = true;
      }
    }

    static playAll() {
      for (let i = 0; i < MARQUEES.length; i++) {
        if (MARQUEES[i]) MARQUEES[i].paused = false;
      }
    }

    static toggleAll() {
      for (let i = 0; i < MARQUEES.length; i++) {
        if (MARQUEES[i]) MARQUEES[i].paused = !MARQUEES[i].paused;
      }
    }

    static init(options = { selector: "marquee3k" }) {
      if (!document.querySelector(`.${options.selector}`)) return;

      const elements = Array.from(document.querySelectorAll(`.${options.selector}`));
      if (!elements.length) return;

      let resizeTimer;
      let resizeDebounceTimer;
      let prevWidth = window.innerWidth;

      for (let i = 0; i < elements.length; i++) {
        const instance = new e(elements[i], options);
        if (instance.content) {
          MARQUEES.push(instance);
        }
      }

      function animate() {
        for (let i = 0; i < MARQUEES.length; i++) {
          if (MARQUEES[i]) MARQUEES[i].animate();
        }
        requestAnimationFrame(animate);
      }

      requestAnimationFrame(animate);

      window.addEventListener("resize", () => {
        // Pause animations during resize
        for (let i = 0; i < MARQUEES.length; i++) {
          if (MARQUEES[i]) MARQUEES[i].isResizing = true;
        }

        clearTimeout(resizeTimer);
        clearTimeout(resizeDebounceTimer);
        
        // Quick debounce to set resize flag
        resizeDebounceTimer = setTimeout(() => {
          const currentWidth = window.innerWidth;
          
          // Only repopulate if width actually changed significantly (>50px)
          if (Math.abs(currentWidth - prevWidth) > 50) {
            for (let i = 0; i < MARQUEES.length; i++) {
              if (MARQUEES[i]) {
                MARQUEES[i]._refresh();
              }
            }
            prevWidth = currentWidth;
          }
          
          // Resume animations
          for (let i = 0; i < MARQUEES.length; i++) {
            if (MARQUEES[i]) MARQUEES[i].isResizing = false;
          }
        }, 500); // Increased debounce time for better performance
      });

      // Handle zoom detection specifically
      let lastDevicePixelRatio = window.devicePixelRatio;
      
      window.addEventListener("resize", () => {
        if (window.devicePixelRatio !== lastDevicePixelRatio) {
          // Zoom detected
          lastDevicePixelRatio = window.devicePixelRatio;
          
          clearTimeout(resizeTimer);
          resizeTimer = setTimeout(() => {
            for (let i = 0; i < MARQUEES.length; i++) {
              if (MARQUEES[i]) {
                MARQUEES[i]._refresh();
              }
            }
          }, 1000); // Longer delay for zoom events
        }
      });
    }

    static destroy() {
      // Global cleanup method
      for (let i = 0; i < MARQUEES.length; i++) {
        if (MARQUEES[i]) {
          MARQUEES[i].destroy();
        }
      }
      MARQUEES = [];
    }
  }

  return e;
});

// Initialize if Marquee3k is available
if (typeof Marquee3k !== 'undefined') {
  Marquee3k.init();
}