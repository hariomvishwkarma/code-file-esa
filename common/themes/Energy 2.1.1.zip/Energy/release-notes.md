Introduced revised preset naming and theme file structure.

### Changed
- Updated preset names and reorganized theme files to align with the Theme Store redesign.

### Fixed
- Fixed an issue where the theme editor failed to load if a 'Scrolling text' section did not contain at least one scrolling content block.