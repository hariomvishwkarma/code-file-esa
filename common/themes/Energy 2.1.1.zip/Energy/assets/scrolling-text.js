!(function (t, e) {
  "function" == typeof define && define.amd
    ? define([], e)
    : "object" == typeof exports
    ? (module.exports = e())
    : (t.Marquee3k = e());
})(this, function () {
  "use strict";
  let t = 0;
  let MARQUEES = [];

  class e {
    constructor(t, e) {
      if (!t || !t.querySelector(".marquee-scrolling-item")) {
        console.warn("Marquee3k: Element has no .marquee-scrolling-item.");
        return;
      }

      this.element = t;
      this.selector = e.selector;
      this.speed = parseFloat(t.dataset.speed) || 1;
      this.pausable = t.dataset.pausable === "true" ? 1 : -1;
      this.reverse = t.dataset.reverse === "true";
      this.paused = false;
      this.parent = t.parentElement;
      this.parentProps = this.parent.getBoundingClientRect();
      this.content = t.children[0];
      this.innerContent = this.content.innerHTML;
      this.offset = 0;
      this._setupWrapper();
      this._setupContent();
      this._setupEvents();
      this.wrapper.appendChild(this.content);
      this.element.appendChild(this.wrapper);
      this.lastFrameTime = null;
    }

    _setupWrapper() {
      this.wrapper = document.createElement("div");
      this.wrapper.classList.add("marquee3k__wrapper");
      this.wrapper.style.whiteSpace = "nowrap";
    }

    _setupContent() {
      this.content.classList.add(`${this.selector}__copy`);
      this.content.style.display = "inline-block";
      this.contentWidth = this.content.offsetWidth;
      this.requiredReps =
        this.contentWidth > this.parentProps.width
          ? 2
          : Math.ceil((this.parentProps.width - this.contentWidth) / this.contentWidth) + 1;

      for (let i = 0; i < this.requiredReps; i++) this._createClone();
      if (this.reverse) this.offset = -1 * this.contentWidth;
      this.element.classList.add("is-init");
    }

    _setupEvents() {
      this.element.addEventListener("mouseenter", () => {
        if (this.pausable) this.paused = true;
      });
      this.element.addEventListener("mouseleave", () => {
        if (this.pausable) this.paused = false;
      });
    }

    _createClone() {
      const clone = this.content.cloneNode(true);
      clone.style.display = "inline-block";
      clone.classList.add(`${this.selector}__copy`);
      this.wrapper.appendChild(clone);
    }

    animate() {
      if (!this.paused) {
        const now = Date.now();
        let deltaTime = 0;
        if (this.lastFrameTime) deltaTime = now - this.lastFrameTime;
        this.lastFrameTime = now;

        const distance = this.speed * deltaTime / 16;
        const shouldContinue = this.reverse
          ? this.offset < 0
          : this.offset > -1 * this.contentWidth;
        const direction = this.reverse ? -1 : 1;
        const resetPoint = this.reverse ? -1 * this.contentWidth : 0;

        this.offset = shouldContinue
          ? this.offset - distance * direction
          : resetPoint;

        this.wrapper.style.whiteSpace = "nowrap";
        this.wrapper.style.transform = `translate(${this.offset}px, 0) translateZ(0)`;
      }
    }

    _refresh() {
      this.contentWidth = this.content.offsetWidth;
    }

    repopulate(t, e) {
      this.contentWidth = this.content.offsetWidth;
      if (e) {
        const reps = Math.ceil(t / this.contentWidth) + 1;
        for (let i = 0; i < reps; i++) this._createClone();
      }
    }

    static refresh(i) {
      MARQUEES[i]._refresh();
    }

    static pause(i) {
      MARQUEES[i].paused = true;
    }

    static play(i) {
      MARQUEES[i].paused = false;
    }

    static toggle(i) {
      MARQUEES[i].paused = !MARQUEES[i].paused;
    }

    static refreshAll() {
      for (let i = 0; i < MARQUEES.length; i++) MARQUEES[i]._refresh();
    }

    static pauseAll() {
      for (let i = 0; i < MARQUEES.length; i++) MARQUEES[i].paused = true;
    }

    static playAll() {
      for (let i = 0; i < MARQUEES.length; i++) MARQUEES[i].paused = false;
    }

    static toggleAll() {
      for (let i = 0; i < MARQUEES.length; i++) MARQUEES[i].paused = !MARQUEES[i].paused;
    }

    static init(options = { selector: "marquee3k" }) {
      if (!document.querySelector(`.${options.selector}`)) return;

      const elements = Array.from(document.querySelectorAll(`.${options.selector}`));
      if (!elements.length) return;

      let resizeTimer;
      let prevWidth = window.innerWidth;

      for (let i = 0; i < elements.length; i++) {
        const instance = new e(elements[i], options);
        if (instance.content) {
          MARQUEES.push(instance);
        }
      }

      function animate() {
        for (let i = 0; i < MARQUEES.length; i++) MARQUEES[i].animate();
        requestAnimationFrame(animate);
      }

      requestAnimationFrame(animate);

      window.addEventListener("resize", () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
          const hasGrown = prevWidth < window.innerWidth;
          const diff = window.innerWidth - prevWidth;
          for (let i = 0; i < MARQUEES.length; i++) {
            MARQUEES[i].repopulate(diff, hasGrown);
          }
          prevWidth = window.innerWidth;
        }, 250);
      });
    }
  }

  return e;
});

Marquee3k.init();