function hideProductModal() {
  const productModal = document.querySelectorAll('product-modal[open]');
  productModal && productModal.forEach((modal) => modal.hide());
}

function initJavascript(){
  if(document.querySelectorAll('.allow-header--transparent').length){
    document.body.classList.add('slideshow-transparent__header');
  }else{
    document.body.classList.remove('slideshow-transparent__header');
  }
  var sectionHeader = document.querySelector('.section-header');
  if (sectionHeader) {
    var rect = sectionHeader.getBoundingClientRect();
    var headerHeight = rect.height.toFixed(1);
    document.documentElement.style.setProperty('--header-height', headerHeight + 'px');
  }

  if(event.target.classList.contains('section_shop_the_look')){
    console.log("has section");
    const dots = document.querySelectorAll('.shop-the__look-dots');
    const productItems = document.querySelectorAll('.shop-the__look-products .shop-the__look-products_image');
    let modallookPopup = event.target.querySelector('.shop-the__look-dots');
    const mediaQuery = window.matchMedia('(min-width: 750px)');
    if (mediaQuery.matches) {
      console.log("match media");
      dots.forEach(d => d.classList.remove('selected'));
      productItems.forEach(item => item.classList.remove('active'));
    }else{
      console.log("not match media");
    }
  }else{
    console.log("not has sections");
  }
}

document.addEventListener('shopify:block:select', function (event) {
  hideProductModal();
  const blockSelectedIsSlide = event.target.classList.contains('slideshow__slide');
  if (!blockSelectedIsSlide) return;

  const parentSlideshowComponent = event.target.closest('slideshow-component');
  parentSlideshowComponent.pause();

  setTimeout(function () {
    parentSlideshowComponent.slider.scrollTo({
      left: event.target.offsetLeft,
    });
  }, 200);
});

document.addEventListener('shopify:block:deselect', function (event) {
  initJavascript();
  const blockDeselectedIsSlide = event.target.classList.contains('slideshow__slide');
  if (!blockDeselectedIsSlide) return;
  const parentSlideshowComponent = event.target.closest('slideshow-component');
  if (parentSlideshowComponent.autoplayButtonIsSetToPlay) parentSlideshowComponent.play();
});

document.addEventListener('shopify:section:load', () => {
  initJavascript();
  const checkMarquee = event.target.querySelectorAll('.marquee3k');
  const checkMarqueeElement = event.target.querySelector('.keep-scrolling__option');
  if (checkMarquee.length > 0) {
    Marquee3k.init(checkMarqueeElement);
  }
  hideProductModal();
  const zoomOnHoverScript = document.querySelector('[id^=EnableZoomOnHover]');
  if (!zoomOnHoverScript) return;
  if (zoomOnHoverScript) {
    const newScriptTag = document.createElement('script');
    newScriptTag.src = zoomOnHoverScript.src;
    zoomOnHoverScript.parentNode.replaceChild(newScriptTag, zoomOnHoverScript);
  }
});


document.addEventListener('shopify:section:reorder', () => hideProductModal());

document.addEventListener('shopify:section:select', (event) => {
  if(event.target.classList.contains('section-theme-modal__newsletter-popup')){
    let modalPopup = event.target.querySelector('.theme-modal-newsletter-popup');
    modalPopup.classList.add("active");
    document.querySelector("body").classList.add("overflow-hidden");
    document.querySelector(".theme-modal-newsletter-popup__overlay").classList.add("active");
  }   
  hideProductModal();
});

document.addEventListener('shopify:section:deselect', (event) => { 
  if(event.target.classList.contains('section-theme-modal__newsletter-popup')){
    let modalPopup = event.target.querySelector('.theme-modal-newsletter-popup');
    modalPopup.classList.remove("active");
    document.querySelector("body").classList.remove("overflow-hidden");
    document.querySelector(".theme-modal-newsletter-popup__overlay").classList.remove("active");
  }
  hideProductModal()
});
document.addEventListener('shopify:section:select', () => hideProductModal());

document.addEventListener('shopify:section:deselect', () => hideProductModal());

document.addEventListener('shopify:inspector:activate', () => hideProductModal());

document.addEventListener('shopify:inspector:deactivate', () => hideProductModal());  