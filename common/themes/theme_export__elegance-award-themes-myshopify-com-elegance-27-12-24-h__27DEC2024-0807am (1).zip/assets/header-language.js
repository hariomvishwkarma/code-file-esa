class HeaderLanguage extends HTMLElement {
    constructor() {
      super();
      const thisElement = this;
      this.headerlanguageButton = this.querySelector('.modal__toggle');
      this.headerlanguageClose = this.querySelector('.header-language__close-button');
      this.headerlanguageOverlay = this.querySelector('.modal-overlay');
      if(this.headerlanguageButton){
        this.headerlanguageButton.addEventListener("click", function(){
          thisElement.classList.add('active');
          document.body.classList.add('overflow-hidden');
        });
      }
      if(this.headerlanguageClose){
        this.headerlanguageClose.addEventListener("click", function(){
          thisElement.classList.remove('active');
          document.body.classList.remove('overflow-hidden');
        });
      }
      if(this.headerlanguageOverlay){
        this.headerlanguageOverlay.addEventListener("click", function(){
          thisElement.classList.remove('active');
          document.body.classList.remove('overflow-hidden');
        });
      }
    }
  }
  customElements.define('header-language', HeaderLanguage);