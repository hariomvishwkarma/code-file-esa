document.addEventListener('DOMContentLoaded', function () {
  const dots = document.querySelectorAll('.shop-the__look-dots');
  const productItems = document.querySelectorAll('.shop-the__look-products .shop-the__look-products_image');
  let activeProductIndex = null; 
  let activeDotIndex = null; 
  productItems.forEach(item => item.classList.remove('active'));
  dots.forEach(dot => dot.classList.remove('selected'));

  const handleLargeScreen = () => {
    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        if (activeDotIndex === index) {
          dot.classList.remove('selected');
          productItems[index].classList.remove('active');
          activeDotIndex = null;
          activeProductIndex = null;
        } else {
          dots.forEach(d => d.classList.remove('selected'));
          productItems.forEach(item => item.classList.remove('active'));

          dot.classList.add('selected');
          const targetProduct = productItems[index];
          targetProduct.classList.add('active');

         activeDotIndex = index;
          activeProductIndex = index;
        }
      });
    });
  };

  const handleSmallScreen = () => {
    if (activeDotIndex === null) {
      activeDotIndex = 0;
      activeProductIndex = 0;
      dots[activeDotIndex].classList.add('selected');
      productItems[activeProductIndex].classList.add('active');
    }

    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        dots.forEach(d => d.classList.remove('selected'));
        productItems.forEach(item => item.classList.remove('active'));

        dot.classList.add('selected');
        const targetProduct = productItems[index];
        targetProduct.classList.add('active');

       activeDotIndex = index;
        activeProductIndex = index;
      });
    });
  };

const mediaQuery = window.matchMedia('(min-width: 750px)');

  if (mediaQuery.matches) {
    handleLargeScreen();
  } else {
    handleSmallScreen();
  }

  mediaQuery.addEventListener('change', (e) => {
    if (e.matches) {
     handleLargeScreen();
    } else {
     handleSmallScreen();
    }
  });

 document.addEventListener('click', (e) => {
    if (!e.target.closest('.shop-the__look-dots') && !e.target.closest('.shop-the__look-products')) {
      if (activeDotIndex !== null) {
        dots[activeDotIndex].classList.remove('selected');
        productItems[activeProductIndex].classList.remove('active');
        activeDotIndex = null;
        activeProductIndex = null;
      }
    }
  });
});