if (!customElements.get('count-down-clock')) {
    class CountdownClock extends HTMLElement {
      constructor() {
        super();
  
        // DOM elements
        this.section = this.closest('section');
        this.display = this.querySelector('.count-down__clock');
        this.block = this.closest('.count-down__block-type-clock');
  
        // Countdown target date components
        this.targetYear = this.dataset.year;
        this.targetMonth = this.dataset.month;
        this.targetDay = this.dataset.day;
        this.targetHour = this.dataset.hour;
        this.targetMinute = this.dataset.minute;
  
        // Countdown placeholders
        this.daysPlaceholder = this.querySelector('.count-clock__days');
        this.hoursPlaceholder = this.querySelector('.count-clock__hours');
        this.minutesPlaceholder = this.querySelector('.count-clock__minutes');
        this.secondsPlaceholder = this.querySelector('.count-clock__seconds');
        this.messagePlaceholder = this.querySelector('.count-down__clock-message');
  
        // Countdown completion settings
        this.hideclockOnComplete = this.dataset.hideClock;
        this.completeMessage = this.dataset.completeMessage;
        this.clockComplete = false;
  
        // Initialize the countdown clock
        this.init();
      }
  
      init() {
        // Update the countdown every second
        setInterval(() => {
          if (!this.clockComplete) {
            this.calculateTime();
          }
        }, 1000);
      }
  
      calculateTime() {
        const targetDate = new Date(`${this.targetMonth}/${this.targetDay}/${this.targetYear} ${this.targetHour}:${this.targetMinute}:00`);
        const timeDifference = targetDate.getTime() - Date.now();
  
        if (timeDifference > 0) {
          // Calculate time intervals
          const intervals = {
            days: Math.floor(timeDifference / (1000 * 60 * 60 * 24)),
            hours: Math.floor((timeDifference / (1000 * 60 * 60)) % 24),
            minutes: Math.floor((timeDifference / 1000 / 60) % 60),
            seconds: Math.floor((timeDifference / 1000) % 60),
          };
  
          // Update placeholders with calculated intervals
          this.daysPlaceholder.innerHTML = intervals.days;
          this.hoursPlaceholder.innerHTML = intervals.hours;
          this.minutesPlaceholder.innerHTML = intervals.minutes;
          this.secondsPlaceholder.innerHTML = intervals.seconds;
        } else {
          // Countdown clock completed
          if (this.completeMessage && this.messagePlaceholder) {
            // Show completion message and hide the clock display
            this.messagePlaceholder.classList.remove('hidden');
          }
  
          if (this.hideclockOnComplete === 'true') {
            // Remove the entire countdown section
            this.display.classList.add('count-down__clock--hidden');
          }else{
            this.display.classList.remove('count-down__clock--hidden');
          }
  
          if (!this.completeMessage && this.hideclockOnComplete === 'true') {
            // Hide the countdown block if no completion message
            this.block.classList.add('count-down__block--hidden');
          }
  
          // Mark the clock as complete
          this.clockComplete = true;
        }
      }
    }
  
    // Define the custom countdown-clock element
    customElements.define('count-down-clock', CountdownClock);
  }

 if (!customElements.get('discount-code')) {
    class DiscountCodeBar extends HTMLElement {
      constructor() {
        super();
      }
      connectedCallback() {
        const discountField = this.querySelector('.discount-code-field__input');
        const copyButton = this.querySelector('.copy-code__discount-btn');
        const primaryLabel = copyButton.dataset.primaryLabel;
        const secondaryLabel = copyButton.dataset.secondaryLabel;

        copyButton.addEventListener('click', () => {
          discountField.select();
          // console.log(secondaryLabel)
          discountField.setSelectionRange(0, 99999);
          document.execCommand('copy');
          discountField.setSelectionRange(0, 0);
          copyButton.textContent = secondaryLabel;
          setTimeout(() => {
            copyButton.textContent = primaryLabel;
          }, 2000);
        });
      }
    }
    customElements.define('discount-code', DiscountCodeBar);
  }
// animation for discount code copy button

function basic(){
  confetti({
  particleCount: 100,
  spread: 70,
  origin: { y: 0.6 }
});
}