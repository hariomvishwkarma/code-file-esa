Igloo 2.1.2 


### Added
- Implemented updates to bring color swatches to the product detail pages, aligning with the existing use of color and image swatches for storefront filters via the Search & Discovery app to simplify the liquid swatch API by introducing a consistent SwatchDrop object for both color and image fields across all surfaces.


### Fixes and Improvements
- Fixed the issue with the JavaScript which was causing the browser loading issue in the theme.