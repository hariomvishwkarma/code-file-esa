if (!customElements.get('filter-toggle')) {
    class FilterToggle extends HTMLElement {
      constructor() {
        super();
  
        this.onButton = this.querySelector('.on--button');
        this.offButton = this.querySelector('.off--button');
        this.facetsContainer = document.querySelector('.facets-container');
        this.productGrid = document.querySelector('.product-grid-container');
  
        this.handleOnButtonClick = this.handleOnButtonClick.bind(this);
        this.handleOffButtonClick = this.handleOffButtonClick.bind(this);
  
        this.init();
      }
  
      init() {
        if (this.onButton) {
          this.onButton.classList.add('active');
        }
  
        if (this.onButton) {
          this.onButton.addEventListener('click', this.handleOnButtonClick);
        }
        if (this.offButton) {
          this.offButton.addEventListener('click', this.handleOffButtonClick);
        }
      }
  
      handleOnButtonClick() {
        if (!this.facetsContainer) {
          console.error('Facets container not found.');
          return;
        }
  
        this.onButton.classList.add('active');
        this.offButton.classList.remove('active');
        this.facetsContainer.classList.add('facets-container--on');
        this.facetsContainer.classList.remove('facets-container--off');
        this.productGrid.classList.remove('product-0', 'search-facets--off');
      }
  
      handleOffButtonClick() {
        if (!this.facetsContainer) {
          console.error('Facets container not found.');
          return;
        }
  
        this.offButton.classList.add('active');
        this.onButton.classList.remove('active');
        this.facetsContainer.classList.add('facets-container--off');
        this.facetsContainer.classList.remove('facets-container--on');
        this.productGrid.classList.add('product-0', 'search-facets--off');
      }
  
      disconnectedCallback() {
        if (this.onButton) {
          this.onButton.removeEventListener('click', this.handleOnButtonClick);
        }
        if (this.offButton) {
          this.offButton.removeEventListener('click', this.handleOffButtonClick);
        }
      }
    }
  
    customElements.define('filter-toggle', FilterToggle);
  }