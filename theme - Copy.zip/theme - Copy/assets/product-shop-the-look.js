if (!customElements.get('shop-the-look-modal')) {
  class ShopTheLookModal extends HTMLElement {
    constructor() {
      super();

      this.dots = this.querySelectorAll('.shop-the__look-dots');
      this.productItems = this.querySelectorAll('.shop-the__look-products .shop-the__look-products_image');

      this.activeDotIndex = null;
      this.activeProductIndex = null;

      this.initialize();
    }

    initialize() {
      this.clearActiveStates();
      this.setupMediaQueryListener();
      this.handleClickOutside();
    }

    clearActiveStates() {
      this.productItems.forEach(item => item.classList.remove('active'));
      this.dots.forEach(dot => dot.classList.remove('selected'));
    }

    handleLargeScreen() {
      this.clearActiveStates();
      this.dots.forEach((dot, index) => {
        dot.addEventListener('click', () => this.toggleActiveState(index));
      });
    }

    handleSmallScreen() {
      if (this.activeDotIndex === null) {
        this.activeDotIndex = 0;
        this.activeProductIndex = 0;
        this.setActiveState(0);
      }

      this.dots.forEach((dot, index) => {
        dot.addEventListener('click', () => this.setActiveState(index));
      });
    }

    toggleActiveState(index) {
      if (this.activeDotIndex === index) {
        this.clearActiveStates();
        this.activeDotIndex = null;
        this.activeProductIndex = null;
      } else {
        this.setActiveState(index);
      }
    }

    setActiveState(index) {
      this.clearActiveStates();
      this.dots[index].classList.add('selected');
      this.productItems[index].classList.add('active');
      this.activeDotIndex = index;
      this.activeProductIndex = index;
    }

    setupMediaQueryListener() {
      const mediaQuery = window.matchMedia('(min-width: 750px)');

      const handleMediaQueryChange = (e) => {
        if (e.matches) {
          this.handleLargeScreen();
        } else {
          this.handleSmallScreen();
        }
      };

      handleMediaQueryChange(mediaQuery);
      mediaQuery.addEventListener('change', handleMediaQueryChange);
    }

    handleClickOutside() {
      document.addEventListener('click', (e) => {
        if (
          !e.target.closest('.shop-the__look-dots') &&
          !e.target.closest('.shop-the__look-products')
        ) {
          this.clearActiveStates();
          this.activeDotIndex = null;
          this.activeProductIndex = null;
        }
      });
    }
  }

  customElements.define('shop-the-look-modal', ShopTheLookModal);
}