class HeaderCountry extends HTMLElement {
  constructor() {
    super();
    const thisElement = this;
    this.headercountryButton = this.querySelector('.modal__toggle');
    this.headercountryClose = this.querySelector('.header-country__close-button');
    this.headercountryOverlay = this.querySelector('.modal-overlay');
    if(this.headercountryButton){
      this.headercountryButton.addEventListener("click", function(){
        thisElement.classList.add('active');
        document.body.classList.add('overflow-hidden');
      });
    }
    if(this.headercountryClose){
      this.headercountryClose.addEventListener("click", function(){
        thisElement.classList.remove('active');
        document.body.classList.remove('overflow-hidden');
      });
    }
    if(this.headercountryOverlay){
      this.headercountryOverlay.addEventListener("click", function(){
        thisElement.classList.remove('active');
        document.body.classList.remove('overflow-hidden');
      });
    }
  }
}
customElements.define('header-country', HeaderCountry);