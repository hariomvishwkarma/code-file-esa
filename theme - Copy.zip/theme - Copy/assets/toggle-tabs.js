if (!customElements.get('toggle-tab')) {
  class ToggleTab extends HTMLElement {
    constructor() {
      super();
    }

    connectedCallback() {
      this.initializeAccordion();
    }

    initializeAccordion() {
      const accordionButtons = this.querySelectorAll(".accordion-toggle-btn");
      accordionButtons.forEach((button) => {
        button.addEventListener("click", () => {
          const content = this.querySelector(button.getAttribute("data-toggle"));
          if (content) {
            if (content.classList.contains("active")) {
              this.slideUp(content);
            } else {
              this.slideDown(content);
            }
            content.classList.toggle("active");
          }
          const icon = button.querySelector(".toggle-icon");
          if (icon) {
            icon.classList.toggle("rotate");
          }
          button.classList.toggle("active");
        });
      });
    }

    slideUp(element) {
      if (element.classList.contains("sliding")) return;
      element.classList.add("sliding");
      element.style.height = element.scrollHeight + "px";
      requestAnimationFrame(() => {
        element.style.transition = "height 0.3s ease";
        element.style.height = "0";
        element.style.overflow = "hidden";
      });
      element.addEventListener(
        "transitionend",
        function () {
          if (element.style.height === "0px") {
            element.style.height = "";
            element.style.transition = "";
            element.classList.remove("sliding");
          }
        },
        { once: true }
      );
    }

    slideDown(element) {
      if (element.classList.contains("sliding")) return;
      element.classList.add("sliding");
      element.style.height = "0";
      requestAnimationFrame(() => {
        element.style.transition = "height 0.3s ease";
        element.style.height = element.scrollHeight + "px";
        element.style.overflow = "hidden";
      });
      element.addEventListener(
        "transitionend",
        function () {
          if (element.style.height !== "0px") {
            element.style.height = "";
            element.style.transition = "";
            element.classList.remove("sliding");
          }
        },
        { once: true }
      );
    }
  }

  customElements.define('toggle-tab', ToggleTab);
}