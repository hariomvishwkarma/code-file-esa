class HeaderMegaMenu extends HTMLElement {
  constructor() {
    super();
   
    const thisElement = this;
    this.megaMenuButton = this.querySelector('.mega-menu__toggle');
    this.megaMenuClose = this.querySelector('.mega-menu__close-button');
    this.megaMenuOverlay = this.querySelector('.mega-menu-overlay');
    if(this.megaMenuButton){
      this.megaMenuButton.addEventListener("click", function(){
        thisElement.classList.add('active');
        document.body.classList.add('overflow-hidden', 'overlay-opened');
      });
    }
    if(this.megaMenuClose){
      this.megaMenuClose.addEventListener("click", function(){
        thisElement.classList.remove('active');
        document.body.classList.remove('overflow-hidden', 'overlay-opened');
      });
    }
    if(this.megaMenuOverlay){
      this.megaMenuOverlay.addEventListener("click", function(){
        thisElement.classList.remove('active');
        document.body.classList.remove('overflow-hidden', 'overlay-opened');
      });
    }
    const drawermenuHeader = document.querySelector('.mega-menu-header__content');
    if (drawermenuHeader) {
      const totalHeightmenu = drawermenuHeader.offsetHeight;
      document.documentElement.style.setProperty('--total-height-desktopmenu', `${totalHeightmenu}px`);
    
    }
  
  }
}
customElements.define('header-mega-menu', HeaderMegaMenu);