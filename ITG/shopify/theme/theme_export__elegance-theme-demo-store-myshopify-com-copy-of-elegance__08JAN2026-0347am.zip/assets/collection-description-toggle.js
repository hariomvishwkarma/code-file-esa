if (!customElements.get('collection-description-toggle')) {
  class CollectionDescriptionToggle extends HTMLElement {
    constructor() {
      super();

      this.arrowDownButton = this.querySelector('.arrow_down');
      this.arrowUpButton = this.querySelector('.arrow_up');
      this.descriptionContainer = document.querySelector('.collection-hero__description');
      this.imageContainer = document.querySelector('.collection-hero__image-container--innner');
      this.heroInner = document.querySelector('.collection-hero-inner');

      this.handleArrowDownClick = this.handleArrowDownClick.bind(this);
      this.handleArrowUpClick = this.handleArrowUpClick.bind(this);

      this.init();
    }

    init() {
      if (this.arrowDownButton) {
        this.arrowDownButton.addEventListener('click', this.handleArrowDownClick);
      }

      if (this.arrowUpButton) {
        this.arrowUpButton.addEventListener('click', this.handleArrowUpClick);
      }
    }

    handleArrowDownClick() {
      if (!this.arrowDownButton || !this.arrowUpButton || !this.heroInner || !this.descriptionContainer || !this.imageContainer) {
        console.error('Required elements are missing.');
        return;
      }

      this.arrowDownButton.classList.add('hide_des');
      this.arrowDownButton.classList.remove('show');

      this.arrowUpButton.classList.add('show');

      this.heroInner.classList.add('description_show');
      this.imageContainer.classList.add('description_show');
      this.descriptionContainer.classList.add('description_show');
      this.descriptionContainer.classList.remove('hide_des');
    }

    handleArrowUpClick() {
      if (!this.arrowDownButton || !this.arrowUpButton || !this.heroInner || !this.descriptionContainer || !this.imageContainer) {
        console.error('Required elements are missing.');
        return;
      }

      this.arrowUpButton.classList.remove('show');
      this.arrowUpButton.classList.add('hide_des');

      this.arrowDownButton.classList.add('show');
      this.arrowDownButton.classList.remove('hide_des');

      this.heroInner.classList.remove('description_show');
      this.imageContainer.classList.remove('description_show');
      this.descriptionContainer.classList.remove('description_show');
      this.descriptionContainer.classList.add('hide_des');
    }

    disconnectedCallback() {
      if (this.arrowDownButton) {
        this.arrowDownButton.removeEventListener('click', this.handleArrowDownClick);
      }

      if (this.arrowUpButton) {
        this.arrowUpButton.removeEventListener('click', this.handleArrowUpClick);
      }
    }
  }

  customElements.define('collection-description-toggle', CollectionDescriptionToggle);
}