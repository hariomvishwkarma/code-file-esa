class UserModal extends HTMLElement {
    constructor() {
      super();
      const thisElement = this;
      this.modalButton = this.querySelector('.modal__toggle');
      this.searchModalClose = this.querySelector('.user-modal__close-button');
      this.searchModalOverlay = this.querySelector('.modal-overlay');
      if(this.modalButton){
        this.modalButton.addEventListener("click", function(){
          thisElement.classList.add('active');
          document.body.classList.add('overflow-hidden', 'overlay-opened');
        });
      }
      if(this.searchModalClose){
        this.searchModalClose.addEventListener("click", function(){
          thisElement.classList.remove('active');
          document.body.classList.remove('overflow-hidden', 'overlay-opened');
        });
      }
      if(this.searchModalOverlay){
        this.searchModalOverlay.addEventListener("click", function(){
          thisElement.classList.remove('active');
          document.body.classList.remove('overflow-hidden', 'overlay-opened');
        });
      }
    }
  }
  customElements.define('user-modal', UserModal);