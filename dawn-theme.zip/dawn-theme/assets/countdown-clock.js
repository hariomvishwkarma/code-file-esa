if (!customElements.get('count-down-clock')) {
  class CountdownClock extends HTMLElement {
    constructor() {
      super();

      this.section = this.closest('section');
      this.display = this.querySelector('.count-down__clock');
      this.block = this.closest('.count-down__block-type-clock');

      this.targetYear = this.dataset.year;
      this.targetMonth = this.dataset.month;
      this.targetDay = this.dataset.day;
      this.targetHour = this.dataset.hour;
      this.targetMinute = this.dataset.minute;

      this.daysPlaceholder = this.querySelector('.count-clock__days');
      this.hoursPlaceholder = this.querySelector('.count-clock__hours');
      this.minutesPlaceholder = this.querySelector('.count-clock__minutes');
      this.secondsPlaceholder = this.querySelector('.count-clock__seconds');
      this.messagePlaceholder = this.querySelector('.count-down__clock-message');

      this.hideclockOnComplete = this.dataset.hideClock;
      this.completeMessage = this.dataset.completeMessage;
      this.clockComplete = false;

      this.init();
    }

    init() {
      setInterval(() => {
        if (!this.clockComplete) {
          this.calculateTime();
        }
      }, 1000);
    }

    calculateTime() {
      const targetDate = new Date(`${this.targetMonth}/${this.targetDay}/${this.targetYear} ${this.targetHour}:${this.targetMinute}:00`);
      const timeDifference = targetDate.getTime() - Date.now();

      if (timeDifference > 0) {
        const intervals = {
          days: Math.floor(timeDifference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((timeDifference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((timeDifference / 1000 / 60) % 60),
          seconds: Math.floor((timeDifference / 1000) % 60),
        };

        this.daysPlaceholder.innerHTML = intervals.days;
        this.hoursPlaceholder.innerHTML = intervals.hours;
        this.minutesPlaceholder.innerHTML = intervals.minutes;
        this.secondsPlaceholder.innerHTML = intervals.seconds;
      } else {
        if (this.completeMessage && this.messagePlaceholder) {
          this.messagePlaceholder.classList.remove('hidden');
        }

        if (this.hideclockOnComplete === 'true') {
          this.display.classList.add('count-down__clock--hidden');
        }else{
          this.display.classList.remove('count-down__clock--hidden');
        }

        if (!this.completeMessage && this.hideclockOnComplete === 'true') {
          this.block.classList.add('count-down__block--hidden');
        }

        this.clockComplete = true;
      }
    }
  }
  customElements.define('count-down-clock', CountdownClock);
}

if (!customElements.get('discount-code')) {
  class DiscountCodeBar extends HTMLElement {
    constructor() {
      super();
    }
    connectedCallback() {
      const discountField = this.querySelector('.discount-code-field__input');
      const copyButton = this.querySelector('.copy-code__discount-btn');
      const primaryLabel = copyButton.dataset.primaryLabel;
      const secondaryLabel = copyButton.dataset.secondaryLabel;

      copyButton.addEventListener('click', () => {
        discountField.select();
        discountField.setSelectionRange(0, 99999);
        document.execCommand('copy');
        discountField.setSelectionRange(0, 0);
        copyButton.textContent = secondaryLabel;
        setTimeout(() => {
          copyButton.textContent = primaryLabel;
        }, 2000);
      });
    }
  }
  customElements.define('discount-code', DiscountCodeBar);
}

function basic(){
  confetti({
    particleCount: 100,
    spread: 70,
    origin: { y: 0.6 }
  });
}